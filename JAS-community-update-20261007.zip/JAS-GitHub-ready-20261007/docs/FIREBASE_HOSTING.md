# Deployment status: 2026-10-07

Live: https://jasvolunteers.web.app redirects to https://jas-1-xukz.onrender.com/index.html. Other paths are preserved with HTTP 302. Render serves both frontend and API; Firebase only redirects. API categories and health checks returned 200; unauthenticated profile access returned 401. Root Render URL still returns API metadata; use /index.html. Browser login with an existing account has not been tested remotely.

The Cloud Run instructions below describe the previous alternative, which was not deployed.

# Firebase Hosting + Python API

Цель: `https://jasvolunteers.web.app`, Firebase-проект `jasvolunteers`.

`firebase.json` публикует только `frontend`, а `/api/**` направляет на Cloud Run `jas-api` в `europe-west1`. Весь репозиторий публиковать нельзя: backend содержит локальные ключи и резервные копии.

Firebase CLI установлен. Доступ к Hosting проверен через локальный сервисный аккаунт; отдельный `firebase login` для этого подключения не требуется. Публикация пока не выполнена: сначала нужно разместить API.

## Сервер

Контейнер собирается из `backend/Dockerfile` с контекстом `backend`. `.dockerignore` допускает только исходники приложения, Dockerfile и зависимости. Ключи, `.env`, резервные копии и тестовые артефакты в образ не включаются.

На Cloud Run используются Application Default Credentials прикреплённого сервисного аккаунта, которому нужен доступ к Firestore. Не нужно загружать JSON-ключ в контейнер. Для API заданы `FIREBASE_USE_ADC=true`, `FIREBASE_PROJECT_ID=jasvolunteers`, `COOKIE_SECURE=true`, `SESSION_COOKIE_NAME=__session`. Локально по умолчанию остаётся cookie `session`.

Hosting передаёт на backend только cookie `__session`. Чтение сессии, выход, смена пароля и завершение всех сессий используют согласованное имя. Ответы API помечаются `private, no-store`.

Cloud Run требует привязанного платёжного аккаунта (Blaze), даже при использовании бесплатных квот. Подключение платёжного аккаунта не выполнялось. Перед запуском выбрать ограничение числа экземпляров (для теста: максимум 1, минимум 0). Rate limiter приложения хранится в памяти процесса, а не распределённо.

AI требует отдельной настройки серверного ключа через секреты окружения. Локальный `.env` автоматически в облако не переносится. Bootstrap отключён (`--lifespan off`), поскольку база уже перенесена.

После запуска API проверить его доступ к Firestore и только затем выполнить `firebase deploy --only hosting --project jasvolunteers`. Проверить через домен вход, `/auth/me`, выход, просмотр проектов и профилей. Для проверки не менять реальные часы и заявки.

Документация:
- https://firebase.google.com/docs/hosting/cloud-run
- https://firebase.google.com/docs/hosting/manage-cache

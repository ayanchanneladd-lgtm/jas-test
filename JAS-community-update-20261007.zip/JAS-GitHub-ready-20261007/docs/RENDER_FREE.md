# Live deployment: 2026-10-07

Render: https://jas-1-xukz.onrender.com/index.html
Firebase entry: https://jasvolunteers.web.app
Repository root directory on Render: JAS-GitHub-ready-20261007

# Тестовый запуск без карты

Согласованная схема: сайт и Python API на одном бесплатном Render Web Service; Firebase `jasvolunteers.web.app` перенаправляет на адрес сервиса. Firestore остаётся в `jasvolunteers`. Это позволяет использовать обычные HttpOnly-cookie без зависимости от сторонних cookie браузера.

## Подготовлено

- `render.yaml`: план Free, Python, команда сборки и запуска, переменные окружения.
- `JAS_SERVE_FRONTEND=true`: API отдаёт только каталог `frontend`. Ключи и резервные копии недоступны по HTTP.
- `/healthz`: проверка работоспособности процесса без чтения Firestore.
- Bootstrap отключён через `--lifespan off`, поэтому запуск не изменяет перенесённые аккаунты.
- Firebase-публикация и перенаправление пока не выполнялись: нужен фактический URL Render.

## Создание сервиса

1. Зарегистрироваться на https://dashboard.render.com/ через GitHub.
2. Подключить приватный GitHub-репозиторий проекта. Не загружать `.env`, JSON-ключи, `.migration-backups`, `.venv-local` или `.test-artifacts`. `.gitignore` уже исключает используемые локальные пути.
3. Создать **Web Service**, выбрать репозиторий, **Python 3**, корневая папка репозитория (Root Directory оставить пустым).
4. Build Command: `pip install -r backend/requirements.txt`.
5. Start Command: `uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port $PORT --lifespan off`.
6. Выбрать **Free**, регион Frankfurt; не выбирать платный план и не добавлять карту.
7. Перенести переменные из `render.yaml` в Environment. В **Secret Files** добавить `firebase-service-account.json` с содержимым локального ключа именно проекта `jasvolunteers`. Ключ не добавлять в GitHub или обычные файлы сайта.
8. Health Check Path: `/healthz`. Запустить deploy.
9. Проверить страницы, API, вход/выход и доступ к Firestore. AI требует отдельного подключения серверного секрета и по умолчанию не включается.
10. После получения и проверки URL Render заменить Cloud Run rewrite в `firebase.json` на временное перенаправление (302), сохранив пути страниц. Только после этого выполнить Firebase deploy.

Бесплатный Render засыпает после 15 минут бездействия. Первый запуск после сна может занять около минуты. Есть месячные лимиты и ограничения исходящего трафика к внешней базе; это тестовый вариант, не обещание круглосуточной доступности. Не использовать искусственные запросы для обхода режима сна.

Источники:
- https://render.com/docs/free
- https://render.com/docs/deploy-fastapi
- https://render.com/docs/configure-environment-variables

"""Profile 2.0: backwards-compatible fields; no unconfigured file uploads."""
from typing import Annotated

from fastapi import Depends, HTTPException
from firebase_admin import firestore
from pydantic import BaseModel, ConfigDict, Field, field_validator


Label = Annotated[str, Field(min_length=1, max_length=50)]


class ProfileUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    full_name: str = Field(min_length=3, max_length=120)
    username: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z0-9_]+$")
    about: str = Field(default="", max_length=1000)
    skills: list[Label] = Field(default_factory=list, max_length=20)
    interests: list[Label] = Field(default_factory=list, max_length=20)

    @field_validator("full_name", "username", "about", mode="before")
    @classmethod
    def trim(cls, value):
        return value.strip() if isinstance(value, str) else value

    @field_validator("skills", "interests", mode="before")
    @classmethod
    def normalize_labels(cls, value):
        if not isinstance(value, list):
            raise ValueError("Передайте список значений")
        if len(value) > 20:
            raise ValueError("Не больше 20 значений")
        result, seen = [], set()
        for label in value:
            if not isinstance(label, str):
                raise ValueError("Каждое значение должно быть строкой")
            label = label.strip()
            if not label or len(label) > 50:
                raise ValueError("Длина каждого значения: от 1 до 50 символов")
            if label.casefold() not in seen:
                result.append(label)
                seen.add(label.casefold())
        return result


def profile_defaults(data):
    """Old accounts remain readable without a database-wide backfill."""
    return {"about": "", "skills": [], "interests": [], "avatar": None, **data}


def save_profile(body, user):
    from . import main as m
    client = m.store()
    ref = client.collection("users").document(user["id"])
    changes = body.model_dump(exclude_unset=True)
    changes["username"] = changes["username"].lower()
    existing = m.first(client.collection("users").where(
        filter=m.FieldFilter("username", "==", changes["username"])))
    if existing and existing.id != user["id"]:
        raise HTTPException(409, "Этот никнейм уже занят")
    audit_ref = client.collection("audit_logs").document()

    @firestore.transactional
    def commit(tx):
        snapshot = ref.get(transaction=tx)
        if not snapshot.exists or not snapshot.to_dict().get("active"):
            raise HTTPException(401, "Аккаунт недоступен")
        previous = snapshot.to_dict()
        fields = sorted(key for key, value in changes.items() if previous.get(key) != value)
        if fields:
            tx.update(ref, {**changes, "updated_at": m.now()})
            tx.set(audit_ref, {"user_id": user["id"], "action": "profile.update",
                              "entity": "user", "entity_id": user["id"],
                              "details": {"changed_fields": fields}, "created_at": m.now()})
    commit(client.transaction())
    return {"user": m.organization_details(m.as_dict(ref.get()))}


def install(app):
    from . import main as m

    @app.get("/api/v1/profile/avatar/capabilities")
    def avatar_capabilities(user=Depends(m.require("profile.read"))):
        return {"upload_enabled": False, "delete_enabled": True,
                "reason": "Загрузка аватаров пока недоступна: безопасное хранилище не подключено."}

    @app.put("/api/v1/profile/avatar")
    def upload_avatar(user=Depends(m.require("profile.update"))):
        # Intentionally no UploadFile/body parser: reject without reading/storing a file.
        raise HTTPException(503, "Загрузка аватаров отключена до подключения безопасного хранилища")

    @app.delete("/api/v1/profile/avatar")
    def delete_avatar(user=Depends(m.require("profile.update"))):
        client = m.store()
        ref = client.collection("users").document(user["id"])
        log_ref = client.collection("audit_logs").document()

        @firestore.transactional
        def commit(tx):
            snapshot = ref.get(transaction=tx)
            if not snapshot.exists or not snapshot.to_dict().get("active"):
                raise HTTPException(401, "Аккаунт недоступен")
            if snapshot.to_dict().get("avatar") is not None:
                tx.update(ref, {"avatar": None, "updated_at": m.now()})
                tx.set(log_ref, {"user_id": user["id"], "action": "avatar.update",
                                "entity": "user", "entity_id": user["id"],
                                "details": {"operation": "remove"}, "created_at": m.now()})
        commit(client.transaction())
        return {"avatar": None}

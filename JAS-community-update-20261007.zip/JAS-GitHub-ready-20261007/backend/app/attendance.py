"""Atomic first-time attendance for bounded groups; existing lifecycle is retained."""
from typing import Literal

from fastapi import Depends, HTTPException
from firebase_admin import firestore
from pydantic import BaseModel, ConfigDict, Field, model_validator


class AttendanceItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    application_id: str = Field(min_length=1, max_length=300, pattern=r"^[^/]+$")
    status: Literal["completed", "no_show", "excused"]


class AttendanceBatch(BaseModel):
    model_config = ConfigDict(extra="forbid")
    items: list[AttendanceItem] = Field(min_length=1, max_length=50)

    @model_validator(mode="after")
    def distinct(self):
        if len({item.application_id for item in self.items}) != len(self.items):
            raise ValueError("Заявка повторяется в списке")
        return self


def mark_attendance(project_id, body, user):
    from . import main as m
    client = m.store()

    @firestore.transactional
    def commit(tx):
        # Read all resources before any writes. A conflict aborts the entire group.
        project = client.collection("projects").document(project_id).get(transaction=tx)
        if not project.exists:
            raise HTTPException(404, "Проект не найден")
        data = project.to_dict()
        m.require_project_scope(data, user)
        if data.get("status") != "completed":
            raise HTTPException(409, "Сначала завершите проект")
        pending = []
        unchanged = 0
        for item in body.items:
            ref = client.collection("applications").document(item.application_id)
            snap = ref.get(transaction=tx)
            row = snap.to_dict() or {}
            if not snap.exists or row.get("project_id") != project_id:
                raise HTTPException(422, "Все заявки должны принадлежать выбранному проекту")
            if row.get("status") == item.status:
                unchanged += 1
                continue
            if row.get("status") != "accepted":
                raise HTTPException(409, "Список устарел: участие уже отмечено или заявка не принята. Обновите данные")
            pending.append((item, ref, row))
        stamp = m.now()
        labels = {"completed": "участие подтверждено", "no_show": "отмечено отсутствие",
                  "excused": "отсутствие по уважительной причине"}
        for item, ref, row in pending:
            tx.update(ref, {"status": item.status, "reviewed_by": user["id"], "updated_at": stamp})
            tx.set(client.collection("application_events").document(), {
                "application_id": item.application_id, "user_id": row["user_id"],
                "from_status": "accepted", "status": item.status, "actor_id": user["id"], "created_at": stamp})
            tx.set(client.collection("notifications").document(), {
                "audience": "user", "user_id": row["user_id"], "type": "ATTENDANCE_UPDATED",
                "title": "Участие в проекте", "message": data.get("title", "Проект")+": "+labels[item.status],
                "application_id": item.application_id, "related_resource_type": "project",
                "related_resource_id": project_id, "created_at": stamp})
            tx.set(client.collection("audit_logs").document(), {
                "user_id": user["id"], "action": "attendance.update", "entity": "application",
                "entity_id": item.application_id, "details": {"from_status": "accepted", "status": item.status,
                "project_id": project_id}, "created_at": stamp})
        return {"updated": len(pending), "unchanged": unchanged, "total": len(body.items)}
    return commit(client.transaction())


def install(app):
    from . import main as m

    @app.put("/api/v1/projects/{project_id}/attendance")
    def save_attendance(project_id: str, body: AttendanceBatch, user=Depends(m.require("attendance.manage"))):
        return mark_attendance(project_id, body, user)

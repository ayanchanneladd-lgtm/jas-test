"""Self-service security; session version invalidates every existing device."""
from fastapi import Depends, HTTPException, Response
from pydantic import BaseModel, Field
from firebase_admin import firestore
from . import main as m


class PasswordChange(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)
    password_confirmation: str = Field(min_length=8, max_length=128)


def install(app):
    def revoke(user, body=None):
        if body and body.new_password != body.password_confirmation:
            raise HTTPException(422, "Новые пароли не совпадают")
        if body and body.new_password == body.current_password:
            raise HTTPException(422, "Новый пароль должен отличаться от текущего")
        client = m.store()
        ref = client.collection("users").document(user["id"])
        # Hash only once; verification against latest hash happens in transaction.
        new_hash = m.password(body.new_password) if body else None
        @firestore.transactional
        def commit(tx):
            snap = ref.get(transaction=tx)
            data = snap.to_dict() or {}
            if not snap.exists or not data.get("active"):
                raise HTTPException(401, "Аккаунт недоступен")
            if body and not m.valid_password(body.current_password, data.get("password_hash")):
                raise HTTPException(400, "Текущий пароль неверен")
            changes = {"session_version": data.get("session_version", 0) + 1, "updated_at": m.now()}
            if new_hash:
                changes["password_hash"] = new_hash
            tx.update(ref, changes)
            tx.set(client.collection("audit_logs").document(), {
                "user_id": user["id"], "action": "password.change" if body else "sessions.revoke_all",
                "entity": "user", "entity_id": user["id"], "created_at": m.now()})
        commit(client.transaction())

    @app.post("/api/v1/profile/password")
    def change_password(body: PasswordChange, response: Response, user=Depends(m.current_user)):
        revoke(user, body)
        response.delete_cookie(m.SESSION_COOKIE_NAME)
        return {"message": "Пароль изменён. Все сессии завершены. Войдите с новым паролем."}

    @app.post("/api/v1/profile/logout-all")
    def logout_all(response: Response, user=Depends(m.current_user)):
        revoke(user)
        response.delete_cookie(m.SESSION_COOKIE_NAME)
        return {"message": "Все сессии завершены, включая текущую."}

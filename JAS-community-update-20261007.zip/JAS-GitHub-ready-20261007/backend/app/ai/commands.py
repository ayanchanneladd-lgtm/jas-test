"""Explicit chat commands, parsed locally; never infer consent from model output."""
import re


TOPIC = r'(?:технические\s+работы|техническое\s+обслуживание|тех\.?\s*работы)'
START = rf'(?:включи(?:ть)?|запусти(?:ть)?|активируй|начни)\s+(?:протокол\s+)?{TOPIC}'
STOP = rf'(?:выключи(?:ть)?|отключи(?:ть)?|заверши(?:ть)?|останови(?:ть)?)\s+(?:протокол\s+)?{TOPIC}'


def parse(message):
    text = re.sub(r'\s+', ' ', message.strip()).lower().replace('ё', 'е')
    text = re.sub(r'^пожалуйста[, ]+', '', text)
    if re.fullmatch(rf'(?:{STOP}|открой\s+сайт)[.!]?', text):
        return {'action':'maintenance.stop','parameters':{}}
    beginning = re.match(rf'^(?:{START}|закрой\s+сайт\s+на\s+{TOPIC})(?=\s|[.!]|$)', text)
    if not beginning:
        return None
    tail = text[beginning.end():].strip()
    duration = re.fullmatch(r'(?:на\s+)?(\d+(?:[.,]\d+)?)\s*(час(?:а|ов)?|ч\.?|минут(?:а|ы)?|мин\.?)[.!]?', tail)
    if not duration:
        return {'help':'Укажи продолжительность одной командой: «Включи технические работы на 5 часов». Для своей причины используй режим управления ниже.'}
    hours = float(duration[1].replace(',', '.'))
    if duration[2].startswith('мин'):
        hours /= 60
    if not 0 < hours <= 720:
        return {'help':'Продолжительность должна быть больше нуля и не более 720 часов.'}
    return {'action':'maintenance.start','parameters':{'hours':hours,'reason':'Технические работы'}}

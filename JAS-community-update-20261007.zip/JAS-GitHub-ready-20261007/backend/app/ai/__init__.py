"""Read-only Gemini assistant; no platform-data or execution tools."""

"""Human-approved administrative operations. No model-generated HTTP paths."""
import hashlib
import json
import time
from uuid import UUID, uuid4

import httpx
from fastapi import Depends, HTTPException, Request, Response
from firebase_admin import firestore
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from starlette.concurrency import run_in_threadpool

from . import service
from .history import operate
from .routes import ChatRequest, failure


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')


class Empty(Strict):
    pass


class Named(Strict):
    name: str = Field(min_length=2, max_length=120)


class ProposalIn(Strict):
    action: str = Field(max_length=80)
    target: str = Field(default='', max_length=150, pattern=r'^[\w-]*$')
    parameters: dict = Field(default_factory=dict)


class Decision(Strict):
    confirm: bool = Field(strict=True)


class DraftIn(ChatRequest):
    action: str = Field(max_length=80)


def registry():
    from .. import main as m
    # key: label, HTTP method, fixed path, collection, model. Target substitution
    # is restricted to one validated identifier; no URL or method from Gemini.
    entries = {
        'project.create': ('Создать проект','POST','/projects',None,m.ProjectIn),
        'project.edit': ('Изменить проект','PUT','/projects/{target}','projects',m.ProjectIn),
        'project.complete': ('Завершить проект','PATCH','/projects/{target}/complete','projects',Empty),
        'project.delete': ('Удалить проект с причиной','DELETE','/projects/{target}','projects',m.ProjectDeletion),
        'project.restore': ('Восстановить проект','POST','/admin/projects/{target}/restore','projects',Empty),
        'application.review': ('Принять / отклонить заявку','PATCH','/applications/{target}','applications',m.Review),
        'user.update': ('Роль, блокировка, отдел или команда участника','PATCH','/admin/users/{target}','users',m.AdminUserUpdate),
        'user.verify': ('Выдать / снять галочку','PATCH','/verification/users/{target}','users',m.VerificationIn),
        'role.permissions': ('Изменить permissions роли','PUT','/admin/roles/{target}','roles',m.RolePermissionsUpdate),
        'maintenance.start': ('Закрыть сайт на техработы','POST','/admin/maintenance','settings',m.MaintenanceIn),
        'maintenance.stop': ('Открыть сайт','DELETE','/admin/maintenance','settings',Empty),
        'settings.update': ('Изменить название / BETA-режим','PATCH','/admin/settings','settings',m.SettingsIn),
        'notification.create': ('Опубликовать уведомление','POST','/admin/notifications',None,m.NotificationIn),
        'department.create': ('Создать отдел','POST','/admin/departments',None,m.DepartmentIn),
        'department.edit': ('Переименовать отдел','PATCH','/admin/departments/{target}','departments',Named),
        'department.delete': ('Удалить отдел','DELETE','/admin/departments/{target}','departments',Empty),
        'team.create': ('Создать команду','POST','/admin/teams',None,m.TeamIn),
        'team.edit': ('Переименовать команду','PATCH','/admin/teams/{target}','teams',Named),
        'team.delete': ('Удалить команду','DELETE','/admin/teams/{target}','teams',Empty),
        'category.create': ('Создать категорию','POST','/admin/categories',None,Named),
        'category.edit': ('Переименовать категорию','PATCH','/admin/categories/{target}','project_categories',Named),
        'category.delete': ('Удалить категорию','DELETE','/admin/categories/{target}','project_categories',Empty),
    }
    return entries


def authorize(user, tx=None):
    from .. import main as m
    current = m.store().collection('users').document(user['id']).get(transaction=tx).to_dict() or {}
    roles = m.store().collection('system_config').document('roles').get(transaction=tx).to_dict() or {}
    allowed = set(roles.get('roles',{}).get(current.get('role'), m.PERMISSIONS.get(current.get('role'),set())))
    if (not current.get('active') or current.get('role') != 'super_admin'
            or current.get('session_version',0) != user.get('session_version',0)
            or not ('*' in allowed or {'ai.access','ai.chat','ai.admin'}.issubset(allowed))):
        raise service.AIError('Управление JAS AI доступно только разработчику с AI-правами.',403)


def validate(body):
    spec = registry().get(body.action)
    if not spec:
        raise service.AIError('Неизвестный инструмент.',422)
    model = spec[4]
    if set(body.parameters) - set(model.model_fields):
        raise service.AIError('Недопустимые параметры операции.',422)
    if len(json.dumps(body.parameters,ensure_ascii=False).encode()) > 24000:
        raise service.AIError('Слишком много параметров.',422)
    try:
        params = model.model_validate(body.parameters).model_dump(exclude_unset=True)
    except ValidationError:
        raise service.AIError('Заполните обязательные поля согласно схеме операции.',422) from None
    if body.action == 'application.review' and params.get('status') not in {'accepted','rejected'}:
        raise service.AIError('Здесь доступны только accepted и rejected. Посещаемость отмечается отдельно.',422)
    if body.action == 'user.update' and not params:
        raise service.AIError('Укажите изменения пользователя.',422)
    if spec[3] not in (None,'settings') and not body.target:
        raise service.AIError('Выберите объект операции.',422)
    if spec[3] in (None,'settings') and body.target:
        raise service.AIError('Для этой операции объект выбирать не нужно.',422)
    return spec, params


def snapshot(spec, target, tx=None):
    from .. import main as m
    collection = spec[3]
    if not collection:
        return {'exists':False}, 'Новый объект'
    if collection == 'roles':
        if target not in m.ROLE_LABELS:
            raise service.AIError('Неизвестная роль.',422)
        data = m.store().collection('system_config').document('roles').get(transaction=tx).to_dict() or {}
        return {'permissions':data.get('roles',{}).get(target,sorted(m.PERMISSIONS[target]))}, m.ROLE_LABELS[target]
    if collection == 'settings':
        data = m.store().collection('system_config').document('settings').get(transaction=tx).to_dict() or {}
        return data, 'Настройки платформы'
    row = m.store().collection(collection).document(target).get(transaction=tx)
    if not row.exists:
        raise service.AIError('Объект не найден.',404)
    data = row.to_dict()
    if collection == 'users':
        # No credentials, email or session material is read into the proposal.
        data = {k:data.get(k) for k in ('full_name','role','active','department_id','team_id','verified','updated_at','session_version')}
    return data, str(data.get('title') or data.get('name') or data.get('full_name') or target)[:180]


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,default=str).encode()).hexdigest()


def audit(tx, user, action, proposal_id, tool):
    from .. import main as m
    tx.set(m.store().collection('audit_logs').document(), {'user_id':user['id'], 'action':action,
        'entity':'ai_proposal', 'entity_id':proposal_id, 'created_at':m.now(), 'details':{'tool':tool}})


def prepare(user, body):
    from .. import main as m
    spec, params = validate(body)
    db = m.store()
    # One active proposal per actor; preparing another invalidates the old one.
    ref = db.collection('ai_proposals').document(user['id'])

    @firestore.transactional
    def commit(tx):
        authorize(user,tx)
        previous = ref.get(transaction=tx).to_dict() or {}
        if previous.get('state') in ('executing','unknown'):
            raise service.AIError('Предыдущая операция выполняется или требует ручной проверки результата.',409)
        data, label = snapshot(spec,body.target,tx)
        proposal = {'id':str(uuid4()),'owner':user['id'],'action':body.action,'target':body.target,
            'parameters':params,'label':label,'fingerprint':digest(data),'state':'pending',
            'before':{key:data.get(key) for key in params},
            'expires':time.time()+600,'created_at':m.now()}
        tx.set(ref,proposal)
        audit(tx,user,'AI_ACTION_PROPOSED',proposal['id'],body.action)
        return public(proposal)
    return commit(db.transaction())


def public(row):
    return {k:row.get(k) for k in ('id','action','target','parameters','before','label','state','expires')}


def claim(user, proposal_id, confirm):
    from .. import main as m
    db = m.store(); ref = db.collection('ai_proposals').document(user['id'])
    @firestore.transactional
    def commit(tx):
        authorize(user,tx)
        row = ref.get(transaction=tx).to_dict() or {}
        if row.get('id') != str(proposal_id) or row.get('owner') != user['id']:
            raise service.AIError('Предложение не найдено.',404)
        if row.get('state') != 'pending':
            raise service.AIError('Операция уже подтверждена, отменена или завершена. Не повторяйте её без проверки результата.',409)
        if row.get('expires',0) < time.time():
            raise service.AIError('Подтверждение устарело. Подготовьте операцию заново.',409)
        spec, _ = validate(ProposalIn(action=row['action'],target=row['target'],parameters=row['parameters']))
        if confirm:
            data, _ = snapshot(spec,row['target'],tx)
            if digest(data) != row['fingerprint']:
                raise service.AIError('Объект изменился. Подготовьте новое предложение и проверьте изменения.',409)
        row['state'] = 'executing' if confirm else 'cancelled'
        tx.set(ref,row)
        audit(tx,user,'AI_ACTION_CONFIRMED' if confirm else 'AI_ACTION_CANCELLED',row['id'],row['action'])
        return row
    return commit(db.transaction())


def finish(user,row,state):
    from .. import main as m
    db=m.store(); ref=db.collection('ai_proposals').document(user['id'])
    @firestore.transactional
    def commit(tx):
        current=ref.get(transaction=tx).to_dict() or {}
        if current.get('id') != row['id'] or current.get('state') != 'executing':
            raise service.AIError('Проверьте результат операции вручную.',409)
        tx.update(ref,{'state':state})
        audit(tx,user,'AI_ACTION_'+state.upper(),row['id'],row['action'])
    commit(db.transaction())


def install(app):
    from .. import main as m

    def admin(user=Depends(m.current_user)):
        try:
            authorize(user)
        except service.AIError as exc:
            raise HTTPException(exc.status,exc.message) from None
        return user

    @app.get('/api/v1/ai/admin/catalog')
    def catalog(response:Response,user=Depends(admin)):
        response.headers['Cache-Control']='no-store'
        return {'actions':[{'key':k,'label':v[0],'collection':v[3],'schema':v[4].model_json_schema()}
                           for k,v in registry().items()], 'confirmation':'all_writes'}

    @app.get('/api/v1/ai/admin/targets/{action}')
    def targets(action:str,response:Response,user=Depends(admin)):
        response.headers['Cache-Control']='no-store'
        spec=registry().get(action)
        if not spec: raise HTTPException(404,'Неизвестная операция')
        collection=spec[3]
        if collection in (None,'settings'): return {'items':[],'limited':False}
        if collection=='roles': return {'items':[{'id':k,'label':v} for k,v in m.ROLE_LABELS.items()],'limited':False}
        rows=list(m.store().collection(collection).limit(101).stream())
        items=[]
        for row in rows[:100]:
            data=row.to_dict()
            items.append({'id':row.id,'label':str(data.get('full_name') or data.get('title') or data.get('name') or row.id)[:180],
                          'status':str(data.get('status',''))[:30]})
        return {'items':items,'limited':len(rows)>100}

    @app.get('/api/v1/ai/admin/proposal')
    def pending(response:Response,user=Depends(admin)):
        response.headers['Cache-Control']='no-store'
        row=m.store().collection('ai_proposals').document(user['id']).get().to_dict() or {}
        return {'proposal':public(row) if row else None}

    @app.get('/api/v1/ai/admin/summary')
    def summary(response:Response,user=Depends(admin)):
        response.headers['Cache-Control']='no-store'
        result={}
        for collection in ('users','projects','applications','system_errors'):
            rows=list(m.store().collection(collection).limit(101).stream())
            # Counts only: no names, document IDs, timestamps, free-text labels,
            # errors or other fields can enter the model context through this API.
            result[collection]={'sample_count':min(len(rows),100),'truncated':len(rows)>100}
        m.audit(user['id'],'AI_SUMMARY_READ','ai',details={'limit_per_collection':100})
        return {'scope':'bounded_sample_not_total','collections':result}

    @app.post('/api/v1/ai/admin/prepare')
    def propose(body:ProposalIn,user=Depends(admin)):
        try: return prepare(user,body)
        except Exception as exc: return failure(exc)

    @app.post('/api/v1/ai/admin/proposals/{proposal_id}/decision')
    async def decision(proposal_id:UUID,body:Decision,request:Request,user=Depends(admin)):
        try:
            row=await run_in_threadpool(claim,user,proposal_id,body.confirm)
            if not body.confirm: return {'state':'cancelled'}
            spec=registry()[row['action']]
            # Invoke the ORIGINAL routes with the CURRENT session. Their RBAC,
            # validations, capacity checks and lifecycle rules still apply.
            try:
                async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://internal',
                        cookies={m.SESSION_COOKIE_NAME:request.cookies.get(m.SESSION_COOKIE_NAME,'')}) as client:
                    result=await client.request(spec[1],'/api/v1'+spec[2].format(target=row['target']),
                        json=row['parameters'])
                state='completed' if result.is_success else ('unknown' if result.status_code>=500 else 'rejected')
                status_code=result.status_code
            except Exception:
                state='unknown'
                status_code=503
            await run_in_threadpool(finish,user,row,state)
            # Never forward endpoint bodies (may contain personal data) to Gemini.
            reasons={401:'Сессия завершилась.',403:'Недостаточно прав для этой операции.',404:'Объект не найден.',
                409:'Операция конфликтует с текущим состоянием или ограничениями платформы.',
                422:'Параметры не прошли проверку правил платформы.',429:'Достигнут лимит запросов.'}
            return {'state':state,'http_status':status_code,'detail':'Готово.' if state=='completed' else
                reasons.get(status_code,'Результат неизвестен. Проверьте объект вручную. Автоповтора не будет.')}
        except Exception as exc: return failure(exc)

    @app.post('/api/v1/ai/admin/draft')
    async def draft(body:DraftIn,user=Depends(admin)):
        reserved=False
        try:
            if not service.ready(): raise service.AIError('AI выключен или не настроен.')
            if not body.privacy_confirmed: raise service.AIError('Подтвердите отсутствие личных и секретных данных.',422)
            spec=registry().get(body.action)
            if not spec: raise service.AIError('Неизвестная операция.',422)
            body.message=service.sanitize(body.message.strip())
            if not body.message: raise service.AIError('Введите задачу без персональных данных.',422)
            # A dedicated conversation owned by caller. Binding the action into
            # request identity prevents replay across different action schemas.
            body.message='Operation '+body.action+'\n'+body.message
            reservation=await run_in_threadpool(operate,user,'reserve',body,None,'draft')
            if 'answer' in reservation: return {'parameters':json.loads(reservation['answer'])}
            reserved=True
            schema=spec[4].model_json_schema()
            result=await service.generate_draft(body.message,schema)
            await run_in_threadpool(authorize,user)
            await run_in_threadpool(operate,user,'finish',body,json.dumps(result,ensure_ascii=False),'draft')
            return {'parameters':result}
        except Exception as exc:
            if reserved:
                try: await run_in_threadpool(operate,user,'fail',body,None,'draft')
                except Exception: pass
            return failure(exc)

    @app.post('/api/v1/ai/admin/draft/history')
    def draft_history(user=Depends(admin)):
        try: return operate(user,'new',channel='draft')
        except Exception as exc: return failure(exc)

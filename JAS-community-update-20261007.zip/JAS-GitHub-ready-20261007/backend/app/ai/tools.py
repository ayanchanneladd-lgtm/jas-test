"""Direct model tools remain disabled; approved operations live in admin.py.

Before registering anything: strict schema, AI and source permissions, resource
scope, bounded reads, synthetic/sanitized output and metadata audit are required.
Never register eval, shell, raw database queries, filesystem or arbitrary URLs.
"""
from types import MappingProxyType
from .service import AIError

REGISTRY = MappingProxyType({})


def call_tool(name, arguments, user):
    # Not exposed to Gemini or HTTP. Adding a name alone cannot enable a tool.
    raise AIError('Прямой вызов запрещён. Используйте режим управления с подтверждением.', 403)

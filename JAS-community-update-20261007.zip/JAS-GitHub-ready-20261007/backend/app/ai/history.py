"""Bounded private history and shared transactional admission control."""
import hashlib
import json
import time
from datetime import datetime, timezone
from uuid import uuid4
from firebase_admin import firestore
from .service import AIError


def operate(user, operation, body=None, answer=None, channel='chat'):
    from .. import main as m
    db = m.store()
    uid = user['id']
    ref = db.collection({'chat':'ai_history','draft':'ai_draft_history'}[channel]).document(uid)
    global_ref = db.collection('ai_limits').document('global')
    user_ref = db.collection('ai_limits').document(m.h(uid))
    stamp = time.time()

    @firestore.transactional
    def commit(tx):
        history = ref.get(transaction=tx).to_dict() or {}
        expired = history.get('expires', 0) < stamp
        if expired:
            history = {'conversation_id': str(uuid4()), 'messages': [], 'expires': stamp + 2592000,
                       'expires_at': datetime.fromtimestamp(stamp + 2592000, timezone.utc)}
        if operation == 'get':
            return {'conversation_id': history['conversation_id'] if not expired else None,
                    'messages': history['messages']}
        if operation == 'new':
            history = {'conversation_id': str(uuid4()), 'messages': [], 'expires': stamp + 2592000,
                       'expires_at': datetime.fromtimestamp(stamp + 2592000, timezone.utc)}
            tx.set(ref, history)
            tx.set(db.collection('audit_logs').document(), {'user_id': uid, 'action': 'AI_HISTORY_CLEARED',
                'entity': 'ai', 'created_at': m.now(), 'details': {}})
            return {'conversation_id': history['conversation_id'], 'messages': []}
        if history['conversation_id'] != str(body.conversation_id):
            raise AIError('Диалог изменился. Обновите историю.', 409)
        request_ref = db.collection('ai_requests').document(m.h(uid + str(body.request_id)))
        request = request_ref.get(transaction=tx).to_dict() or {}
        global_state = global_ref.get(transaction=tx).to_dict() or {}
        user_state = user_ref.get(transaction=tx).to_dict() or {}
        fingerprint = hashlib.sha256((channel + str(body.conversation_id) + body.message).encode()).hexdigest()
        active = {k: v for k, v in global_state.get('active', {}).items() if v > stamp}
        if operation == 'reserve':
            if request:
                if request.get('fingerprint') != fingerprint:
                    raise AIError('Идентификатор запроса уже использован.', 409)
                if request.get('state') == 'complete':
                    for item in history['messages']:
                        if item.get('request_id') == str(body.request_id) and item['role'] == 'model':
                            return {'answer': item['text'], 'replayed': True}
                raise AIError('Запрос уже обрабатывался. Обновите историю; автоматического повтора нет.', 409)
            if history.get('pending_until', 0) > stamp or len(active) >= 2:
                raise AIError('AI занят. Попробуйте позже.', 429)
            for state, rpm, daily in ((user_state, 3, 20), (global_state, 10, 100)):
                state['recent'] = [x for x in state.get('recent', []) if x > stamp - 60]
                if state.get('day') != int(stamp // 86400):
                    state.update(day=int(stamp // 86400), count=0)
                if len(state['recent']) >= rpm or state.get('count', 0) >= daily:
                    raise AIError('Лимит AI достигнут. Попробуйте позже.', 429)
                state['recent'].append(stamp)
                state['count'] = state.get('count', 0) + 1
            active[request_ref.id] = stamp + 120
            global_state['active'] = active
            history.update(pending=str(body.request_id), pending_until=stamp + 120)
            tx.set(global_ref, global_state)
            tx.set(user_ref, user_state)
            tx.set(ref, history)
            tx.set(request_ref, {'fingerprint': fingerprint, 'state': 'pending', 'created_at': stamp,
                                'expires_at': datetime.fromtimestamp(stamp + 2592000, timezone.utc)})
            tx.set(db.collection('audit_logs').document(), {'user_id': uid, 'action': 'AI_CHAT_REQUEST',
                'entity': 'ai', 'created_at': m.now(), 'details': {'request_id': str(body.request_id)}})
            # Whole turns only, context bounded independently of stored history.
            context = history['messages'][-6:]
            while context and sum(len(x['text']) for x in context) > 12000:
                context = context[2:]
            return {'messages': context + [{'role': 'user', 'text': body.message}]}
        # Finish never recreates a deleted/new conversation, including late results.
        if history.get('pending') != str(body.request_id) or request.get('state') != 'pending':
            raise AIError('Запрос больше не активен.', 409)
        if operation == 'finish':
            current = db.collection('users').document(uid).get(transaction=tx).to_dict() or {}
            roles = db.collection('system_config').document('roles').get(transaction=tx).to_dict() or {}
            perms = roles.get('roles', {}).get(current.get('role'), m.PERMISSIONS.get(current.get('role'), set()))
            if (not current.get('active') or current.get('session_version', 0) != user.get('session_version', 0)
                    or not ('*' in perms or {'ai.access', 'ai.chat'}.issubset(perms))):
                raise AIError('Доступ к AI изменился.', 403)
            history['messages'].extend([{'role': 'user', 'text': body.message, 'request_id': str(body.request_id)},
                                       {'role': 'model', 'text': answer, 'request_id': str(body.request_id)}])
            history['messages'] = history['messages'][-20:]
            while len(json.dumps(history['messages'], ensure_ascii=False).encode()) > 60000:
                history['messages'] = history['messages'][2:]
        history.update(pending=None, pending_until=0, expires=stamp + 2592000,
                       expires_at=datetime.fromtimestamp(stamp + 2592000, timezone.utc))
        active.pop(request_ref.id, None)
        global_state['active'] = active
        tx.set(global_ref, global_state)
        tx.set(ref, history)
        tx.set(request_ref, {**request, 'state': 'complete' if operation == 'finish' else 'failed'})
        tx.set(db.collection('audit_logs').document(), {'user_id': uid,
            'action': 'AI_CHAT_COMPLETED' if operation == 'finish' else 'AI_CHAT_FAILED',
            'entity': 'ai', 'created_at': m.now(), 'details': {'request_id': str(body.request_id)}})
        return {'answer': answer}

    return commit(db.transaction())

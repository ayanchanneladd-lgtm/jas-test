from uuid import UUID
from fastapi import Depends, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from starlette.concurrency import run_in_threadpool
from . import service
from .history import operate
from .commands import parse as parse_command


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: UUID
    conversation_id: UUID
    message: str = Field(min_length=1, max_length=4000)
    privacy_confirmed: bool = False


def failure(exc):
    if not isinstance(exc, service.AIError):
        exc = service.AIError('AI временно недоступен. Обратитесь к разработчику.')
    return JSONResponse({'detail': exc.message, 'code': 'ai_error'}, status_code=exc.status,
                        headers={'Cache-Control':'no-store', **({'Retry-After': '60'} if exc.status == 429 else {})})


def install(app):
    from .. import main as m
    access = m.require('ai.access')
    chat_access = m.require('ai.chat')

    @app.get('/api/v1/ai/status')
    def status(response: Response, user=Depends(access)):
        response.headers['Cache-Control'] = 'no-store'
        return {'ready': service.ready(), 'tools_enabled': False,
                'management_available': user.get('role') == 'super_admin' and
                    ('*' in user.get('permissions',[]) or 'ai.admin' in user.get('permissions',[])),
                'coming_soon': service.FEATURES, 'max_prompt': 4000,
                'user_rpm': 3, 'user_daily': 20, 'global_rpm': 10, 'global_daily': 100}

    @app.get('/api/v1/ai/history')
    def history(response: Response, user=Depends(access)):
        response.headers['Cache-Control'] = 'no-store'
        try:
            return operate(user, 'get')
        except Exception as exc:
            return failure(exc)

    @app.post('/api/v1/ai/history/new')
    @app.delete('/api/v1/ai/history')
    def clear(response: Response, user=Depends(access)):
        response.headers['Cache-Control'] = 'no-store'
        try:
            return operate(user, 'new')
        except Exception as exc:
            return failure(exc)

    @app.post('/api/v1/ai/chat')
    async def chat(body: ChatRequest, response: Response, user=Depends(access), permitted=Depends(chat_access)):
        response.headers['Cache-Control'] = 'no-store'
        reserved = False
        try:
            if not body.privacy_confirmed or not body.message.strip():
                raise service.AIError('Подтвердите отсутствие персональных и конфиденциальных данных.', 422)
            body.message = service.sanitize(body.message.strip())
            command = parse_command(body.message)
            if command:
                from .admin import authorize, prepare, ProposalIn
                await run_in_threadpool(authorize, user)
            elif not service.ready():
                raise service.AIError('AI выключен или не настроен администратором.')
            result = await run_in_threadpool(operate, user, 'reserve', body)
            if 'answer' in result:
                return result
            reserved = True
            if command:
                if 'help' in command:
                    answer = command['help']
                else:
                    await run_in_threadpool(prepare, user, ProposalIn(**command))
                    if command['action'] == 'maintenance.start':
                        answer = ('Подготовлено закрытие сайта. Ориентировочный срок: ' + str(command['parameters']['hours']) +
                                  ' ч. Причина: Технические работы. Настройки ещё не изменены. '
                                  'Проверь карточку действия и нажми «Подтвердить и выполнить».')
                    else:
                        answer = 'Подготовлено открытие сайта. Подтверди действие в карточке ниже. Пока настройки не изменены.'
            else:
                answer = await service.generate(result['messages'])
            return await run_in_threadpool(operate, user, 'finish', body, answer)
        except Exception as exc:
            if reserved:
                try:
                    await run_in_threadpool(operate, user, 'fail', body)
                except Exception:
                    pass  # Lease expires; no raw exception enters system error logs.
            return failure(exc)

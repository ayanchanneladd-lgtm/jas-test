"""Bounded, thread-safe, process-local sliding-window limits for a single worker."""
import math
import os
import time
from collections import deque
from threading import Lock

from starlette.responses import JSONResponse


def positive_env(name, default):
    value = int(os.getenv(name, str(default)))
    if value < 1:
        raise ValueError(name + " must be positive")
    return value


class RateLimiter:
    def __init__(self, rules=None, clock=time.monotonic, max_keys=20000):
        self.rules = rules if rules is not None else {
            "api": (positive_env("RATE_LIMIT_API_PER_MINUTE", 300), 60),
            "write": (positive_env("RATE_LIMIT_WRITES_PER_MINUTE", 60), 60),
            "login": (positive_env("RATE_LIMIT_LOGIN_PER_5_MINUTES", 10), 300),
            "register": (positive_env("RATE_LIMIT_REGISTER_PER_HOUR", 5), 3600),
            "security": (positive_env("RATE_LIMIT_SECURITY_PER_5_MINUTES", 10), 300),
        }
        self.clock, self.max_keys = clock, max_keys
        self.buckets = {}
        self.lock = Lock()
        self.last_cleanup = 0

    def check(self, address, groups):
        with self.lock:
            now = self.clock()
            if now - self.last_cleanup >= 60 or len(self.buckets) + len(groups) > self.max_keys:
                for key in list(self.buckets):
                    entries = self.buckets[key]
                    if not entries or entries[-1] <= now - self.rules[key[1]][1]:
                        del self.buckets[key]
                self.last_cleanup = now
            retry = 0
            for group in groups:
                limit, window = self.rules[group]
                entries = self.buckets.get((address, group))
                if entries is not None:
                    while entries and entries[0] <= now - window:
                        entries.popleft()
                    if len(entries) >= limit:
                        retry = max(retry, math.ceil(entries[0] + window - now))
            if retry:
                return max(1, retry)
            missing = sum((address, group) not in self.buckets for group in groups)
            if len(self.buckets) + missing > self.max_keys:
                # Do not evict live limits, which would allow a flood to reset them.
                return 60
            for group in groups:
                self.buckets.setdefault((address, group), deque()).append(now)
            return 0


class RateLimitMiddleware:
    def __init__(self, app, limiter=None):
        self.app = app
        self.limiter = limiter if limiter is not None else RateLimiter()

    async def __call__(self, scope, receive, send):
        path = scope.get("path", "").rstrip("/")
        method = scope.get("method", "")
        if scope["type"] != "http" or method == "OPTIONS" or not path.startswith("/api/v1/"):
            return await self.app(scope, receive, send)
        groups = ["api"]
        if method not in {"GET", "HEAD"}:
            groups.append("write")
        if path == "/api/v1/auth/login":
            groups.append("login")
        elif path == "/api/v1/auth/register":
            groups.append("register")
        elif path in {"/api/v1/profile/password", "/api/v1/profile/logout-all"}:
            groups.append("security")
        # Never trust client-supplied X-Forwarded-For here. ASGI server/proxy
        # forwarding must be configured to trust ONLY the actual reverse proxy.
        client = scope.get("client")
        address = client[0] if client else "unknown"
        retry = self.limiter.check(address, groups)
        if retry:
            response = JSONResponse(
                {"detail": f"Слишком много запросов. Повторите через {retry} сек.",
                 "code": "rate_limited", "retry_after": retry},
                status_code=429,
                headers={"Retry-After": str(retry), "Cache-Control": "no-store"},
            )
            return await response(scope, receive, send)
        await self.app(scope, receive, send)

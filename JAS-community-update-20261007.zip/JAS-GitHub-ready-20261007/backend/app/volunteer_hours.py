"""One current award per volunteer/project, with immutable history and corrections."""
import hashlib
import json
from typing import Annotated
from uuid import uuid4

from fastapi import Depends, HTTPException, Query
from firebase_admin import firestore
from pydantic import BaseModel, ConfigDict, Field, field_validator


class Award(BaseModel):
    model_config = ConfigDict(extra="forbid")
    minutes: int = Field(strict=True, ge=1, le=1440)
    reason: str = Field(min_length=3, max_length=500)

    @field_validator("reason", mode="before")
    @classmethod
    def trim(cls, value):
        return value.strip() if isinstance(value, str) else value


class Correction(Award):
    minutes: int = Field(strict=True, ge=0, le=1440)
    expected_version: int = Field(strict=True, ge=1)


def award_key(user_id, project_id):
    return hashlib.sha256(json.dumps([user_id, project_id]).encode()).hexdigest()


def write_award(client, tx, ref, account_ref, account, record):
    record.setdefault('version', 1)
    key = ref.id
    stamp = record["created_at"]
    minutes = record["minutes"]
    reason = record["reason"]
    recipient_id = record["user_id"]
    project_id = record["project_id"]
    actor_id = record["granted_by"]
    tx.set(ref, record)
    tx.set(account_ref, {"total_minutes": account.get("total_minutes", 0) + minutes,
                        "project_count": account.get("project_count", 0) + 1, "updated_at": stamp})
    tx.set(account_ref.collection("history").document(key), record)
    tx.set(client.collection("notifications").document(), {
        "audience": "user", "user_id": recipient_id, "type": "HOURS_CONFIRMED",
        "title": "Начислены волонтёрские часы",
        "message": f'{record["project_title"]}: {minutes // 60} ч {minutes % 60} мин. {reason}',
        "related_resource_type": "volunteer_hours", "related_resource_id": key, "created_at": stamp,
    })
    tx.set(client.collection("audit_logs").document(), {
        "user_id": actor_id, "action": "hours.grant", "entity": "volunteer_hours",
        "entity_id": key, "created_at": stamp,
        "details": {"recipient_id": recipient_id, "project_id": project_id,
                    "minutes": minutes, "reason": reason},
    })


def grant(application_id, body, session_user):
    from . import main as m
    client = m.store()

    @firestore.transactional
    def commit(tx):
        # Recheck current identity, permission and scope within the write transaction.
        actor = client.collection("users").document(session_user["id"]).get(transaction=tx).to_dict() or {}
        roles = client.collection("system_config").document("roles").get(transaction=tx).to_dict() or {}
        if not actor.get("active") or actor.get("session_version", 0) != session_user.get("session_version", 0):
            raise HTTPException(401, "Сессия завершена. Войдите снова")
        allowed = roles.get("roles", {}).get(actor.get("role"), m.PERMISSIONS.get(actor.get("role"), set()))
        if "*" not in allowed and "hours.manage" not in allowed:
            raise HTTPException(403, "Нет права начислять часы")
        application = client.collection("applications").document(application_id).get(transaction=tx)
        if not application.exists:
            raise HTTPException(404, "Заявка не найдена")
        row = application.to_dict()
        project = client.collection("projects").document(row["project_id"]).get(transaction=tx)
        if not project.exists:
            raise HTTPException(404, "Проект не найден")
        m.require_project_scope(project.to_dict(), actor)
        if row["user_id"] == session_user["id"]:
            raise HTTPException(403, "Нельзя начислять часы самому себе")
        if row.get("status") != "completed" or project.to_dict().get("status") != "completed":
            raise HTTPException(409, "Нужны завершённый проект и подтверждённое участие")
        recipient = client.collection("users").document(row["user_id"]).get(transaction=tx)
        if not recipient.exists or not recipient.to_dict().get("active"):
            raise HTTPException(409, "Аккаунт участника недоступен")
        key = award_key(row["user_id"], row["project_id"])
        ref = client.collection("volunteer_hours").document(key)
        if ref.get(transaction=tx).exists:
            raise HTTPException(409, "Часы за этот проект уже начислены. Повторное начисление запрещено")
        account_ref = client.collection("volunteer_hour_accounts").document(row["user_id"])
        account = account_ref.get(transaction=tx).to_dict() or {}
        stamp = m.now()
        record = {
            "user_id": row["user_id"], "project_id": row["project_id"],
            "application_id": application_id, "project_title": project.to_dict().get("title", "Проект"),
            "minutes": body.minutes, "reason": body.reason, "status": "confirmed",
            "granted_by": session_user["id"], "granted_by_name": actor.get("full_name", "Руководитель"),
            "created_at": stamp,
        }
        write_award(client, tx, ref, account_ref, account, record)
        return {"id": key, **record}

    return commit(client.transaction())


def correct(application_id, body, session_user):
    from . import main as m
    client = m.store()

    @firestore.transactional
    def commit(tx):
        actor = client.collection('users').document(session_user['id']).get(transaction=tx).to_dict() or {}
        config = client.collection('system_config').document('roles').get(transaction=tx).to_dict() or {}
        if not actor.get('active') or actor.get('session_version', 0) != session_user.get('session_version', 0):
            raise HTTPException(401, 'Сессия завершена')
        allowed = config.get('roles', {}).get(actor.get('role'), m.PERMISSIONS.get(actor.get('role'), set()))
        if '*' not in allowed and 'hours.manage' not in allowed:
            raise HTTPException(403, 'Нет права исправлять часы')
        application = client.collection('applications').document(application_id).get(transaction=tx)
        if not application.exists:
            raise HTTPException(404, 'Заявка не найдена')
        row = application.to_dict()
        project = client.collection('projects').document(row['project_id']).get(transaction=tx)
        if not project.exists:
            raise HTTPException(404, 'Проект не найден')
        m.require_project_scope(project.to_dict(), actor)
        if row['user_id'] == session_user['id']:
            raise HTTPException(403, 'Нельзя исправлять собственные часы')
        if row.get('status') != 'completed' or project.to_dict().get('status') != 'completed':
            raise HTTPException(409, 'Нужны завершённый проект и подтверждённое участие')
        ref = client.collection('volunteer_hours').document(award_key(row['user_id'], row['project_id']))
        snapshot = ref.get(transaction=tx)
        if not snapshot.exists:
            raise HTTPException(404, 'Начисление не найдено')
        previous = snapshot.to_dict()
        version = previous.get('version', 1)
        if body.expected_version != version:
            raise HTTPException(409, 'Часы уже изменены другим руководителем. Закройте окно и откройте его заново')
        old_minutes = previous['minutes']
        if old_minutes == body.minutes:
            raise HTTPException(409, 'Новое количество часов совпадает с текущим')
        account_ref = client.collection('volunteer_hour_accounts').document(row['user_id'])
        account = account_ref.get(transaction=tx).to_dict() or {}
        if not account or account.get('total_minutes', 0) < old_minutes or account.get('project_count', 0) < int(old_minutes > 0):
            raise HTTPException(409, 'Итог часов несогласован. Обратитесь к администратору')
        stamp = m.now()
        change = {'minutes': body.minutes, 'reason': body.reason, 'version': version + 1,
                  'updated_at': stamp, 'corrected_by': session_user['id'],
                  'corrected_by_name': actor.get('full_name', 'Руководитель'), 'status': 'corrected'}
        event_id = hashlib.sha256((ref.id + uuid4().hex).encode()).hexdigest()
        event = {**previous, **change, 'record_id': ref.id, 'previous_minutes': old_minutes,
                 'delta_minutes': body.minutes - old_minutes, 'created_at': stamp,
                 'granted_by': session_user['id'], 'granted_by_name': actor.get('full_name', 'Руководитель')}
        tx.update(ref, change)
        tx.update(account_ref, {'total_minutes': account['total_minutes'] + body.minutes - old_minutes,
                  'project_count': account.get('project_count', 0) + int(body.minutes > 0) - int(old_minutes > 0),
                  'updated_at': stamp})
        tx.set(account_ref.collection('history').document(event_id), event)
        tx.set(client.collection('notifications').document(), {
            'audience': 'user', 'user_id': row['user_id'], 'type': 'HOURS_CORRECTED',
            'title': 'Волонтёрские часы исправлены',
            'message': f'{previous["project_title"]}: {old_minutes // 60} ч {old_minutes % 60} мин → {body.minutes // 60} ч {body.minutes % 60} мин. Причина: {body.reason}',
            'related_resource_type': 'volunteer_hours', 'related_resource_id': ref.id, 'created_at': stamp})
        tx.set(client.collection('audit_logs').document(), {
            'user_id': session_user['id'], 'action': 'hours.correct', 'entity': 'volunteer_hours',
            'entity_id': ref.id, 'created_at': stamp,
            'details': {'recipient_id': row['user_id'], 'project_id': row['project_id'],
                        'previous_minutes': old_minutes, 'minutes': body.minutes,
                        'reason': body.reason, 'version': version + 1}})
        return {'id': ref.id, **previous, **change}
    return commit(client.transaction())


def install(app):
    from . import main as m

    @app.post("/api/v1/applications/{application_id}/hours", status_code=201)
    def award_hours(application_id: str, body: Award, user=Depends(m.require("hours.manage"))):
        return grant(application_id, body, user)

    @app.patch('/api/v1/applications/{application_id}/hours')
    def correct_hours(application_id: str, body: Correction, user=Depends(m.require('hours.manage'))):
        return correct(application_id, body, user)

    @app.get("/api/v1/applications/{application_id}/hours")
    def application_hours(application_id: str, user=Depends(m.require("hours.manage"))):
        client = m.store()
        application = client.collection("applications").document(application_id).get()
        if not application.exists:
            raise HTTPException(404, "Заявка не найдена")
        row = application.to_dict()
        project = client.collection("projects").document(row["project_id"]).get()
        if not project.exists:
            raise HTTPException(404, "Проект не найден")
        m.require_project_scope(project.to_dict(), user)
        recipient = client.collection("users").document(row["user_id"]).get().to_dict() or {}
        record = client.collection("volunteer_hours").document(award_key(row["user_id"], row["project_id"])).get()
        return {"record": m.as_dict(record) if record.exists else None,
                "project_title": project.to_dict().get("title", "Проект"),
                "participant_name": recipient.get("full_name", "Участник"),
                "can_correct": row["user_id"] != user["id"] and row.get("status") == "completed"
                    and project.to_dict().get("status") == "completed" and record.exists,
                "can_award": row["user_id"] != user["id"] and row.get("status") == "completed"
                    and project.to_dict().get("status") == "completed" and bool(recipient.get("active"))}

    @app.get("/api/v1/my/hours")
    def my_hours(limit: Annotated[int, Query(ge=1, le=50)] = 20,
                 cursor: Annotated[str | None, Query(pattern=r"^[a-f0-9]{64}$")] = None,
                 user=Depends(m.current_user)):
        account_ref = m.store().collection("volunteer_hour_accounts").document(user["id"])
        account = account_ref.get().to_dict() or {}
        history = account_ref.collection("history")
        query = history.order_by("created_at", direction=firestore.Query.DESCENDING)
        if cursor:
            snapshot = history.document(cursor).get()
            if not snapshot.exists:
                raise HTTPException(400, "Страница истории устарела. Обновите список")
            query = query.start_after(snapshot)
        rows = list(query.limit(limit + 1).stream())
        return {"total_minutes": account.get("total_minutes", 0),
                "project_count": account.get("project_count", 0),
                "items": [m.as_dict(row) for row in rows[:limit]],
                "next_cursor": rows[limit - 1].id if len(rows) > limit else None}

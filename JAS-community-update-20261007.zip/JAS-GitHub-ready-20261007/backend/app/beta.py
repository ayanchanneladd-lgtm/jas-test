"""BETA workflows. All mutations use the existing server-side authorization."""
from collections import Counter
from datetime import datetime, timezone
from fastapi import Depends, HTTPException
from pydantic import BaseModel, Field
from firebase_admin import firestore
from . import main as m


def change_project_status(project_id, status, user, reason=""):
    client = m.store()
    ref = client.collection("projects").document(project_id)
    if status == "deleted" and len(reason.strip()) < 5:
        raise HTTPException(422, "Укажите причину, минимум 5 символов")
    @firestore.transactional
    def commit(tx):
        snap = ref.get(transaction=tx)
        if not snap.exists:
            raise HTTPException(404, "Проект не найден")
        data = snap.to_dict()
        m.require_project_scope(data, user)
        if data.get("status") == "deleted" or status == "completed" and data.get("status") != "active":
            raise HTTPException(409, "Статус проекта уже изменён")
        changes = {"status": status, status + "_at": m.now(), status + "_by": user["id"]}
        if status == "deleted":
            changes.update(deletion_reason=reason.strip(), previous_status=data.get("status"))
        tx.update(ref, changes)
        tx.set(client.collection("audit_logs").document(), {
            "user_id": user["id"], "action": "project." + ("complete" if status == "completed" else "delete"),
            "entity": "project", "entity_id": project_id, "details": reason.strip(), "created_at": m.now()})
    commit(client.transaction())
    return {"status": status}


def transition(application_id, status, user, own=False):
    if not own and status in {"completed", "no_show", "excused"}:
        from .attendance import AttendanceBatch, mark_attendance
        m.require("attendance.manage")(user)
        snapshot = m.store().collection("applications").document(application_id).get()
        if not snapshot.exists:
            raise HTTPException(404, "Заявка не найдена")
        mark_attendance(snapshot.to_dict()["project_id"], AttendanceBatch(items=[
            {"application_id": application_id, "status": status}]), user)
        return {"status": status}
    client = m.store()
    ref = client.collection("applications").document(application_id)
    event_ref = client.collection("application_events").document()
    notice_ref = client.collection("notifications").document()
    audit_ref = client.collection("audit_logs").document()

    @firestore.transactional
    def commit(tx):
        snapshot = ref.get(transaction=tx)
        if not snapshot.exists:
            raise HTTPException(404, "Заявка не найдена")
        data = snapshot.to_dict()
        project_ref = client.collection("projects").document(data["project_id"])
        project = project_ref.get(transaction=tx)
        if not project.exists:
            raise HTTPException(404, "Проект не найден")
        p = project.to_dict()
        if own:
            if data["user_id"] != user["id"]:
                raise HTTPException(403, "Это не ваша заявка")
            if status != "cancelled" or data["status"] not in {"pending", "accepted"}:
                raise HTTPException(409, "Эту заявку уже нельзя отменить")
            if data["status"] == "accepted" and p.get("status") == "completed":
                raise HTTPException(409, "Проект завершён: участие должен отметить координатор")
        else:
            m.require_project_scope(p, user)
            allowed = {"pending": {"accepted", "rejected"}, "accepted": {"completed", "no_show"}}
            if status not in allowed.get(data["status"], set()):
                raise HTTPException(409, "Недопустимый переход статуса")
            if status == "accepted" and p.get("status") != "active":
                raise HTTPException(409, "Проект больше не принимает участников")
            if status in {"completed", "no_show"} and p.get("status") != "completed":
                raise HTTPException(409, "Сначала завершите проект, затем отметьте участие")
        count = p.get("accepted_count", 0)
        if status == "accepted":
            if count >= p["capacity"]:
                raise HTTPException(409, "Свободных мест больше нет")
            tx.update(project_ref, {"accepted_count": count + 1})
        elif status == "cancelled" and data["status"] == "accepted":
            tx.update(project_ref, {"accepted_count": max(0, count - 1)})
        stamp = m.now()
        tx.update(ref, {"status": status, "reviewed_by": user["id"], "updated_at": stamp})
        tx.set(event_ref, {"application_id": application_id, "user_id": data["user_id"],
                          "from_status": data["status"], "status": status, "actor_id": user["id"], "created_at": stamp})
        labels = {"accepted": "принята", "rejected": "отклонена", "completed": "участие подтверждено",
                  "no_show": "отмечено отсутствие", "cancelled": "отменена"}
        tx.set(notice_ref, {"audience": "user", "user_id": data["user_id"], "title": "Статус заявки обновлён",
                           "message": p.get("title", "Проект") + ": " + labels[status],
                           "application_id": application_id, "created_at": stamp})
        tx.set(audit_ref, {"user_id": user["id"], "action": "application." + status, "entity": "application",
                          "entity_id": application_id, "created_at": stamp})
    commit(client.transaction())
    return {"status": status}


def visible_notice(data, user):
    return (data.get("audience") == "all" or
            data.get("audience") == "role" and data.get("role") == user["role"] or
            data.get("audience") == "user" and data.get("user_id") == user["id"])


class Named(BaseModel):
    name: str = Field(min_length=2, max_length=120)


def install(app):
    @app.post("/api/v1/my/applications/{application_id}/cancel")
    def cancel(application_id: str, user=Depends(m.current_user)):
        return transition(application_id, "cancelled", user, own=True)

    @app.get("/api/v1/applications/{application_id}/history")
    def history(application_id: str, user=Depends(m.current_user)):
        client = m.store()
        snapshot = client.collection("applications").document(application_id).get()
        if not snapshot.exists:
            raise HTTPException(404, "Заявка не найдена")
        data = snapshot.to_dict()
        if data["user_id"] != user["id"]:
            m.require("applications.review")(user)
            project = client.collection("projects").document(data["project_id"]).get()
            if not project.exists:
                raise HTTPException(404, "Проект не найден")
            m.require_project_scope(project.to_dict(), user)
        rows = [m.as_dict(s) for s in client.collection("application_events").where(
            filter=m.FieldFilter("application_id", "==", application_id)).stream()]
        rows.insert(0, {"status": "pending", "created_at": data["created_at"]})
        return sorted(rows, key=lambda row: row["created_at"])

    @app.put("/api/v1/projects/{project_id}")
    def edit_project(project_id: str, body: m.ProjectIn, user=Depends(m.require("projects.manage"))):
        try:
            date = datetime.fromisoformat(body.starts_at.replace("Z", "+00:00"))
            if not date.tzinfo:
                raise ValueError()
        except ValueError:
            raise HTTPException(422, "Укажите дату и часовой пояс")
        client = m.store()
        ref = client.collection("projects").document(project_id)
        @firestore.transactional
        def commit(tx):
            snap = ref.get(transaction=tx)
            category = client.collection("project_categories").document(body.category_id).get(transaction=tx)
            if not snap.exists:
                raise HTTPException(404, "Проект не найден")
            data = snap.to_dict()
            m.require_project_scope(data, user)
            if data.get("status") != "active":
                raise HTTPException(409, "Редактировать можно только активный проект")
            if not category.exists:
                raise HTTPException(422, "Категория не найдена")
            if body.capacity < data.get("accepted_count", 0):
                raise HTTPException(409, "Мест не может быть меньше числа принятых участников")
            changes = body.model_dump()
            changes.update(starts_at=date.astimezone(timezone.utc).isoformat(), updated_at=m.now())
            tx.update(ref, changes)
        commit(client.transaction())
        m.audit(user["id"], "project.update", "project", project_id)
        return {"id": project_id}

    @app.get("/api/v1/my/notifications")
    def notifications(offset: int = 0, user=Depends(m.current_user)):
        client = m.store()
        reads = {s.to_dict()["notification_id"] for s in client.collection("notification_reads").where(
            filter=m.FieldFilter("user_id", "==", user["id"])).stream()}
        rows = [m.as_dict(s) for s in client.collection("notifications").stream() if visible_notice(s.to_dict(), user)]
        rows.sort(key=lambda row: row.get("created_at", ""), reverse=True)
        for row in rows:
            row["read"] = row["id"] in reads
        start = max(0, offset)
        return {"items": rows[start:start+20], "total": len(rows), "unread": sum(not r["read"] for r in rows)}

    @app.post("/api/v1/my/notifications/{notification_id}/read")
    def read_notification(notification_id: str, user=Depends(m.current_user)):
        client = m.store()
        snap = client.collection("notifications").document(notification_id).get()
        if not snap.exists or not visible_notice(snap.to_dict(), user):
            raise HTTPException(404, "Уведомление не найдено")
        client.collection("notification_reads").document(user["id"] + "_" + notification_id).set(
            {"user_id": user["id"], "notification_id": notification_id, "read_at": m.now()})
        return {"read": True}

    # Names can be edited. Deletion is blocked while referenced, preserving history.
    def rename(collection, entity_id, name, user):
        name = name.strip()
        if len(name) < 2:
            raise HTTPException(422, "Название слишком короткое")
        client = m.store()
        ref = client.collection(collection).document(entity_id)
        if not ref.get().exists:
            raise HTTPException(404, "Запись не найдена")
        if any(s.id != entity_id and s.to_dict().get("name", "").casefold() == name.casefold()
               for s in client.collection(collection).stream()):
            raise HTTPException(409, "Такое название уже существует")
        ref.update({"name": name, "updated_at": m.now()})
        m.audit(user["id"], collection + ".update", collection, entity_id)
        return m.as_dict(ref.get())

    def remove(collection, entity_id, relations, user):
        client = m.store()
        ref = client.collection(collection).document(entity_id)
        @firestore.transactional
        def commit(tx):
            if not ref.get(transaction=tx).exists:
                raise HTTPException(404, "Запись не найдена")
            for related, field in relations:
                query = client.collection(related).where(filter=m.FieldFilter(field, "==", entity_id)).limit(1)
                if list(query.stream(transaction=tx)):
                    raise HTTPException(409, "Запись используется: " + related + ". Сначала измените привязки.")
            tx.delete(ref)
        commit(client.transaction())
        m.audit(user["id"], collection + ".delete", collection, entity_id)
        return {"deleted": True}

    @app.patch("/api/v1/admin/departments/{entity_id}")
    def edit_department(entity_id: str, body: Named, user=Depends(m.require("departments.manage"))):
        return rename("departments", entity_id, body.name, user)

    @app.delete("/api/v1/admin/departments/{entity_id}")
    def delete_department(entity_id: str, user=Depends(m.require("departments.manage"))):
        return remove("departments", entity_id, [("users", "department_id"), ("teams", "department_id"), ("projects", "department_id")], user)

    @app.patch("/api/v1/admin/teams/{entity_id}")
    def edit_team(entity_id: str, body: Named, user=Depends(m.require("departments.manage"))):
        return rename("teams", entity_id, body.name, user)

    @app.delete("/api/v1/admin/teams/{entity_id}")
    def delete_team(entity_id: str, user=Depends(m.require("departments.manage"))):
        return remove("teams", entity_id, [("users", "team_id"), ("projects", "team_id")], user)

    @app.post("/api/v1/admin/categories", status_code=201)
    def create_category(body: Named, user=Depends(m.require_super_admin)):
        name = body.name.strip()
        if len(name) < 2:
            raise HTTPException(422, "Название слишком короткое")
        client = m.store()
        if any(s.to_dict().get("name", "").casefold() == name.casefold() for s in client.collection("project_categories").stream()):
            raise HTTPException(409, "Категория уже существует")
        ref = client.collection("project_categories").document()
        ref.set({"name": name, "created_at": m.now()})
        m.audit(user["id"], "category.create", "category", ref.id)
        return m.as_dict(ref.get())

    @app.patch("/api/v1/admin/categories/{entity_id}")
    def edit_category(entity_id: str, body: Named, user=Depends(m.require_super_admin)):
        return rename("project_categories", entity_id, body.name, user)

    @app.delete("/api/v1/admin/categories/{entity_id}")
    def delete_category(entity_id: str, user=Depends(m.require_super_admin)):
        return remove("project_categories", entity_id, [("projects", "category_id")], user)

    @app.get("/api/v1/admin/analytics")
    def analytics(user=Depends(m.require_super_admin)):
        client = m.store()
        users = [s.to_dict() for s in client.collection("users").stream()]
        projects = [m.as_dict(s) for s in client.collection("projects").stream()]
        applications = [s.to_dict() for s in client.collection("applications").stream()]
        return {"users": len(users), "active_users": sum(bool(u.get("active")) for u in users),
                "verified_users": sum(bool(u.get("verified")) for u in users),
                "roles": dict(Counter(u.get("role", "unknown") for u in users)),
                "project_statuses": {**dict.fromkeys(("active","completed","deleted"),0), **Counter(p.get("status", "unknown") for p in projects)},
                "application_statuses": {**dict.fromkeys(("pending","accepted","rejected","completed","cancelled","no_show","excused"),0), **Counter(a.get("status", "unknown") for a in applications)},
                "projects": [{"id": p["id"], "title": p["title"], "capacity": p["capacity"],
                              "reserved": p.get("accepted_count", 0),
                              "applications": sum(a.get("project_id") == p["id"] for a in applications)}
                             for p in projects if p.get("status") != "deleted"]}

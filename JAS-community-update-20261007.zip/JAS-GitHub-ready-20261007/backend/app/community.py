"""Authenticated community chat and coarse presence; no public account data dump."""
from datetime import datetime, timezone
from uuid import UUID

from fastapi import Depends, HTTPException, Query
from firebase_admin import firestore
from pydantic import BaseModel, ConfigDict, Field, field_validator


def seconds_since(value):
    try:
        return (datetime.now(timezone.utc) - datetime.fromisoformat(value)).total_seconds()
    except (ValueError, TypeError):
        return float('inf')


def online(data):
    return 0 <= seconds_since(data.get('last_seen_at')) < 120


def activity_badge(account):
    return account.get('total_minutes', 0) >= 3000 and account.get('project_count', 0) >= 8


def account_status(data, account):
    return {'is_online': online(data), 'active_volunteer': activity_badge(account)}


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra='forbid')
    client_id: UUID
    text: str = Field(min_length=1, max_length=2000)

    @field_validator('text', mode='before')
    @classmethod
    def trim(cls, value):
        return value.strip() if isinstance(value, str) else value


def checked_actor(client, tx, user):
    from . import main as m
    ref = client.collection('users').document(user['id'])
    actor = ref.get(transaction=tx).to_dict() or {}
    if not actor.get('active') or actor.get('session_version', 0) != user.get('session_version', 0):
        raise HTTPException(401, 'Сессия завершена. Войдите снова')
    return ref, actor


def install(app):
    from . import main as m

    @app.get('/api/v1/community/status')
    def statuses(ids: str = Query(..., max_length=2400), user=Depends(m.current_user)):
        identifiers = list(dict.fromkeys(ids.split(',')))
        if len(identifiers) > 48 or any(not uid or '/' in uid for uid in identifiers):
            raise HTTPException(422, 'Некорректный список участников')
        read = m.document_reader(m.store())
        result = {}
        for uid in identifiers:
            data = read('users', uid).to_dict() or {}
            if data.get('active'):
                result[uid] = account_status(data, read('volunteer_hour_accounts', uid).to_dict() or {})
            else:
                result[uid] = {'is_online': False, 'active_volunteer': False}
        return result

    @app.post('/api/v1/presence')
    def heartbeat(user=Depends(m.current_user)):
        client = m.store()

        @firestore.transactional
        def commit(tx):
            ref, actor = checked_actor(client, tx, user)
            if seconds_since(actor.get('last_seen_at')) >= 50:
                tx.update(ref, {'last_seen_at': m.now()})
        commit(client.transaction())
        return {'is_online': True}

    @app.get('/api/v1/chat/messages')
    def messages(revision: int = Query(-1, ge=-1), before: int = Query(0, ge=0), user=Depends(m.current_user)):
        client = m.store()
        room = client.collection('chat_rooms').document('general').get().to_dict() or {}
        current = room.get('revision', 0)
        if not before and revision == current:
            return {'unchanged': True, 'revision': current}
        query = client.collection('chat_messages').order_by('seq', direction=firestore.Query.DESCENDING)
        if before:
            query = query.where(filter=m.FieldFilter('seq', '<', before))
        snapshots = list(query.limit(51).stream())
        read = m.document_reader(client)
        items = []
        for snapshot in snapshots[:50]:
            row = snapshot.to_dict()
            author = read('users', row['user_id']).to_dict() or {}
            visible = author.get('active', False)
            account = read('volunteer_hour_accounts', row['user_id']).to_dict() or {} if visible else {}
            deleted = bool(row.get('deleted'))
            items.append({'id': snapshot.id, 'seq': row['seq'], 'user_id': row['user_id'] if visible else None,
                          'full_name': author.get('full_name', 'Участник') if visible else 'Недоступный аккаунт',
                          'verified': bool(visible and author.get('verified')), 'is_online': visible and online(author),
                          'active_volunteer': visible and activity_badge(account),
                          'text': '' if deleted else row['text'], 'created_at': row['created_at'], 'deleted': deleted,
                          'can_delete': not deleted and (row['user_id'] == user['id'] or m.has_global_scope(user))})
        return {'items': list(reversed(items)), 'revision': current, 'has_more': len(snapshots) > 50}

    @app.post('/api/v1/chat/messages', status_code=201)
    def send(body: ChatMessage, user=Depends(m.current_user)):
        client = m.store()
        ref = client.collection('chat_messages').document(user['id'] + '_' + str(body.client_id))
        room_ref = client.collection('chat_rooms').document('general')

        @firestore.transactional
        def commit(tx):
            actor_ref, actor = checked_actor(client, tx, user)
            previous = ref.get(transaction=tx)
            room = room_ref.get(transaction=tx).to_dict() or {}
            if previous.exists:
                # Same request can be retried after a lost response, never duplicated.
                if previous.to_dict().get('text') != body.text and not previous.to_dict().get('deleted'):
                    raise HTTPException(409, 'Идентификатор сообщения уже использован')
                return {'id': ref.id, 'duplicate': True}
            if seconds_since(actor.get('last_chat_at')) < 3:
                raise HTTPException(429, 'Подождите 3 секунды перед следующим сообщением')
            stamp = m.now()
            tx.set(ref, {'user_id': user['id'], 'text': body.text, 'created_at': stamp,
                         'seq': room.get('seq', 0) + 1, 'deleted': False})
            tx.set(room_ref, {'seq': room.get('seq', 0) + 1, 'revision': room.get('revision', 0) + 1})
            tx.update(actor_ref, {'last_chat_at': stamp, 'last_seen_at': stamp})
            return {'id': ref.id, 'duplicate': False}
        return commit(client.transaction())

    @app.delete('/api/v1/chat/messages/{message_id}')
    def remove(message_id: str, user=Depends(m.current_user)):
        client = m.store()
        ref = client.collection('chat_messages').document(message_id)
        room_ref = client.collection('chat_rooms').document('general')

        @firestore.transactional
        def commit(tx):
            _, actor = checked_actor(client, tx, user)
            snapshot = ref.get(transaction=tx)
            room = room_ref.get(transaction=tx).to_dict() or {}
            if not snapshot.exists:
                raise HTTPException(404, 'Сообщение не найдено')
            row = snapshot.to_dict()
            if row['user_id'] != user['id'] and not m.has_global_scope(actor):
                raise HTTPException(403, 'Можно удалить только своё сообщение')
            if not row.get('deleted'):
                tx.update(ref, {'deleted': True, 'text': '', 'deleted_by': user['id'], 'deleted_at': m.now()})
                tx.set(room_ref, {**room, 'revision': room.get('revision', 0) + 1})
                tx.set(client.collection('audit_logs').document(), {'user_id': user['id'],
                       'action': 'chat.delete', 'entity': 'chat_message', 'entity_id': message_id, 'created_at': m.now()})
        commit(client.transaction())
        return {'deleted': True}

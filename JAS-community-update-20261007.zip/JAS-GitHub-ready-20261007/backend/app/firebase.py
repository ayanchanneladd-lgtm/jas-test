"""Optional Firebase Admin initialization. Never import credentials in frontend code."""
import os
from pathlib import Path
from typing import Optional

import firebase_admin
from firebase_admin import credentials, firestore, storage
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def service_account_path() -> Optional[Path]:
    value = os.getenv("FIREBASE_SERVICE_ACCOUNT_PATH")
    if not value:
        return None
    path = Path(value)
    if not path.is_absolute():
        path = Path(__file__).resolve().parent.parent / path
    return path


def firestore_client():
    """Return a Firestore client only when a local service-account file is configured."""
    path = service_account_path()
    use_adc = os.getenv("FIREBASE_USE_ADC", "false").lower() == "true"
    if not path and not use_adc:
        return None
    if path and not path.is_file():
        raise RuntimeError("Firebase service-account file was not found")
    if not firebase_admin._apps:
        options = {}
        project = os.getenv("FIREBASE_PROJECT_ID")
        if project:
            options["projectId"] = project
        bucket = os.getenv("FIREBASE_STORAGE_BUCKET")
        if bucket:
            options["storageBucket"] = bucket
        credential = credentials.Certificate(str(path)) if path else credentials.ApplicationDefault()
        firebase_admin.initialize_app(credential, options or None)
    return firestore.client()


def storage_bucket():
    firestore_client()
    if not os.getenv("FIREBASE_STORAGE_BUCKET"):
        raise RuntimeError("FIREBASE_STORAGE_BUCKET is not configured")
    return storage.bucket()

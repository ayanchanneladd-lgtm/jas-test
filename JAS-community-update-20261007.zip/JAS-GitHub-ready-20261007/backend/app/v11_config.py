"""Idempotent self-profile and attendance permission upgrades."""
from firebase_admin import firestore

SELF_PERMISSIONS = {"profile.read", "profile.update"}


def migrate(client, defaults, stamp):
    ref = client.collection("system_config").document("roles")
    log_ref = client.collection("audit_logs").document()

    @firestore.transactional
    def commit(tx):
        data = ref.get(transaction=tx).to_dict() or {}
        if data.get("profile_permissions_version", 0) >= 1 and data.get("attendance_permissions_version", 0) >= 1:
            return False
        # Preserve custom roles: attendance is granted only to existing reviewers.
        roles = dict(data.get("roles", {}))
        for role, fallback in defaults.items():
            allowed = set(roles.get(role, fallback))
            if "*" not in allowed and data.get("profile_permissions_version", 0) < 1:
                allowed.update(SELF_PERMISSIONS)
            if "applications.review" in allowed and data.get("attendance_permissions_version", 0) < 1:
                allowed.update({"attendance.read", "attendance.manage"})
            roles[role] = sorted(allowed)
        tx.set(ref, {"roles": roles, "profile_permissions_version": 1, "attendance_permissions_version": 1}, merge=True)
        tx.set(log_ref, {"user_id": None, "action": "migration.v11_permissions",
                        "entity": "system_config", "entity_id": "roles",
                        "details": {"profile_version": 1, "attendance_version": 1}, "created_at": stamp})
        return True
    return commit(client.transaction())

"""Authenticated member directory with an explicit public-field allowlist."""
import unicodedata
from .community import account_status

from fastapi import Depends, HTTPException, Query


def normalized(value):
    return ' '.join(unicodedata.normalize('NFKC', value or '').casefold().split())


def member_card(snapshot):
    from . import main as m
    data = snapshot.to_dict()
    return {"id": snapshot.id, "full_name": data.get("full_name", ""),
            "username": data.get("username", ""), "verified": bool(data.get("verified")),
            "role_label": m.ROLE_LABELS.get(data.get("role"), "Участник")}


def install(app):
    from . import main as m

    @app.get('/api/v1/members')
    def members(q: str = Query('', max_length=120), offset: int = Query(0, ge=0),
                limit: int = Query(24, ge=1, le=48), user=Depends(m.current_user)):
        query = normalized(q).lstrip('@')
        if len(query) < 2:
            return {"items": [], "total": 0, "has_more": False}
        words = query.split()
        rows = []
        matched_users = {}
        # Legacy names have no normalized search index. Filter server-side without
        # exposing whole account records or adding a write-time migration.
        for snapshot in m.store().collection('users').where(filter=m.FieldFilter('active', '==', True)).stream():
            card = member_card(snapshot)
            text = normalized(card['full_name'] + ' ' + card['username'])
            if all(word in text for word in words):
                rows.append(card)
                matched_users[snapshot.id] = snapshot.to_dict()
        rows.sort(key=lambda row: (normalized(row['username']) != query,
                                   normalized(row['full_name']), row['id']))
        selected = rows[offset:offset + limit]
        read = m.document_reader(m.store())
        for row in selected:
            row.update(account_status(matched_users[row['id']],
                                      read('volunteer_hour_accounts', row['id']).to_dict() or {}))
        return {"items": selected, "total": len(rows),
                "has_more": offset + limit < len(rows)}

    @app.get('/api/v1/members/{member_id}')
    def member(member_id: str, user=Depends(m.current_user)):
        client = m.store()
        snapshot = client.collection('users').document(member_id).get()
        data = snapshot.to_dict() or {}
        if not snapshot.exists or not data.get('active'):
            raise HTTPException(404, 'Профиль не найден или недоступен')
        result = member_card(snapshot)
        result.update({key: data.get(key, default) for key, default in
                       [('about', ''), ('skills', []), ('interests', []), ('created_at', None)]})
        for field, collection in [('department', 'departments'), ('team', 'teams')]:
            identifier = data.get(field + '_id')
            record = client.collection(collection).document(identifier).get().to_dict() if identifier else None
            result[field + '_name'] = (record or {}).get('name')
        account = client.collection('volunteer_hour_accounts').document(member_id).get().to_dict() or {}
        result['total_minutes'] = account.get('total_minutes', 0)
        result['awarded_project_count'] = account.get('project_count', 0)
        result.update(account_status(data, account))
        return {"member": result}

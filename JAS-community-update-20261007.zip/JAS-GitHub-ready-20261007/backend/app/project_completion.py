"""Complete a project and award equal hours to an explicitly confirmed roster."""
from typing import Annotated
from fastapi import Depends, HTTPException
from firebase_admin import firestore
from pydantic import BaseModel, ConfigDict, Field, model_validator
from .volunteer_hours import award_key, write_award


class Completion(BaseModel):
    model_config = ConfigDict(extra='forbid')
    minutes: int = Field(strict=True, ge=1, le=1440)
    application_ids: list[Annotated[str, Field(min_length=1, max_length=300, pattern=r'^[^/]+$')]] = Field(min_length=1, max_length=50)

    @model_validator(mode='after')
    def unique(self):
        if len(set(self.application_ids)) != len(self.application_ids):
            raise ValueError('Участник указан повторно')
        return self


def authorize(user, client=None, tx=None):
    from . import main as m
    if client is not None:
        actor = client.collection('users').document(user['id']).get(transaction=tx).to_dict() or {}
        config = client.collection('system_config').document('roles').get(transaction=tx).to_dict() or {}
        if not actor.get('active') or actor.get('session_version', 0) != user.get('session_version', 0):
            raise HTTPException(401, 'Сессия завершена')
        allowed = config.get('roles', {}).get(actor.get('role'), m.PERMISSIONS.get(actor.get('role'), set()))
        actor = {**actor, 'id': user['id']}
    else:
        actor, allowed = user, user.get('permissions', [])
    if '*' not in allowed and not {'projects.manage', 'attendance.manage', 'hours.manage'}.issubset(allowed):
        raise HTTPException(403, 'Нужны права управления проектами, посещаемостью и часами')
    return actor


def complete(project_id, body, user):
    from . import main as m
    client = m.store()

    @firestore.transactional
    def commit(tx):
        actor = authorize(user, client, tx)
        project_ref = client.collection('projects').document(project_id)
        project = project_ref.get(transaction=tx)
        if not project.exists:
            raise HTTPException(404, 'Проект не найден')
        project_data = project.to_dict()
        m.require_project_scope(project_data, actor)
        if project_data.get('status') != 'active':
            raise HTTPException(409, 'Проект уже завершён или недоступен. Обновите страницу')
        prepared, recipients = [], set()
        for aid in body.application_ids:
            app_ref = client.collection('applications').document(aid)
            snap = app_ref.get(transaction=tx)
            row = snap.to_dict() or {}
            if not snap.exists or row.get('project_id') != project_id or row.get('status') != 'accepted':
                raise HTTPException(409, 'Список изменился: все выбранные заявки должны быть приняты в этот проект')
            uid = row['user_id']
            if uid == user['id']:
                raise HTTPException(403, 'Начислять часы себе нельзя. Ваше участие должен подтвердить другой руководитель')
            if uid in recipients:
                raise HTTPException(409, 'Один участник указан в нескольких заявках')
            recipients.add(uid)
            recipient = client.collection('users').document(uid).get(transaction=tx)
            if not recipient.exists or not recipient.to_dict().get('active'):
                raise HTTPException(409, 'Аккаунт участника недоступен. Обновите список')
            hours_ref = client.collection('volunteer_hours').document(award_key(uid, project_id))
            if hours_ref.get(transaction=tx).exists:
                raise HTTPException(409, 'Одному из участников уже начислены часы за этот проект')
            account_ref = client.collection('volunteer_hour_accounts').document(uid)
            account = account_ref.get(transaction=tx).to_dict() or {}
            prepared.append((app_ref, uid, hours_ref, account_ref, account))
        # No writes until every selected participant has passed all checks.
        stamp = m.now()
        tx.update(project_ref, {'status': 'completed', 'completed_at': stamp, 'completed_by': user['id']})
        for app_ref, uid, hours_ref, account_ref, account in prepared:
            tx.update(app_ref, {'status': 'completed', 'reviewed_by': user['id'], 'updated_at': stamp})
            tx.set(client.collection('application_events').document(), {
                'application_id': app_ref.id, 'user_id': uid, 'from_status': 'accepted',
                'status': 'completed', 'actor_id': user['id'], 'created_at': stamp})
            tx.set(client.collection('audit_logs').document(), {
                'user_id': user['id'], 'action': 'attendance.update', 'entity': 'application',
                'entity_id': app_ref.id, 'created_at': stamp,
                'details': {'project_id': project_id, 'from_status': 'accepted', 'status': 'completed'}})
            write_award(client, tx, hours_ref, account_ref, account, {
                'user_id': uid, 'project_id': project_id, 'application_id': app_ref.id,
                'project_title': project_data.get('title', 'Проект'), 'minutes': body.minutes,
                'reason': 'Подтверждённое участие при завершении проекта', 'status': 'confirmed',
                'granted_by': user['id'], 'granted_by_name': actor.get('full_name', 'Руководитель'),
                'created_at': stamp})
        tx.set(client.collection('audit_logs').document(), {
            'user_id': user['id'], 'action': 'project.complete', 'entity': 'project',
            'entity_id': project_id, 'created_at': stamp,
            'details': {'awarded_count': len(prepared), 'minutes_each': body.minutes}})
        return {'status': 'completed', 'awarded_count': len(prepared), 'minutes_each': body.minutes}
    return commit(client.transaction())


def install(app):
    from . import main as m

    @app.get('/api/v1/projects/{project_id}/completion-preview')
    def preview(project_id: str, user=Depends(m.current_user)):
        authorize(user)
        client = m.store()
        project = client.collection('projects').document(project_id).get()
        if not project.exists:
            raise HTTPException(404, 'Проект не найден')
        m.require_project_scope(project.to_dict(), user)
        if project.to_dict().get('status') != 'active':
            raise HTTPException(409, 'Проект уже завершён или недоступен')
        rows = list(client.collection('applications').where(filter=m.FieldFilter('project_id', '==', project_id))
                    .where(filter=m.FieldFilter('status', '==', 'accepted')).limit(51).stream())
        if len(rows) > 50:
            raise HTTPException(409, 'За один раз можно завершить проект с начислением до 50 участникам. Для этого проекта используйте отдельное завершение и учёт часов')
        refs = [client.collection('users').document(uid) for uid in {snap.to_dict()['user_id'] for snap in rows}]
        people = {snap.id: snap.to_dict() or {} for snap in client.get_all(refs)} if refs else {}
        items = []
        for snap in rows:
            uid = snap.to_dict()['user_id']
            person = people.get(uid, {})
            items.append({'application_id': snap.id, 'name': person.get('full_name', 'Участник'),
                          'eligible': bool(person.get('active')) and uid != user['id'],
                          'reason': 'Ваше участие подтверждает другой руководитель' if uid == user['id'] else
                                    ('Аккаунт недоступен' if not person.get('active') else '')})
        return {'title': project.to_dict().get('title', 'Проект'), 'items': items, 'accepted_count': len(items)}

    @app.post('/api/v1/projects/{project_id}/complete-with-hours')
    def finish(project_id: str, body: Completion, user=Depends(m.current_user)):
        return complete(project_id, body, user)

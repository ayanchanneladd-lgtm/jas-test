"""One-time migration of the local BETA SQLite data into Firestore.

Run from the backend directory: python -m app.migrate_sqlite_to_firestore
The script only writes/upserts Firestore documents; it never deletes either database.
"""
import sqlite3
from pathlib import Path

from .firebase import firestore_client

SQLITE_PATH = Path(__file__).resolve().parent.parent / "jas_volunteers.db"


def write_rows(client, collection, rows, convert=lambda row: row):
    batch = client.batch()
    count = 0
    for row in rows:
        data = convert(dict(row))
        document_id = str(data.pop("id"))
        batch.set(client.collection(collection).document(document_id), data)
        count += 1
        if count % 400 == 0:
            batch.commit()
            batch = client.batch()
    if count % 400:
        batch.commit()
    return count


def main():
    if not SQLITE_PATH.exists():
        raise SystemExit(f"SQLite source was not found: {SQLITE_PATH}")
    client = firestore_client()
    if not client:
        raise SystemExit("FIREBASE_SERVICE_ACCOUNT_PATH is not configured")
    source = sqlite3.connect(SQLITE_PATH)
    source.row_factory = sqlite3.Row
    try:
        users = source.execute("SELECT * FROM users").fetchall()
        departments = source.execute("SELECT * FROM departments").fetchall()
        teams = source.execute("SELECT * FROM teams").fetchall()
        categories = source.execute("SELECT * FROM project_categories").fetchall()
        projects = source.execute("SELECT * FROM projects").fetchall()
        applications = source.execute("SELECT * FROM applications").fetchall()
        sessions = source.execute("SELECT * FROM sessions").fetchall()
        logs = source.execute("SELECT * FROM audit_logs").fetchall()

        write_rows(client, "departments", departments)
        write_rows(client, "teams", teams, lambda row: {**row, "department_id":str(row["department_id"]) if row["department_id"] else None})
        write_rows(client, "project_categories", categories)
        write_rows(client, "users", users, lambda row: {**row, "department_id":str(row["department_id"]) if row["department_id"] else None, "team_id":str(row["team_id"]) if row["team_id"] else None})
        accepted_by_project = {str(row["id"]): 0 for row in projects}
        for row in applications:
            if row["status"] == "accepted": accepted_by_project[str(row["project_id"])] += 1
        write_rows(client, "projects", projects, lambda row: {**row, "category_id":str(row["category_id"]), "organizer_id":str(row["organizer_id"]) if row["organizer_id"] else None, "accepted_count":accepted_by_project[str(row["id"])]})
        write_rows(client, "applications", applications, lambda row: {**row, "id":f"{row['project_id']}_{row['user_id']}", "legacy_id":row["id"], "project_id":str(row["project_id"]), "user_id":str(row["user_id"]), "reviewed_by":str(row["reviewed_by"]) if row["reviewed_by"] else None})
        write_rows(client, "sessions", sessions, lambda row: {**row, "id":row["token_hash"], "legacy_id":row["id"], "user_id":str(row["user_id"])})
        write_rows(client, "audit_logs", logs, lambda row: {**row, "user_id":str(row["user_id"]) if row["user_id"] else None})
        print(f"Firestore migration complete: users={len(users)}, projects={len(projects)}, applications={len(applications)}")
    finally:
        source.close()


if __name__ == "__main__":
    main()

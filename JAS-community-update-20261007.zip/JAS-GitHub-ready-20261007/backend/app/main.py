"""JAS Volunteers BETA API — Firestore is the primary database."""
import csv
import hashlib
import hmac
import json
from io import StringIO
from pathlib import Path
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import uuid4

from fastapi import Cookie, Depends, FastAPI, HTTPException, Response, Request, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from firebase_admin import firestore
from google.cloud.firestore_v1.base_query import FieldFilter
from pydantic import BaseModel, Field, field_validator
from dotenv import load_dotenv

from .firebase import firestore_client, service_account_path, storage_bucket
from .profile_v11 import ProfileUpdate, profile_defaults, save_profile
from .v11_config import SELF_PERMISSIONS, migrate as migrate_profile_permissions

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"))
ITERATIONS, SESSION_DAYS = 600_000, 14
SESSION_COOKIE_NAME = os.getenv("SESSION_COOKIE_NAME", "session")
PERMISSIONS = {"volunteer":set(), "teamlead":{"applications.review","team.read"}, "vice_coordinator":{"applications.review","projects.manage"}, "coordinator":{"applications.review","projects.manage"}, "senior_coordinator":{"applications.review","projects.manage"}, "vice_chairman":{"applications.review","projects.manage","departments.manage","audit.export"}, "chairman":{"applications.review","projects.manage","departments.manage","audit.export"}, "super_admin":{"*"}}
ROLE_LABELS = {"volunteer":"Волонтёр","teamlead":"Тимлидер","vice_coordinator":"Заместитель координатора","coordinator":"Координатор","senior_coordinator":"Старший координатор","vice_chairman":"Заместитель председателя","chairman":"Председатель","super_admin":"Super Admin"}
PERMISSION_CATALOG = ["applications.review","team.read","projects.manage","departments.manage","audit.export"]
PERMISSION_CATALOG += sorted(SELF_PERMISSIONS)
PERMISSION_CATALOG += ["attendance.read", "attendance.manage", "hours.manage"]
from .ai.service import PERMISSIONS as AI_PERMISSIONS
PERMISSION_CATALOG += AI_PERMISSIONS
for role_permissions in PERMISSIONS.values():
    if "applications.review" in role_permissions:
        role_permissions.update({"attendance.read", "attendance.manage"})
    if "*" not in role_permissions:
        role_permissions.update(SELF_PERMISSIONS)
GLOBAL_SCOPE_ROLES = {"super_admin", "chairman", "vice_chairman"}
DEPARTMENT_SCOPE_ROLES = {"vice_coordinator", "coordinator", "senior_coordinator"}
app = FastAPI(title="JAS Volunteers API", version="BETA 1.1 — Firestore")

def store():
    client = firestore_client()
    if not client: raise RuntimeError("Firestore is not configured")
    return client
def now(): return datetime.now(timezone.utc).isoformat()
def h(value): return hashlib.sha256(value.encode()).hexdigest()
def password(raw, salt=None):
    salt=salt or secrets.token_bytes(16)
    return salt.hex()+"$"+hashlib.pbkdf2_hmac("sha256",raw.encode(),salt,ITERATIONS).hex()
def valid_password(candidate, saved):
    try:
        salt,digest=saved.split("$",1)
        return hmac.compare_digest(password(candidate,bytes.fromhex(salt)).split("$",1)[1],digest)
    except (ValueError,TypeError,AttributeError):
        return False
def as_dict(snapshot):
    data=snapshot.to_dict() or {}; data["id"]=snapshot.id; return data
def public_user(data):
    result=profile_defaults(dict(data)); result.pop("password_hash",None); result["role_label"]=ROLE_LABELS.get(result.get("role"),result.get("role","")); return result
def first(query): return next(iter(query.limit(1).stream()),None)
def audit(actor_id, action, entity, entity_id=None, details=None):
    entry={"user_id":actor_id,"action":action,"entity":entity,"entity_id":entity_id,"created_at":now()}
    if details: entry["details"]=details
    store().collection("audit_logs").document().set(entry)
def user_by_email_or_username(login):
    client=store(); email=first(client.collection("users").where(filter=FieldFilter("email","==",login)))
    return email or first(client.collection("users").where(filter=FieldFilter("username","==",login)))
def category_map(): return {s.id:as_dict(s) for s in store().collection("project_categories").stream()}
def coordinator_name(user_id):
    if not user_id: return "JAS Volunteers"
    snapshot=store().collection("users").document(str(user_id)).get()
    return snapshot.to_dict().get("full_name","JAS Volunteers") if snapshot.exists else "JAS Volunteers"
def document_reader(client):
    """Reuse immutable snapshots only within one response, never across requests."""
    snapshots = {}
    def read(collection, document_id):
        key = (collection, document_id)
        if key not in snapshots:
            snapshots[key] = client.collection(collection).document(document_id).get()
        return snapshots[key]
    return read

def organization_details(data, read=None):
    """Add display names without exposing any additional private user data."""
    result=public_user(data); read=read or document_reader(store())
    department_id=result.get("department_id"); team_id=result.get("team_id")
    department=read("departments",department_id) if department_id else None
    team=read("teams",team_id) if team_id else None
    result["department_name"]=department.to_dict().get("name") if department and department.exists else None
    result["team_name"]=team.to_dict().get("name") if team and team.exists else None
    config=read('system_config','roles').to_dict() or {}
    result['permissions']=config.get('roles',{}).get(result.get('role'),sorted(PERMISSIONS.get(result.get('role'),set())))
    return result
def has_global_scope(user): return user.get("role") in GLOBAL_SCOPE_ROLES
def project_in_scope(project,user):
    """Leadership data is constrained on the server, never only in the UI."""
    if has_global_scope(user): return True
    if user.get("role")=="teamlead":
        return bool(user.get("team_id")) and project.get("team_id")==user.get("team_id")
    if user.get("role") in DEPARTMENT_SCOPE_ROLES:
        return bool(user.get("department_id")) and project.get("department_id")==user.get("department_id")
    return False
def require_project_scope(project,user):
    if not project_in_scope(project,user): raise HTTPException(403,"Нет доступа к данным другого отдела или команды")
def ensure_seed_data():
    client=store()
    roles_ref=client.collection("system_config").document("roles")
    if not roles_ref.get().exists: roles_ref.set({"roles":{role:sorted(values) for role,values in PERMISSIONS.items()}})
    migrate_profile_permissions(client, PERMISSIONS, now())
    settings_ref=client.collection("system_config").document("settings")
    if not settings_ref.get().exists: settings_ref.set({"platform_name":"JAS Volunteers","beta_mode":True,"maintenance_mode":False,"updated_at":now()})
    if not first(client.collection("project_categories")):
        for name in ("Экология","Социальные инициативы","Образование","Спорт и IT"):
            doc=client.collection("project_categories").document(); doc.set({"name":name})
    if not first(client.collection("projects")):
        category=first(client.collection("project_categories").where(filter=FieldFilter("name","==","Экология")))
        client.collection("projects").document().set({"title":"Озеленение парка «Кок-Тобе»","description":"Высадка саженцев и благоустройство парковой зоны вместе с экологическим сообществом города.","image_url":"https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=1200","location":"Алматы, парковая зона","starts_at":"2026-09-18T10:00:00+05:00","requirements":"Удобная одежда и желание помогать.","capacity":40,"accepted_count":0,"status":"active","category_id":category.id,"created_at":now()})
    email,raw=os.getenv("JAS_BOOTSTRAP_ADMIN_EMAIL"),os.getenv("JAS_BOOTSTRAP_ADMIN_PASSWORD")
    if email and raw:
        snapshot=user_by_email_or_username(email.lower())
        if snapshot: snapshot.reference.update({"role":"super_admin","active":True,"updated_at":now()})
        else:
            uid=str(uuid4()); client.collection("users").document(uid).set({"public_id":"JAS-ADMIN-"+secrets.token_hex(3).upper(),"full_name":os.getenv("JAS_BOOTSTRAP_ADMIN_NAME","JAS Super Admin"),"username":os.getenv("JAS_BOOTSTRAP_ADMIN_USERNAME","jas_admin").lower(),"email":email.lower(),"password_hash":password(raw),"role":"super_admin","active":True,"created_at":now(),"updated_at":now()})

@app.on_event("startup")
def startup():
    ensure_seed_data()

@app.middleware("http")
async def record_server_errors(request:Request, call_next):
    try:
        response=await call_next(request)
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'private, no-store'
        if response.status_code>=500:
            try: store().collection("system_errors").document().set({"path":request.url.path,"status":response.status_code,"created_at":now()})
            except Exception: pass
        return response
    except Exception as error:
        try: store().collection("system_errors").document().set({"path":request.url.path,"status":500,"message":str(error)[:500],"created_at":now()})
        except Exception: pass
        raise

class TrimmedInput(BaseModel):
    @field_validator("*",mode="before")
    @classmethod
    def trim_fields(cls,value,info):
        if isinstance(value,str) and info.field_name not in {"password","password_confirmation"}:
            return value.strip()
        return value

class Register(TrimmedInput):
    full_name:str=Field(min_length=3,max_length=120); username:str=Field(min_length=3,max_length=32,pattern=r"^[A-Za-z0-9_]+$"); email:str=Field(min_length=5,max_length=254); password:str=Field(min_length=8,max_length=128); password_confirmation:str
    @field_validator("email")
    @classmethod
    def validate_email(cls,value):
        import re
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+",value): raise ValueError("Введите корректный email")
        return value.lower()

class Login(TrimmedInput): login:str=Field(min_length=3,max_length=254); password:str=Field(min_length=1,max_length=128)
Profile = ProfileUpdate
class Review(BaseModel): status:str
class ProjectIn(BaseModel):
    title:str=Field(min_length=3,max_length=160)
    description:str=Field(min_length=10,max_length=4000)
    location:str=Field(min_length=2,max_length=250)
    starts_at:str
    capacity:int=Field(gt=0,le=100000)
    category_id:str=Field(min_length=1,max_length=150)
    image_url:Optional[str]=Field(default=None,max_length=2000)
    requirements:Optional[str]=Field(default=None,max_length=4000)

    @field_validator("title","description","location",mode="before")
    @classmethod
    def trim_text(cls,value):
        return value.strip() if isinstance(value,str) else value

    @field_validator("starts_at")
    @classmethod
    def valid_date(cls,value):
        date=datetime.fromisoformat(value.replace("Z","+00:00"))
        if date.tzinfo is None: raise ValueError("Укажите часовой пояс")
        return date.astimezone(timezone.utc).isoformat()

    @field_validator("image_url")
    @classmethod
    def valid_image(cls,value):
        if value and not value.startswith(("https://","http://")): raise ValueError("Нужна HTTP(S) ссылка")
        return value
class ProjectDeletion(BaseModel): reason:str=Field(min_length=5,max_length=1000)
class AdminUserUpdate(BaseModel):
    role:Optional[str]=None
    active:Optional[bool]=None
    department_id:Optional[str]=None
    team_id:Optional[str]=None
class RolePermissionsUpdate(BaseModel): permissions:list[str]
class DepartmentIn(TrimmedInput): name:str=Field(min_length=2,max_length=120)
class TeamIn(TrimmedInput): name:str=Field(min_length=2,max_length=120); department_id:str=Field(min_length=1,max_length=150,pattern=r"^[^/]+$")
class SettingsIn(TrimmedInput): platform_name:Optional[str]=Field(default=None,min_length=2,max_length=120); beta_mode:Optional[bool]=None
class MaintenanceIn(BaseModel):
    hours:float=Field(gt=0,le=720)
    reason:str=Field(min_length=3,max_length=500)

class NotificationIn(TrimmedInput): title:str=Field(min_length=3,max_length=160); message:str=Field(min_length=3,max_length=2000); audience:str=Field(pattern=r"^(all|role)$"); role:Optional[str]=None

def make_session(user_id, expected_hash=None):
    client=store(); raw=secrets.token_urlsafe(32)
    @firestore.transactional
    def create(transaction):
        snapshot=client.collection("users").document(user_id).get(transaction=transaction)
        data=snapshot.to_dict() or {}
        if not snapshot.exists or not data.get("active"): raise HTTPException(401,"Аккаунт недоступен")
        if expected_hash is not None and data.get("password_hash")!=expected_hash:
            raise HTTPException(401,"Пароль изменён. Повторите вход")
        transaction.set(client.collection("sessions").document(h(raw)),{
            "user_id":user_id,"session_version":data.get("session_version",0),
            "expires_at":(datetime.now(timezone.utc)+timedelta(days=SESSION_DAYS)).isoformat(),"created_at":now()})
    create(client.transaction())
    return raw
def set_session(response, token): response.set_cookie(SESSION_COOKIE_NAME,token,httponly=True,samesite="lax",secure=os.getenv("COOKIE_SECURE","false").lower()=="true",max_age=SESSION_DAYS*86400)
def current_user(session:Optional[str]=Cookie(default=None, alias=SESSION_COOKIE_NAME)):
    if not session: raise HTTPException(401,"Требуется авторизация")
    client=store(); record=client.collection("sessions").document(h(session)).get()
    if not record.exists: raise HTTPException(401,"Сессия недействительна")
    data=record.to_dict()
    if data["expires_at"] <= now(): record.reference.delete(); raise HTTPException(401,"Сессия истекла")
    user=client.collection("users").document(data["user_id"]).get()
    if not user.exists or not user.to_dict().get("active"): raise HTTPException(401,"Сессия недействительна")
    if data.get("session_version",0)!=user.to_dict().get("session_version",0):
        raise HTTPException(401,"Сессия завершена. Войдите снова")
    return organization_details(as_dict(user))
def require(permission):
    def checker(user=Depends(current_user)):
        config=store().collection("system_config").document("roles").get().to_dict() or {}
        allowed=set((config.get("roles",{}).get(user["role"],list(PERMISSIONS.get(user["role"],set())))))
        if permission not in allowed and "*" not in allowed: raise HTTPException(403,"Недостаточно прав")
        return user
    return checker
def require_super_admin(user=Depends(current_user)):
    if user["role"]!="super_admin": raise HTTPException(403,"Требуется роль Super Admin")
    return user

class VerificationIn(BaseModel):
    verified:bool
    reason:str=Field(min_length=3,max_length=500)

def require_verification_manager(user=Depends(current_user)):
    if user.get('role') not in {'super_admin','chairman','vice_chairman'}:
        raise HTTPException(403,'Нет права управлять подтверждением аккаунтов')
    return user

def verified_account(user_id):
    if not user_id: return False
    snapshot=store().collection('users').document(str(user_id)).get()
    return bool(snapshot.exists and snapshot.to_dict().get('verified',False))

@app.get('/api/v1/verification/users')
def verification_users(q:str='',offset:int=0,user=Depends(require_verification_manager)):
    rows=[]
    for snapshot in store().collection('users').stream():
        data=as_dict(snapshot)
        if q.casefold() not in (data.get('full_name','')+' '+data.get('username','')).casefold(): continue
        rows.append({k:data.get(k) for k in ('id','full_name','username','verified')})
    rows.sort(key=lambda row:(row.get('full_name') or '',row['id']))
    start=max(0,offset)
    return {'items':rows[start:start+50],'total':len(rows)}

@app.patch('/api/v1/verification/users/{user_id}')
def set_verification(user_id:str,body:VerificationIn,user=Depends(require_verification_manager)):
    reason=body.reason.strip()
    if len(reason)<3: raise HTTPException(422,'Укажите причину, минимум 3 символа')
    ref=store().collection('users').document(user_id)
    if not ref.get().exists: raise HTTPException(404,'Пользователь не найден')
    ref.update({'verified':body.verified,'updated_at':now()})
    audit(user['id'],'verification.grant' if body.verified else 'verification.revoke','user',user_id,reason)
    return {'id':user_id,'verified':body.verified}

def maintenance_status():
    data=store().collection('system_config').document('settings').get().to_dict() or {}
    return {key:data.get(key) for key in ('maintenance_mode','maintenance_reason','maintenance_hours','maintenance_until')}

@app.middleware('http')
async def maintenance_gate(request:Request,call_next):
    allowed={'/api/v1/maintenance','/api/v1/auth/login','/api/v1/auth/logout'}
    if request.method!='OPTIONS' and request.url.path.startswith('/api/') and request.url.path not in allowed:
        state=maintenance_status()
        if state.get('maintenance_mode'):
            try: developer=current_user(request.cookies.get(SESSION_COOKIE_NAME))['role']=='super_admin'
            except HTTPException: developer=False
            if not developer:
                headers={'Retry-After':'60'}
                origin=request.headers.get('origin')
                if origin in {'http://localhost:3000','http://127.0.0.1:3000'}:
                    headers.update({'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Credentials':'true','Vary':'Origin'})
                return JSONResponse({'detail':'Сайт временно закрыт на техническое обслуживание','code':'maintenance',**state},status_code=503,headers=headers)
    return await call_next(request)

@app.get('/api/v1/maintenance')
def public_maintenance(): return maintenance_status()

@app.post('/api/v1/admin/maintenance')
def start_maintenance(body:MaintenanceIn,user=Depends(require_super_admin)):
    reason=body.reason.strip()
    if len(reason)<3: raise HTTPException(422,'Укажите причину, минимум 3 символа')
    store().collection('system_config').document('settings').set({'maintenance_mode':True,'maintenance_reason':reason,'maintenance_hours':body.hours,'maintenance_until':(datetime.now(timezone.utc)+timedelta(hours=body.hours)).isoformat()},merge=True)
    audit(user['id'],'maintenance.start','settings',details=reason)
    return maintenance_status()

@app.delete('/api/v1/admin/maintenance')
def stop_maintenance(user=Depends(require_super_admin)):
    store().collection('system_config').document('settings').set({'maintenance_mode':False},merge=True)
    audit(user['id'],'maintenance.stop','settings')
    return maintenance_status()

@app.get("/")
def root():
    if os.getenv('JAS_SERVE_FRONTEND', 'false').lower() == 'true':
        from fastapi.responses import FileResponse
        return FileResponse(Path(__file__).resolve().parents[2] / 'frontend' / 'index.html')
    return {"message":"JAS Volunteers API BETA","database":"Firestore","docs":"/docs"}
@app.post("/api/v1/auth/register",status_code=201)
def register(body:Register,response:Response):
    if body.password!=body.password_confirmation: raise HTTPException(422,"Пароли не совпадают")
    if body.email.count("@")!=1: raise HTTPException(422,"Введите корректный email")
    client=store(); email,username=body.email.lower(),body.username.lower()
    if user_by_email_or_username(email) or first(client.collection("users").where(filter=FieldFilter("username","==",username))): raise HTTPException(409,"Email или никнейм уже заняты")
    uid=str(uuid4()); user={"public_id":"JAS-"+secrets.token_hex(4).upper(),"full_name":body.full_name.strip(),"username":username,"email":email,"password_hash":password(body.password),"role":"volunteer","active":True,"created_at":now(),"updated_at":now()}
    client.collection("users").document(uid).set(user); token=make_session(uid); audit(uid,"register","user",uid); user["id"]=uid
    set_session(response,token); return {"user":organization_details(user)}
@app.post("/api/v1/auth/login")
def login(body:Login,response:Response):
    snapshot=user_by_email_or_username(body.login.lower())
    if not snapshot or not valid_password(body.password,snapshot.to_dict()["password_hash"]): raise HTTPException(401,"Неверный логин или пароль")
    user=as_dict(snapshot)
    if not user.get("active"): raise HTTPException(403,"Аккаунт заблокирован")
    token=make_session(user["id"],user["password_hash"]); audit(user["id"],"login","session"); set_session(response,token); return {"user":organization_details(user)}
@app.post("/api/v1/auth/logout",status_code=204)
def logout(response:Response,session:Optional[str]=Cookie(default=None, alias=SESSION_COOKIE_NAME)):
    if session: store().collection("sessions").document(h(session)).delete()
    response.delete_cookie(SESSION_COOKIE_NAME)
@app.get("/api/v1/auth/me")
def me(user=Depends(current_user)):
    from .community import account_status
    account = store().collection('volunteer_hour_accounts').document(user['id']).get().to_dict() or {}
    return {"user": {**user, **account_status(user, account)}}
@app.patch("/api/v1/profile")
def profile(body:Profile,user=Depends(require("profile.update"))):
    return save_profile(body,user)
@app.get("/api/v1/categories")
def categories(): return [as_dict(s) for s in store().collection("project_categories").order_by("name").stream()]
@app.get("/api/v1/projects")
def projects(q:str="",category_id:Optional[str]=None):
    query=store().collection("projects").where(filter=FieldFilter("status","==","active"))
    if category_id: query=query.where(filter=FieldFilter("category_id","==",category_id))
    categories=category_map(); rows=[]
    for snapshot in query.stream():
        project=as_dict(snapshot)
        if q.lower() not in (project["title"]+project["description"]+project["location"]).lower(): continue
        project["category"]=categories.get(project.get("category_id"),{}).get("name",""); project["available_places"]=project["capacity"]-project.get("accepted_count",0); project["coordinator_verified"]=verified_account(project.get("organizer_id")); project["coordinator_name"]=coordinator_name(project.get("organizer_id")); rows.append(project)
    return sorted(rows,key=lambda item:item["starts_at"])
@app.get("/api/v1/projects/{project_id}")
def get_project(project_id:str):
    snapshot=store().collection("projects").document(project_id).get()
    if not snapshot.exists or snapshot.to_dict().get("status")=="deleted": raise HTTPException(404,"Проект не найден")
    project=as_dict(snapshot); project["category"]=category_map().get(project.get("category_id"),{}).get("name",""); project["available_places"]=project["capacity"]-project.get("accepted_count",0); project["coordinator_verified"]=verified_account(project.get("organizer_id")); project["coordinator_name"]=coordinator_name(project.get("organizer_id")); return project
@app.post("/api/v1/projects",status_code=201)
def create_project(body:ProjectIn,user=Depends(require("projects.manage"))):
    if not store().collection("project_categories").document(body.category_id).get().exists: raise HTTPException(422,"Категория не найдена")
    if not has_global_scope(user) and not user.get("department_id"): raise HTTPException(403,"Сначала попросите Super Admin назначить вам отдел")
    ref=store().collection("projects").document(); ref.set({"title":body.title,"description":body.description,"image_url":body.image_url,"location":body.location,"starts_at":body.starts_at,"requirements":body.requirements,"organizer_id":user["id"],"department_id":user.get("department_id"),"team_id":user.get("team_id"),"capacity":body.capacity,"accepted_count":0,"status":"active","category_id":body.category_id,"created_at":now()}); audit(user["id"],"project.create","project",ref.id,"Отдел: "+str(user.get("department_name") or "без отдела")); return {"id":ref.id}
@app.get("/api/v1/managed/projects")
def managed_projects(user=Depends(require("projects.manage"))):
    categories=category_map(); rows=[]
    for snapshot in store().collection("projects").stream():
        project=as_dict(snapshot)
        if project.get("status") not in {"active","completed"}: continue
        if not project_in_scope(project,user): continue
        project["category"]=categories.get(project.get("category_id"),{}).get("name","")
        project["available_places"]=project["capacity"]-project.get("accepted_count",0)
        project["coordinator_verified"]=verified_account(project.get("organizer_id")); project["coordinator_name"]=coordinator_name(project.get("organizer_id"))
        rows.append(project)
    return sorted(rows,key=lambda item:item.get("starts_at",""))
@app.patch("/api/v1/projects/{project_id}/complete")
def complete_project(project_id:str,user=Depends(require("projects.manage"))):
    from .beta import change_project_status
    return change_project_status(project_id,"completed",user)
@app.delete("/api/v1/projects/{project_id}")
def delete_project(project_id:str,body:ProjectDeletion,user=Depends(require("projects.manage"))):
    from .beta import change_project_status
    return change_project_status(project_id,"deleted",user,body.reason)
@app.post("/api/v1/projects/{project_id}/applications",status_code=201)
def apply(project_id:str,user=Depends(current_user)):
    client=store(); project_ref=client.collection("projects").document(project_id); app_ref=client.collection("applications").document(f"{project_id}_{user['id']}")
    @firestore.transactional
    def create(transaction):
        project=project_ref.get(transaction=transaction)
        if not project.exists or project.to_dict().get("status")!="active": raise HTTPException(404,"Проект недоступен")
        if app_ref.get(transaction=transaction).exists: raise HTTPException(409,"Вы уже подали заявку на этот проект")
        data=project.to_dict()
        if data.get("accepted_count",0)>=data["capacity"]: raise HTTPException(409,"Свободных мест больше нет")
        transaction.set(app_ref,{"project_id":project_id,"user_id":user["id"],"status":"pending","created_at":now(),"updated_at":now()})
    create(client.transaction()); audit(user["id"],"application.create","application",app_ref.id); return {"id":app_ref.id,"status":"pending","message":"Заявка отправлена на рассмотрение"}
@app.get("/api/v1/my/applications")
def mine(user=Depends(current_user)):
    client=store(); rows=[]; read=document_reader(client)
    for snapshot in client.collection("applications").where(filter=FieldFilter("user_id","==",user["id"])).stream():
        app_item=as_dict(snapshot); project=read("projects",app_item["project_id"])
        app_item["project_status"]=project.to_dict().get("status") if project.exists else None
        if project.exists: app_item.update({key:project.to_dict().get(key) for key in ("title","starts_at","location")})
        rows.append(app_item)
    return sorted(rows,key=lambda item:item["created_at"],reverse=True)
@app.get("/api/v1/applications")
def applications(user=Depends(require("applications.review"))):
    client=store(); rows=[]; read=document_reader(client)
    for snapshot in client.collection("applications").stream():
        item=as_dict(snapshot); project=read("projects",item["project_id"])
        item["project_status"]=project.to_dict().get("status") if project.exists else None
        if not project.exists or not project_in_scope(project.to_dict(),user): continue
        volunteer=read("users",item["user_id"])
        item.update({key:project.to_dict().get(key) for key in ("title","starts_at","location")})
        item["verified"]=bool(volunteer.exists and volunteer.to_dict().get("verified",False))
        if volunteer.exists: item.update({key:volunteer.to_dict().get(key) for key in ("full_name","username")})
        rows.append(item)
    return sorted(rows,key=lambda item:item["created_at"],reverse=True)
@app.patch("/api/v1/applications/{application_id}")
def review(application_id:str,body:Review,user=Depends(require("applications.review"))):
    from .beta import transition
    return transition(application_id,body.status,user)
@app.get("/api/v1/admin/stats")
def stats(user=Depends(require_super_admin)):
    client=store(); applications=[s.to_dict() for s in client.collection("applications").stream()]; projects=[s.to_dict() for s in client.collection("projects").stream()]; users=[s.to_dict() for s in client.collection("users").stream()]
    return {"users":len(users),"active_users":sum(bool(u.get("active")) for u in users),"projects":len(projects),"active_projects":sum(p.get("status")=="active" for p in projects),"applications":len(applications),"accepted":sum(a.get("status")=="accepted" for a in applications),"rejected":sum(a.get("status")=="rejected" for a in applications)}
@app.get("/api/v1/admin/users")
def admin_users(limit:int=50,offset:int=0,user=Depends(require_super_admin)):
    client=store(); read=document_reader(client)
    records=sorted([as_dict(s) for s in client.collection("users").stream()],key=lambda x:x["created_at"],reverse=True)
    page=records[max(0,offset):max(0,offset)+max(1,min(limit,100))]
    return [organization_details(record,read) for record in page]
@app.patch("/api/v1/admin/users/{user_id}")
def admin_update_user(user_id:str,body:AdminUserUpdate,user=Depends(require_super_admin)):
    changes=body.model_dump(exclude_unset=True)
    if any(key in changes and changes[key] is None for key in ("role","active")): raise HTTPException(422,"Роль и статус не могут быть пустыми")
    if not changes: raise HTTPException(422,"Нет изменений")
    if changes.get("role") is not None and changes["role"] not in ROLE_LABELS: raise HTTPException(422,"Неизвестная роль")
    client=store(); ref=client.collection("users").document(user_id); target=ref.get()
    if not target.exists: raise HTTPException(404,"Пользователь не найден")
    if user_id==user["id"] and changes.get("active") is False: raise HTTPException(409,"Нельзя заблокировать собственный аккаунт")
    if user_id==user["id"] and "role" in changes and changes["role"]!="super_admin": raise HTTPException(409,"Нельзя снять собственную роль разработчика")
    current=target.to_dict(); department_id=changes.get("department_id",current.get("department_id")); team_id=changes.get("team_id",current.get("team_id"))
    if "department_id" in changes and department_id!=current.get("department_id") and "team_id" not in changes:
        team_id=None
    if department_id and not client.collection("departments").document(department_id).get().exists: raise HTTPException(422,"Отдел не найден")
    if team_id:
        team=client.collection("teams").document(team_id).get()
        if not team.exists: raise HTTPException(422,"Команда не найдена")
        team_department=team.to_dict().get("department_id")
        if "department_id" in changes and department_id!=team_department: raise HTTPException(422,"Команда относится к другому отделу")
        department_id=team_department
    elif "department_id" in changes and department_id!=current.get("department_id"):
        team_id=None
    if not department_id: team_id=None
    patch={"updated_at":now(),"department_id":department_id,"team_id":team_id}
    if "role" in changes: patch["role"]=changes["role"]
    if "active" in changes: patch["active"]=changes["active"]
    ref.update(patch); audit(user["id"],"admin.user.update","user",user_id,"Структура: "+str(department_id or "не назначен")+" / "+str(team_id or "без команды")); return {"user":organization_details(as_dict(ref.get()))}
@app.get("/api/v1/admin/audit-logs")
def audit_logs(limit:int=50,offset:int=0,action:Optional[str]=None,user=Depends(require_super_admin)):
    client=store(); rows=[]
    for snapshot in client.collection("audit_logs").stream():
        item=as_dict(snapshot)
        if action and item.get("action")!=action: continue
        actor=client.collection("users").document(item["user_id"]).get() if item.get("user_id") else None; item["actor_name"]=actor.to_dict().get("full_name") if actor and actor.exists else "Система"; rows.append(item)
    return sorted(rows,key=lambda x:x["created_at"],reverse=True)[max(0,offset):max(0,offset)+max(1,min(limit,100))]
@app.get("/api/v1/audit-logs/export")
def export_audit_logs(period:str="24h",user=Depends(require("audit.export"))):
    if user.get('role') not in GLOBAL_SCOPE_ROLES: raise HTTPException(403,'Журнал доступен только разработчику и председателям')
    periods={"24h":timedelta(hours=24),"7d":timedelta(days=7),"30d":timedelta(days=30),"90d":timedelta(days=90)}
    if period not in periods: raise HTTPException(422,"Недопустимый период")
    since=datetime.now(timezone.utc)-periods[period]; client=store(); records=[]
    for snapshot in client.collection("audit_logs").stream():
        item=as_dict(snapshot)
        try: created=datetime.fromisoformat(item["created_at"])
        except (KeyError,ValueError): continue
        if created.tzinfo is None: created=created.replace(tzinfo=timezone.utc)
        if created < since: continue
        actor=client.collection("users").document(item["user_id"]).get() if item.get("user_id") else None
        records.append({"date":item["created_at"],"actor":actor.to_dict().get("full_name") if actor and actor.exists else "Система","action":item.get("action",""),"entity":item.get("entity",""),"entity_id":item.get("entity_id",""),"details":item.get("details","")})
    output=StringIO(); writer=csv.DictWriter(output,fieldnames=["date","actor","action","entity","entity_id","details"]); writer.writeheader()
    for row in sorted(records,key=lambda item:item["date"],reverse=True):
        # Preserve stored logs; neutralize spreadsheet formulas only in the export.
        writer.writerow({key:csv_safe(value) for key,value in row.items()})
    audit(user["id"],"audit.export","audit_log",period)
    return Response(content="\ufeff"+output.getvalue(),media_type="text/csv; charset=utf-8",headers={"Content-Disposition":f'attachment; filename="jas-audit-logs-{period}.csv"'})

def csv_safe(value):
    text="" if value is None else str(value)
    return "'"+text if text.lstrip().startswith(("=","+","-","@")) or text.startswith(("\t","\r","\n")) else text
@app.get("/api/v1/admin/firebase-status")
def firebase_status(user=Depends(require_super_admin)):
    path=service_account_path()
    if not path: return {"configured":False,"connected":False}
    try: next(iter(store().collections()),None); return {"configured":True,"connected":True,"project_id":os.getenv("FIREBASE_PROJECT_ID","")}
    except Exception: return {"configured":True,"connected":False}

@app.get("/api/v1/admin/developer-overview")
def developer_overview(user=Depends(require_super_admin)):
    client=store(); collections=["users","sessions","projects","applications","audit_logs","notifications","departments","teams","system_errors"]
    counts={name:sum(1 for _ in client.collection(name).stream()) for name in collections}
    return {"database":"Firestore","project_id":os.getenv("FIREBASE_PROJECT_ID",""),"collections":counts,"firebase_configured":bool(service_account_path()),"generated_at":now()}

@app.get("/api/v1/admin/roles")
def admin_roles(user=Depends(require_super_admin)):
    data=store().collection("system_config").document("roles").get().to_dict() or {}
    configured=data.get("roles",{})
    return {"catalog":PERMISSION_CATALOG,"roles":[{"key":key,"label":ROLE_LABELS[key],"permissions":configured.get(key,sorted(PERMISSIONS[key]))} for key in ROLE_LABELS]}

@app.put("/api/v1/admin/roles/{role}")
def update_role_permissions(role:str,body:RolePermissionsUpdate,user=Depends(require_super_admin)):
    if role!='super_admin' and '*' in body.permissions: raise HTTPException(422,'Полный доступ разрешён только разработчику')
    if role not in ROLE_LABELS: raise HTTPException(404,"Роль не найдена")
    if any(permission not in PERMISSION_CATALOG and permission!="*" for permission in body.permissions): raise HTTPException(422,"Неизвестное permission")
    if role=="super_admin" and "*" not in body.permissions: raise HTTPException(409,"Super Admin должен сохранять полный доступ")
    ref=store().collection("system_config").document("roles"); data=ref.get().to_dict() or {"roles":{}}
    roles=data.get("roles",{}); roles[role]=sorted(set(body.permissions)); ref.set({"roles":roles},merge=True); audit(user["id"],"admin.role_permissions.update","role",role)
    return {"role":role,"permissions":roles[role]}

@app.get("/api/v1/admin/projects/deleted")
def deleted_projects(user=Depends(require_super_admin)):
    rows=[]
    for snapshot in store().collection("projects").where(filter=FieldFilter("status","==","deleted")).stream():
        item=as_dict(snapshot); item["coordinator_name"]=coordinator_name(item.get("organizer_id")); rows.append(item)
    return sorted(rows,key=lambda item:item.get("deleted_at",""),reverse=True)

@app.post("/api/v1/admin/projects/{project_id}/restore")
def restore_project(project_id:str,user=Depends(require_super_admin)):
    client=store(); ref=client.collection("projects").document(project_id)
    @firestore.transactional
    def restore(transaction):
        snapshot=ref.get(transaction=transaction)
        if not snapshot.exists: raise HTTPException(404,"Проект не найден")
        data=snapshot.to_dict()
        if data.get("status")!="deleted": raise HTTPException(409,"Восстановить можно только удалённый проект")
        status=data.get("previous_status","completed" if data.get("completed_at") else "active")
        if status not in {"active","completed"}: status="active"
        transaction.update(ref,{"status":status,"restored_at":now(),"restored_by":user["id"]})
        return status
    status=restore(client.transaction()); audit(user["id"],"project.restore","project",project_id)
    return {"status":status}

@app.get("/api/v1/admin/organization")
def organization(user=Depends(require("departments.manage"))):
    client=store(); departments=[as_dict(s) for s in client.collection("departments").order_by("name").stream()]; teams=[as_dict(s) for s in client.collection("teams").order_by("name").stream()]
    return {"departments":departments,"teams":teams}

@app.post("/api/v1/admin/departments",status_code=201)
def create_department(body:DepartmentIn,user=Depends(require("departments.manage"))):
    if first(store().collection("departments").where(filter=FieldFilter("name","==",body.name.strip()))): raise HTTPException(409,"Такой отдел уже существует")
    ref=store().collection("departments").document(); ref.set({"name":body.name.strip(),"created_at":now()}); audit(user["id"],"department.create","department",ref.id); return as_dict(ref.get())

@app.post("/api/v1/admin/teams",status_code=201)
def create_team(body:TeamIn,user=Depends(require("departments.manage"))):
    client=store()
    if not client.collection("departments").document(body.department_id).get().exists: raise HTTPException(422,"Отдел не найден")
    if first(client.collection("teams").where(filter=FieldFilter("name","==",body.name.strip()))): raise HTTPException(409,"Такая команда уже существует")
    ref=client.collection("teams").document(); ref.set({"name":body.name.strip(),"department_id":body.department_id,"created_at":now()}); audit(user["id"],"team.create","team",ref.id); return as_dict(ref.get())

@app.get("/api/v1/admin/settings")
def get_settings(user=Depends(require_super_admin)):
    return store().collection("system_config").document("settings").get().to_dict() or {}

@app.patch("/api/v1/admin/settings")
def update_settings(body:SettingsIn,user=Depends(require_super_admin)):
    patch={key:value for key,value in body.model_dump().items() if value is not None}; patch["updated_at"]=now()
    store().collection("system_config").document("settings").set(patch,merge=True); audit(user["id"],"system.settings.update","settings","settings")
    return store().collection("system_config").document("settings").get().to_dict()

@app.get("/api/v1/admin/notifications")
def admin_notifications(user=Depends(require_super_admin)):
    return sorted([as_dict(s) for s in store().collection("notifications").stream()],key=lambda item:item.get("created_at",""),reverse=True)[:100]

@app.post("/api/v1/admin/notifications",status_code=201)
def create_notification(body:NotificationIn,user=Depends(require_super_admin)):
    if body.audience=="role" and body.role not in ROLE_LABELS: raise HTTPException(422,"Укажите существующую роль")
    ref=store().collection("notifications").document(); ref.set({"title":body.title.strip(),"message":body.message.strip(),"audience":body.audience,"role":body.role if body.audience=="role" else None,"created_by":user["id"],"created_at":now()}); audit(user["id"],"notification.create","notification",ref.id)
    return as_dict(ref.get())

@app.get("/api/v1/admin/system-errors")
def system_errors(user=Depends(require_super_admin)):
    return sorted([as_dict(s) for s in store().collection("system_errors").stream()],key=lambda item:item.get("created_at",""),reverse=True)[:100]

@app.get("/api/v1/admin/data-export")
def data_export(user=Depends(require_super_admin)):
    client=store(); safe_collections=["departments","teams","project_categories","projects","applications","notifications"]
    payload={collection:[as_dict(s) for s in client.collection(collection).stream()] for collection in safe_collections}
    audit(user["id"],"admin.data_export","system","firestore")
    return Response(content=json.dumps(payload,ensure_ascii=False,indent=2),media_type="application/json; charset=utf-8",headers={"Content-Disposition":'attachment; filename="jas-firestore-export.json"'})

def media_storage():
    try: return storage_bucket()
    except Exception: raise HTTPException(503,"Firebase Storage не настроен")

@app.get("/api/v1/admin/media")
def admin_media(user=Depends(require_super_admin)):
    return sorted([as_dict(s) for s in store().collection("media").stream()],key=lambda item:item.get("created_at",""),reverse=True)[:100]

@app.post("/api/v1/admin/media",status_code=201)
async def upload_media(file:UploadFile=File(...),category:str="general",user=Depends(require_super_admin)):
    allowed={"image/jpeg","image/png","image/webp","application/pdf"}
    if file.content_type not in allowed: raise HTTPException(422,"Разрешены JPG, PNG, WEBP и PDF")
    content=await file.read()
    if not content or len(content)>10*1024*1024: raise HTTPException(422,"Размер файла должен быть от 1 байта до 10 МБ")
    safe_category="".join(char for char in category.lower() if char.isalnum() or char in "_-") or "general"
    safe_name="".join(char for char in Path(file.filename or "file").name if char.isalnum() or char in "._-") or "file"
    object_path=f"media/{safe_category}/{uuid4().hex}_{safe_name}"; blob=media_storage().blob(object_path); blob.upload_from_string(content,content_type=file.content_type)
    ref=store().collection("media").document(); ref.set({"object_path":object_path,"filename":safe_name,"content_type":file.content_type,"size":len(content),"category":safe_category,"uploaded_by":user["id"],"created_at":now()}); audit(user["id"],"media.upload","media",ref.id)
    return as_dict(ref.get())

@app.get("/api/v1/admin/media/{media_id}/download")
def download_media(media_id:str,user=Depends(require_super_admin)):
    snapshot=store().collection("media").document(media_id).get()
    if not snapshot.exists: raise HTTPException(404,"Файл не найден")
    item=snapshot.to_dict(); data=media_storage().blob(item["object_path"]).download_as_bytes(); audit(user["id"],"media.download","media",media_id)
    return Response(content=data,media_type=item.get("content_type","application/octet-stream"),headers={"Content-Disposition":f'attachment; filename="{item.get("filename","download")}"'})

@app.delete("/api/v1/admin/media/{media_id}")
def delete_media(media_id:str,user=Depends(require_super_admin)):
    ref=store().collection("media").document(media_id); snapshot=ref.get()
    if not snapshot.exists: raise HTTPException(404,"Файл не найден")
    media_storage().blob(snapshot.to_dict()["object_path"]).delete(); ref.delete(); audit(user["id"],"media.delete","media",media_id)
    return {"status":"deleted"}

# Additional BETA workflows share the same authentication and Firestore client.
from .beta import install
install(app)
from .profile_security import install as install_profile_security
install_profile_security(app)
from .profile_v11 import install as install_profile_v11
install_profile_v11(app)
from .member_profiles import install as install_member_profiles
install_member_profiles(app)
from .community import install as install_community
install_community(app)
from .attendance import install as install_attendance
install_attendance(app)
from .volunteer_hours import install as install_volunteer_hours
install_volunteer_hours(app)
from .project_completion import install as install_project_completion
install_project_completion(app)
from .ai.routes import install as install_ai
install_ai(app)
from .ai.admin import install as install_ai_admin
install_ai_admin(app)

if os.getenv('JAS_SERVE_FRONTEND', 'false').lower() == 'true':
    from .web_hosting import install as install_web_hosting
    install_web_hosting(app)

# Rate limiting runs before authentication/maintenance and their Firestore reads.
# CORS remains outermost so browsers can read 429 responses.
from .rate_limit import RateLimitMiddleware
app.add_middleware(RateLimitMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000","http://127.0.0.1:3000"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"], expose_headers=["Retry-After"])

"""Optional same-origin frontend for a single free web-service deployment."""
from pathlib import Path

from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse


def install(app):
    @app.get('/healthz', include_in_schema=False)
    def health():
        return {'status': 'ok'}

    # Registered before the static mount: unknown API paths must remain JSON 404s.
    @app.api_route('/api/{path:path}', methods=['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'], include_in_schema=False)
    def unknown_api(path: str):
        return JSONResponse({'detail': 'API route not found'}, status_code=404)

    root = Path(__file__).resolve().parents[2] / 'frontend'
    app.mount('/', StaticFiles(directory=root, html=True), name='frontend')

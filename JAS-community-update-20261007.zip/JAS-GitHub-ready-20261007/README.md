# JAS Volunteers — BETA

Рабочее ядро BETA: регистрация и серверные сессии, профиль, роли/права, каталог проектов, заявки, их рассмотрение и audit log.

Добавлены [волонтёрские часы, история и уведомления](docs/VOLUNTEER_HOURS.md).
Для начисления руководителю нужно выдать `hours.manage` в настройках его роли.

## Запуск

Нужен Python 3.10+.

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Во втором терминале раздайте статический frontend:

```powershell
cd frontend
py ../backend/serve_frontend.py
```

Откройте `http://localhost:3000`. API будет доступен по `http://127.0.0.1:8000/docs`.

## Первый Super Admin

Скопируйте `backend/.env.example` в `backend/.env`, замените email и пароль на уникальные значения, затем перезапустите API. При запуске аккаунт будет создан (или существующему аккаунту с этим email будет назначена роль `super_admin`). После входа откройте `http://127.0.0.1:3000/admin.html`.

Для production задайте `COOKIE_SECURE=true`, используйте HTTPS и храните секреты только в переменных окружения. Основная БД приложения — Firestore.

## Firebase Admin (подготовлено безопасно)

После отзыва старого ключа создайте новый ключ Service Account. Сохраните JSON локально как `backend/firebase-service-account.json` — этот путь уже исключён из Git. В `backend/.env` добавьте `FIREBASE_SERVICE_ACCOUNT_PATH=./firebase-service-account.json` и `FIREBASE_PROJECT_ID=...`. Ключ используется только FastAPI backend; во frontend он не передаётся. После перезапуска Super Admin может проверить инициализацию через `GET /api/v1/admin/firebase-status`.

Чтобы включить загрузку файлов из панели разработчика, сначала активируйте **Firebase Storage** в консоли Firebase, затем укажите фактическое имя bucket в `FIREBASE_STORAGE_BUCKET` (например, `имя-проекта.firebasestorage.app`). Не добавляйте Service Account JSON в репозиторий.

## Firestore как основная БД

Backend использует Firestore как основное хранилище. Чтобы перенести созданные ранее локальные BETA-данные из SQLite один раз, выполните из папки `backend`:

```powershell
.\.venv\Scripts\python.exe -m app.migrate_sqlite_to_firestore
```

Скрипт делает только upsert в Firestore и не удаляет SQLite-файл. После проверки Firestore SQLite больше не используется API.

## Роли

Новые пользователи получают роль `volunteer`. Роли и разрешения хранятся в Firestore и проверяются сервером. Super Admin может менять роль пользователя, блокировать аккаунт и настраивать разрешения ролей в `admin.html`.

## Панель разработчика

JAS AI: [первый этап](docs/JAS_AI_IMPLEMENTATION.md) и [управление с подтверждением](docs/JAS_AI_MANAGEMENT.md). Режим управления доступен разработчику на `ai.html`; модель не получает прямой доступ к базе, ключам или серверу.

`admin.html` доступна только роли `super_admin`. В ней есть сведения о Firestore, пользователи и роли, журнал действий, восстановление удалённых проектов, отделы и команды, системные настройки, объявления, экспорт безопасных коллекций, журнал ошибок и медиафайлы Firebase Storage.

## Структура доступа

Сначала Super Admin создаёт отдел, затем при необходимости команду внутри этого отдела. В карточке пользователя назначаются отдел и команда. Председатель, заместитель председателя и Super Admin имеют глобальный доступ; старший координатор, координатор и заместитель координатора видят и управляют проектами и заявками только своего отдела, а тимлидер — только своей команды. Создаваемый руководителем проект автоматически получает его отдел и команду.

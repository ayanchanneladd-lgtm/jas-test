document.addEventListener('DOMContentLoaded',()=>{
  // Render the supplied white logo without its generated preview background.
  // The filter affects presentation only; the source image stays untouched.
  document.body.insertAdjacentHTML('afterbegin', `<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" aria-hidden="true" focusable="false" style="position:absolute"><defs><filter id="jas-logo-cutout" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 10 0 0 -8"/></filter></defs></svg>`);
  document.querySelectorAll('.editorial-hero,.poster-grid').forEach((element,index)=>{
    const band=document.createElement('div');band.className='oyu-band'+(index?' light':'');band.setAttribute('aria-hidden','true');element.after(band);
  });
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches && 'IntersectionObserver' in window) {
    const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('revealed');observer.unobserve(entry.target)}})},{threshold:0.08});
    document.querySelectorAll('.editorial-about,.poster,.home-steps,.join-banner').forEach(element=>{element.classList.add('reveal-ready');observer.observe(element)});
  }
  document.querySelectorAll('nav a').forEach(link=>{if(new URL(link.href).pathname===location.pathname)link.setAttribute('aria-current','page')});
  if(document.querySelector('body>nav')){
    const footer=document.createElement('footer');footer.className='site-footer';footer.innerHTML='<div><b>JAS VOLUNTEERS</b><p>Маленькие действия. Большие перемены.</p></div><a href="/projects.html">Найти своё доброе дело ↗</a>';document.body.append(footer);
  }
  document.querySelectorAll('nav a.font-black, main > .brand, .site-footer b').forEach(element=>{
    const link=document.createElement('a');link.href='/';link.className='jas-logo-link';link.setAttribute('aria-label','JAS Volunteers — на главную');
    link.innerHTML='<img src="/assets/jas-logo.png" alt="JAS Volunteers — Volunteer organization" width="2061" height="763" class="jas-logo-image" decoding="async"><span class="jas-beta" aria-label="Бета-версия"><span class="jas-beta-dot" aria-hidden="true"></span>BETA</span>';
    element.replaceWith(link);
  });
});

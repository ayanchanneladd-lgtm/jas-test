// Additional management tools; identity and authorization are checked on the API.
document.addEventListener('DOMContentLoaded',async()=>{
  const me=await getMe();if(!me||me.role!=='super_admin')return;
  const section=document.createElement('section');section.className='mt-8 rounded-2xl bg-white p-6';
  section.innerHTML='<h2 class="text-xl font-bold">Справочники и статистика BETA</h2><p class="mt-2 text-sm">Используемые отделы, команды и категории удалить нельзя: привязки и история сохраняются.</p><form id="categoryCreate" class="mt-4 flex flex-wrap gap-3"><input name="name" minlength="2" maxlength="120" required placeholder="Название категории" aria-label="Название категории" class="rounded-xl border p-3"><button class="rounded-xl border p-3">Добавить категорию</button></form><div id="betaDirectories"></div><div id="betaAnalytics" class="mt-6"></div><button type="button" id="refreshBeta" class="mt-4 rounded-xl border p-3">Обновить справочники и статистику</button>';
  $('main').append(section);
  async function refresh(){
    try{
      const [org,categories,stats]=await Promise.all([api('/admin/organization'),api('/categories'),api('/admin/analytics')]);
      $('#betaDirectories').innerHTML=[['departments','Отделы',org.departments],['teams','Команды',org.teams],['categories','Категории',categories]].map(([kind,title,rows])=>'<h3 class="mt-5 font-bold">'+title+'</h3>'+rows.map(r=>'<div class="flex flex-wrap items-center gap-2 border-b py-3"><span>'+esc(r.name)+'</span><button type="button" data-kind="'+kind+'" data-id="'+esc(r.id)+'" data-name="'+esc(r.name)+'" data-op="rename" class="rounded-xl border p-2">Переименовать</button><button type="button" data-kind="'+kind+'" data-id="'+esc(r.id)+'" data-op="remove" class="rounded-xl border p-2">Удалить</button></div>').join('')).join('');
      const labels={active:'Активные',deleted:'Удалённые',completed:'Завершённые',pending:'Ожидают',accepted:'Приняты',rejected:'Отклонены',cancelled:'Отменены',no_show:'Не пришли'};
      const counts=data=>Object.entries(data).map(([key,value])=>'<li>'+esc(labels[key]||key)+': '+value+'</li>').join('');
      $('#betaAnalytics').innerHTML='<h3 class="text-xl font-bold">Подробная статистика</h3><p>Аккаунты: '+stats.users+' · Активны (не заблокированы): '+stats.active_users+' · Подтверждены: '+stats.verified_users+'</p><h4 class="mt-3 font-bold">Заявки</h4><ul>'+counts(stats.application_statuses)+'</ul><h4 class="mt-3 font-bold">Проекты</h4><ul>'+counts(stats.project_statuses)+'</ul><h4 class="mt-3 font-bold">Роли</h4><ul>'+counts(stats.roles)+'</ul><div class="mt-4 overflow-x-auto"><table class="w-full text-left"><thead><tr><th>Проект</th><th>Заявки</th><th>Занято / мест</th></tr></thead><tbody>'+stats.projects.map(p=>'<tr><td class="p-2">'+esc(p.title)+'</td><td>'+p.applications+'</td><td>'+p.reserved+' / '+p.capacity+'</td></tr>').join('')+'</tbody></table></div>';
    }catch(e){$('#betaDirectories').textContent='Ошибка загрузки: '+e.message}
  }
  $('#refreshBeta').addEventListener('click',refresh);
  $('#categoryCreate').addEventListener('submit',async e=>{
    e.preventDefault();const b=e.target.querySelector('button');b.disabled=true;
    try{await api('/admin/categories',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});e.target.reset();await refresh();toast('Категория создана')}catch(x){toast(x.message,true)}finally{b.disabled=false}
  });
  section.addEventListener('click',async e=>{
    const b=e.target.closest('[data-op]');if(!b)return;b.disabled=true;
    try{
      const path='/admin/'+b.dataset.kind+'/'+encodeURIComponent(b.dataset.id);
      if(b.dataset.op==='rename'){const name=prompt('Новое название:',b.dataset.name);if(name===null)return;await api(path,{method:'PATCH',body:JSON.stringify({name:name.trim()})})}
      else{if(!confirm('Удалить неиспользуемую запись? Отменить удаление нельзя.'))return;await api(path,{method:'DELETE'})}
      await refresh();await load();toast('Справочник обновлён');
    }catch(x){toast(x.message,true)}finally{b.disabled=false}
  });
  let opened = false;
  const openSection = () => {
    if (!opened && location.hash === '#section=directories') { opened = true; refresh(); }
  };
  addEventListener('hashchange', openSection); openSection();
});

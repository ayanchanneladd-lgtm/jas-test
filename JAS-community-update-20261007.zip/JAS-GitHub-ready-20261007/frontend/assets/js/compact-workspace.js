function initCompactWorkspace(main, page) {
  document.body.classList.add('compact-workspace');
  const profile = main.querySelector('section');
  if (page === 'dashboard' && profile && !profile.id) profile.id = 'workspace-overview';
  const definitions = page === 'admin' ? [
    ['overview','Панель',['stats','adminShortcuts']], ['users','Список участников',['users']],
    ['verification','Подтверждение участников',['verificationPanel']],
    ['server','Состояние сервера',['health']], ['settings','Настройки и техработы',['settingsForm']],
    ['roles','Роли и права',['roles']], ['organization','Отделы и команды',['organization']],
    ['deleted','Удалённые проекты',['deletedProjects']], ['announcements','Объявления',['notifications']],
    ['audit','Журнал действий',['logs']], ['errors','Ошибки API',['errors']],
    ['media','Файлы',['mediaList']], ['directories','Справочники и статистика',['betaDirectories']]
  ] : page === 'coordinator' ? [
    ['overview','Рабочая панель',['coordinatorIntro']],
    ['projects','Проекты команды',['managedProjects','completedProjects']],
    ['create','Создать проект',['projectManagement']],
    ['applications','Заявки и участие',['management','attendanceManagement']],
    ['reports','Отчёты',['auditExport']], ['organization','Отделы и команды',['organizationPanel']],
    ['verification','Подтверждение участников',['verificationPanel']]
  ] : [
    ['overview','Обзор',['participationStats','nearestProject']],
    ['projects','Мои участия',['apps']],
    ['hours','Мои часы',['volunteerHours']], ['notifications','Уведомления',['inbox']],
    ['profile','Профиль и безопасность',['workspace-overview','profileSecurity']]
  ];
  const bar = document.createElement('header'); bar.className = 'compact-toolbar';
  bar.innerHTML = '<h1 tabindex="-1"></h1><button type="button" class="workspace-menu-button" aria-label="Открыть меню разделов" aria-haspopup="dialog" aria-expanded="false"><span aria-hidden="true">☰</span> Разделы</button>';
  main.before(bar);
  const title = bar.querySelector('h1'), trigger = bar.querySelector('button');
  const shell = document.createElement('div'); shell.className = 'workspace-shell';
  const content = document.createElement('div'); content.className = 'workspace-content';
  const sidebar = document.createElement('nav'); sidebar.className = 'workspace-sidebar'; sidebar.setAttribute('aria-label','Разделы кабинета');
  bar.before(shell); shell.append(sidebar, content); content.append(bar, main);
  const quick = document.createElement('nav'); quick.className = 'workspace-quick'; quick.setAttribute('aria-label','Основные разделы'); bar.after(quick);
  const loading = document.createElement('p'); loading.className = 'section-load-status'; loading.setAttribute('role','status'); loading.textContent = 'Загружаем раздел…'; quick.after(loading);
  const primary = page === 'admin' ? ['overview','users','settings'] : page === 'coordinator' ? ['overview','projects','applications','create'] : ['overview','projects','hours','notifications'];
  const menu = document.createElement('dialog'); menu.className = 'workspace-menu';
  menu.innerHTML = '<header><h2>ПАНЕЛЬ</h2><button type="button" aria-label="Закрыть меню">✕</button></header><nav aria-label="Разделы панели"></nav>';
  document.body.append(menu);
  trigger.onclick = () => { menu.showModal(); trigger.setAttribute('aria-expanded','true'); };
  menu.querySelector('button').onclick = () => menu.close();
  menu.addEventListener('click', event => { if (event.target === menu) menu.close(); });
  menu.addEventListener('close', () => { trigger.setAttribute('aria-expanded','false'); trigger.focus(); });
  const links = new Map();
  if (page === 'admin') {
    const shortcuts = document.createElement('div'); shortcuts.id='adminShortcuts'; shortcuts.className='admin-shortcuts';
    const entries = [['users','Участники','Аккаунты, роли и доступ'],['settings','Настройки и техработы','Название платформы и доступность сайта'],['server','Состояние системы','Подключение и системная информация'],['announcements','Объявления','Сообщение участникам платформы']];
    for (const [key,label,description] of entries) {
      const link=document.createElement('a'); link.href='#section='+key; link.textContent=label;
      const detail=document.createElement('small'); detail.textContent=description; link.append(detail); shortcuts.append(link);
    }
    main.prepend(shortcuts);
  }
  const visibleLinks = new Map();
  const groups = new Map();
  const groupFor = key => key === 'overview' ? null : ['users','verification','roles'].includes(key) ? 'Участники и доступ' : ['organization','directories','deleted','media'].includes(key) ? 'Структура и материалы' : ['announcements'].includes(key) ? 'Объявления' : 'Система и обслуживание';
  function groupHost(key, root, suffix) {
    const name = page === 'admin' && groupFor(key);
    if (!name) return root;
    const id = name + suffix;
    if (!groups.has(id)) {
      const details = document.createElement('details'); details.className = 'workspace-nav-group';
      const summary = document.createElement('summary'); summary.textContent = name; details.append(summary);
      root.append(details); groups.set(id, details);
    }
    return groups.get(id);
  }
  for (const [key,label] of definitions) {
    const link = document.createElement('a'); link.href = '#section=' + key; link.textContent = label;
    groupHost(key, menu.querySelector('nav'), 'menu').append(link); links.set(key,link);
    link.onclick = () => { menu.close(); if (location.hash === link.hash) render(true); };
    const desktop = link.cloneNode(true); groupHost(key, sidebar, 'sidebar').append(desktop);
    const copies = [desktop];
    if (primary.includes(key)) {
      const mobile = link.cloneNode(true);
      mobile.textContent = ({overview:'Обзор',users:'Участники',settings:'Настройки',applications:'Заявки',hours:'Мои ВЧ',projects:'Проекты',create:'Создать'})[key] || label;
      quick.append(mobile); copies.push(mobile);
    }
    visibleLinks.set(key, copies);
  }
  function owner(id) {
    const target = document.getElementById(id);
    if (!target || !main.contains(target)) return null;
    if (page === 'admin' && target.closest('article')) return target.closest('article');
    let node = target;
    while (node.parentElement !== main && node.parentElement) node = node.parentElement;
    return node;
  }
  let currentKey = null, workspaceUser = null;
  function render(navigate = false) {
    const hash = location.hash.slice(1);
    const selected = definitions.find(([key,,ids]) => hash === 'section=' + key || ids.includes(hash)) || definitions[0];
    title.textContent = selected[1];
    loading.hidden = selected[2].some(id => {
      const node = owner(id); return node && !node.hidden && !node.classList.contains('hidden');
    }) || !!document.getElementById('dashboardLoadStatus')?.textContent;
    loading.replaceChildren(document.createTextNode('Загружаем раздел…'));
    const required = {projects:'projects.manage',create:'projects.manage',applications:'applications.review',reports:'audit.export',organization:'departments.manage'}[selected[0]];
    if (!loading.hidden && page === 'coordinator' && workspaceUser && required && !can(workspaceUser, required)) loading.textContent = 'Этот раздел недоступен для вашей роли. Выберите другой раздел в меню.';
    const overviewRetry = selected[0] === 'overview' && main.querySelector('#apps [data-load-error] button');
    if (!loading.hidden && overviewRetry) {
      loading.textContent = 'Не удалось загрузить обзор. ';
      const retry = document.createElement('button'); retry.type = 'button'; retry.textContent = 'Повторить загрузку';
      retry.onclick = () => { retry.disabled = true; overviewRetry.click(); };
      loading.append(retry);
    }
    const assigned = new Set();
    for (const [key,,ids] of definitions) {
      const nodes = [...new Set(ids.map(owner).filter(Boolean))];
      const available = nodes.some(node => !node.classList.contains('hidden') && !node.hidden);
      links.get(key).hidden = !available && key !== 'overview';
      if (key === selected[0]) { links.get(key).setAttribute('aria-current','page'); if (links.get(key).parentElement.tagName === 'DETAILS') links.get(key).parentElement.open = true; }
      else links.get(key).removeAttribute('aria-current');
      for (const copy of visibleLinks.get(key)) {
        copy.hidden = links.get(key).hidden;
        if (key === selected[0]) { copy.setAttribute('aria-current','page'); if (copy.parentElement.tagName === 'DETAILS') copy.parentElement.open = true; }
        else copy.removeAttribute('aria-current');
      }
      for (const node of nodes) { assigned.add(node); node.classList.toggle('workspace-inactive', key !== selected[0]); }
    }
    // Hide empty two-column wrappers while keeping the original forms and IDs intact.
    for (const node of main.children) {
      if (node.id === 'dashboardLoadStatus') continue;
      if (assigned.has(node)) continue;
      const panels = [...assigned].filter(panel => node.contains(panel));
      node.classList.toggle('workspace-inactive', panels.length ? panels.every(panel => panel.classList.contains('workspace-inactive')) : selected[0] !== 'overview');
      if (panels.length) node.classList.add('workspace-panel-row');
    }
    if (selected[0] === 'create' && currentKey !== 'create') document.getElementById('projectForm')?.classList.remove('hidden');
    if (currentKey !== selected[0]) {
      currentKey = selected[0];
      document.dispatchEvent(new CustomEvent('jas:section', {detail:{key:currentKey}}));
    }
    if (navigate) { title.focus({preventScroll:true}); window.scrollTo({top:0,behavior:'instant'}); }
  }
  addEventListener('hashchange', () => render(true));
  // New sections are added after the authenticated API responses arrive.
  let scheduled = false;
  new MutationObserver(records => {
    // Text changes, button decorations and focus styles do not change navigation.
    if (scheduled || !records.some(record => [...record.addedNodes, ...record.removedNodes].some(node => node.nodeType === 1 && (node.matches('section,article,[data-load-error]') || node.querySelector('section'))))) return;
    scheduled = true; requestAnimationFrame(() => { scheduled = false; render(); });
  }).observe(main, {childList:true,subtree:true});
  document.addEventListener('jas:user', event => { workspaceUser=event.detail; requestAnimationFrame(() => render()); });
  render();
}

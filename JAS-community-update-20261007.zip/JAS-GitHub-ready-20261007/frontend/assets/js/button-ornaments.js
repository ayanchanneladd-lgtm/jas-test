// Delegation also covers controls rendered later by the dashboard and AI panel.
(() => {
  const motion = matchMedia('(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)');
  const selector = 'button:not(.verified-badge), a.rounded-xl, a.button, a.primary-button';
  document.addEventListener('pointerover', event => {
    if (!motion.matches || document.body.classList.contains('compact-workspace') || !(event.target instanceof Element)) return;
    const button = event.target.closest(selector);
    if (!button || button.matches(':disabled, [aria-disabled="true"], [aria-busy="true"]')) return;
    button.classList.add('oyu-hover-button');
    if (button.querySelector(':scope > .oyu-air')) return;
    const ornaments = document.createElement('span');
    ornaments.className = 'oyu-air';
    ornaments.setAttribute('aria-hidden', 'true');
    for (let i = 0; i < 3; i++) ornaments.append(document.createElement('span'));
    button.append(ornaments);
  });
})();

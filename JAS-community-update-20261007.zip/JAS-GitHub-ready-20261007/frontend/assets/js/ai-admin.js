/* Management data stays local. Only the separate nonconfidential task text
 * and static schema are sent to Gemini by /draft. No automatic execution. */
(() => {
  const labels = {title:'Название',description:'Описание',location:'Место',starts_at:'Дата и время (ISO, с часовым поясом)',
    capacity:'Количество мест',category_id:'ID категории (только локально)',image_url:'Ссылка на фото',requirements:'Требования',
    reason:'Причина',status:'Статус: accepted или rejected',role:'Код роли',active:'Аккаунт активен',
    department_id:'ID отдела (только локально)',team_id:'ID команды (только локально)',verified:'Подтверждённый участник',
    permissions:'Permissions (JSON-массив)',hours:'Продолжительность в часах',platform_name:'Название платформы',
    beta_mode:'BETA-режим',message:'Текст уведомления',audience:'Аудитория: all или role',name:'Название'};
  const el = (tag, text, cls) => { const node=document.createElement(tag); if(text)node.textContent=text;if(cls)node.className=cls;return node; };
  document.addEventListener('DOMContentLoaded', async () => {
    const host=document.querySelector('[data-ai-admin]'); if(!host)return;
    const me=await getMe();
    if(!me || me.role!=='super_admin' || !can(me,'ai.admin') || !can(me,'ai.access') || !can(me,'ai.chat'))return;
    host.hidden=false;
    host.innerHTML=`<h2>Управление платформой</h2>
      <p>AI готовит черновик — ты проверяешь и подтверждаешь. Все изменения требуют отдельного подтверждения. Имена и ID из полей ниже не отправляются Gemini.</p>
      <p role="status" aria-live="polite" data-admin-status>Загрузка…</p>
      <div class="jas-ai-toolbar"><button type="button" data-summary>Получить обезличенную сводку</button><button type="button" data-reload>Обновить предложение</button></div>
      <pre data-summary-output></pre>
      <label>Операция<select data-action></select></label>
      <label data-target-label>Объект<select data-target></select></label><p data-target-note></p>
      <label data-manual-label>ID объекта вручную (если его нет в первых 100 результатах)<input data-manual-target maxlength="150" pattern="[\\w-]*"></label>
      <details><summary>Попросить AI заполнить параметры</summary>
      <p>Опиши задачу без имён, ID, персональных данных и секретов. AI не получает выбранный объект и текущие поля. ID и даты проверь вручную.</p>
      <textarea data-draft-message maxlength="3000" rows="3" placeholder="Например: причина удаления — мероприятие отменено"></textarea>
      <label class="jas-ai-consent"><input type="checkbox" data-draft-consent> Мне 18+, текст не содержит личных, секретных и конфиденциальных данных.</label>
      <button type="button" data-draft>Подготовить черновик AI</button></details>
      <form data-operation><div data-fields></div><button type="submit">Проверить и подготовить операцию</button></form>
      <section data-proposal aria-label="Подтверждение действия"></section>`;
    const status=host.querySelector('[data-admin-status]'), select=host.querySelector('[data-action]');
    const targets=host.querySelector('[data-target]'), manual=host.querySelector('[data-manual-target]');
    const fields=host.querySelector('[data-fields]'), proposalHost=host.querySelector('[data-proposal]');
    let actions=[], selected=null, busy=false, revision=0, controls={}, draftRequest=null;
    function locked(value){busy=value;host.querySelectorAll('button').forEach(b=>b.disabled=value);select.disabled=value;targets.disabled=value;manual.disabled=value;}
    function fill(params){
      Object.entries(controls).forEach(([key,{input,enabled,type}])=>{
        if(!(key in params))return;
        enabled.checked=true;
        input.value=params[key]===null?'null':type==='array'?JSON.stringify(params[key]):String(params[key]);
      });
    }
    function renderFields(schema){
      fields.replaceChildren();controls={};
      Object.entries(schema.properties||{}).forEach(([key,rule])=>{
        const type=rule.type || rule.anyOf?.find(x=>x.type!=='null')?.type || 'string';
        const row=el('div',null,'jas-ai-field'), label=el('label',labels[key]||key);
        const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=(schema.required||[]).includes(key);
        enabled.setAttribute('aria-label','Изменить '+(labels[key]||key));
        const include=el('label','Включить поле ');include.prepend(enabled);row.append(include,label);
        let input;
        if(type==='boolean'){input=el('select');['true','false'].forEach(value=>input.append(new Option(value,value)));}
        else {input=el('textarea');input.rows=type==='array'||['description','requirements','message'].includes(key)?3:1;input.maxLength=rule.maxLength||8000;}
        input.setAttribute('aria-label',labels[key]||key);input.dataset.parameter=key;label.append(input);
        if(rule.anyOf?.some(x=>x.type==='null'))row.append(el('small','Пустое значение не очищает поле. Для очистки nullable-поля укажите null.'));
        controls[key]={input,enabled,type};fields.append(row);
      });
    }
    async function changeAction(){
      const current=++revision; selected=actions.find(x=>x.key===select.value);draftRequest=null;manual.value='';
      targets.replaceChildren(new Option('Выберите объект',''));renderFields(selected.schema);
      const needs=selected.collection && selected.collection!=='settings';
      host.querySelector('[data-target-label]').hidden=!needs;host.querySelector('[data-manual-label]').hidden=!needs;
      try {
        const data=await api('/ai/admin/targets/'+encodeURIComponent(selected.key));if(current!==revision)return;
        (data.items||[]).forEach(row=>targets.append(new Option(row.label+' · '+row.id+(row.status?' · '+row.status:''),row.id)));
        host.querySelector('[data-target-note]').textContent=data.limited?'Показаны первые 100 объектов. При необходимости укажите точный ID вручную.':'';
      }catch(e){status.textContent=e.message;}
    }
    function showProposal(proposal){
      proposalHost.replaceChildren();if(!proposal)return;
      proposalHost.append(el('h3','Предложение: '+(actions.find(a=>a.key===proposal.action)?.label||proposal.action)),
        el('p','Объект: '+proposal.label+(proposal.target?' · '+proposal.target:'')),
        el('p','Текущие значения затрагиваемых полей:'),el('pre',JSON.stringify(proposal.before||{},null,2)),
        el('p','Будут переданы следующие параметры:'),
        el('pre',JSON.stringify(proposal.parameters,null,2)),
        el('p','Статус: '+proposal.state+' · Действительно до '+new Date(proposal.expires*1000).toLocaleString('ru-RU')));
      if(proposal.state!=='pending'){proposalHost.append(el('p','Повторное выполнение этого предложения запрещено. При unknown/executing проверьте результат вручную.'));return;}
      const check=el('input');check.type='checkbox';const label=el('label',' Я проверил объект и все параметры этой конкретной операции.');label.prepend(check);
      const confirm=el('button','Подтвердить и выполнить'),cancel=el('button','Отменить');confirm.type=cancel.type='button';
      confirm.dataset.confirmAction='';cancel.dataset.cancelAction='';proposalHost.append(label,confirm,cancel);
      async function decide(yes){
        if(busy)return;if(yes&&!check.checked){status.textContent='Сначала проверьте параметры и поставьте отметку подтверждения.';return;}
        locked(true);
        try{const result=await api('/ai/admin/proposals/'+proposal.id+'/decision',{method:'POST',body:JSON.stringify({confirm:yes})});
          status.textContent=result.detail||('Статус: '+result.state);await reload();
        }catch(e){status.textContent=e.message+' Обновите предложение; не повторяйте действие вслепую.';}
        finally{locked(false);}
      }
      confirm.onclick=()=>decide(true);cancel.onclick=()=>decide(false);
    }
    async function reload(){const data=await api('/ai/admin/proposal');showProposal(data.proposal);}
    select.onchange=changeAction;
    host.querySelector('[data-operation]').onsubmit=async event=>{
      event.preventDefault();if(busy)return;locked(true);
      try{
        const parameters={};Object.entries(controls).forEach(([key,{input,enabled,type}])=>{
          if(!enabled.checked)return;const value=input.value;
          parameters[key]=value==='null'?null:type==='boolean'?value==='true':['number','integer'].includes(type)?Number(value):type==='array'?JSON.parse(value):value;
        });
        const result=await api('/ai/admin/prepare',{method:'POST',body:JSON.stringify({action:selected.key,target:manual.value.trim()||targets.value,parameters})});
        showProposal(result);status.textContent='Предложение готово. Ничего ещё не изменено. Подтверждение действует 10 минут.';
      }catch(e){status.textContent=e.message;}finally{locked(false);}
    };
    host.querySelector('[data-draft]').onclick=async()=>{
      if(busy)return;
      const message=host.querySelector('[data-draft-message]').value.trim();
      if(!message || !host.querySelector('[data-draft-consent]').checked){status.textContent='Введите обезличенную задачу и подтвердите отсутствие закрытых данных.';return;}
      locked(true);
      try{
        if(!draftRequest||draftRequest.message!==message||draftRequest.action!==selected.key){
          const history=await api('/ai/admin/draft/history',{method:'POST'});
          draftRequest={message,action:selected.key,privacy_confirmed:true,request_id:crypto.randomUUID(),conversation_id:history.conversation_id};
        }
        const result=await api('/ai/admin/draft',{method:'POST',body:JSON.stringify(draftRequest),signal:AbortSignal.timeout(45000)});
        fill(result.parameters);draftRequest=null;status.textContent='AI заполнил черновик. Проверьте поля: действие не выполнено и не подтверждено.';
      }catch(e){status.textContent=e.message;}finally{locked(false);}
    };
    host.querySelector('[data-reload]').onclick=async()=>{if(busy)return;try{await reload();}catch(e){status.textContent=e.message;}};
    host.querySelector('[data-summary]').onclick=async()=>{
      if(busy)return;locked(true);
      try{const data=await api('/ai/admin/summary');host.querySelector('[data-summary-output]').textContent=JSON.stringify(data,null,2);
        status.textContent='Это ограниченная выборка, не полная статистика. Содержит только количества; Gemini не вызывался.';
      }catch(e){status.textContent=e.message;}finally{locked(false);}
    };
    try{const data=await api('/ai/admin/catalog');actions=data.actions;
      actions.forEach(action=>select.append(new Option(action.label,action.key)));await changeAction();await reload();status.textContent='Режим разработчика. Любая запись — только после подтверждения.';
    }catch(e){status.textContent=e.message;}
  });
})();

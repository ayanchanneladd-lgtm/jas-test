(() => {
  const escape = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let user, revision=-1, loading=false, sending=false, stopped=false, requestId=null, requestText='', lastRefresh=0;
  const rows=new Map(), scroll=$('#chatScroll');
  const status = value => { $('#chatStatus').textContent=value; };
  function bottom() { scroll.scrollTop=scroll.scrollHeight; $('#chatNew').hidden=true; }
  function render() {
    $('#chatMessages').innerHTML=[...rows.values()].sort((a,b)=>a.seq-b.seq).map(row=>{
      const name=row.user_id ? `<a href="members.html?id=${encodeURIComponent(row.user_id)}">${verifiedName(row.full_name,row.verified,false)}</a>` : escape(row.full_name);
      const date=new Date(row.created_at);
      return `<article role="listitem" class="chat-message ${row.user_id===user.id?'chat-own':''}" data-id="${escape(row.id)}"><header>${name}${activeVolunteerBadge(row.active_volunteer)}<time datetime="${escape(row.created_at)}">${escape(Number.isNaN(date.getTime())?'':date.toLocaleString('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}))}</time></header><p class="chat-body ${row.deleted?'chat-deleted':''}">${escape(row.deleted?'Сообщение удалено':row.text)}</p>${row.can_delete?`<button class="chat-delete" type="button" data-delete="${escape(row.id)}" aria-label="Удалить сообщение">Удалить</button>`:''}</article>`;
    }).join('') || '<p class="chat-empty">Пока тихо. Начните знакомство с командой!</p>';
  }
  function failure(error) {
    if(error.status===401) { stopped=true;$('#chatRoom').hidden=true;$('#chatLogin').hidden=false;status('Войдите в аккаунт, чтобы читать и отправлять сообщения.'); }
    else { status(error.message || 'Не удалось связаться с сервером.');$('#chatRetry').hidden=false; }
  }
  async function load(older=false, force=false) {
    if(loading || stopped || document.hidden)return;
    loading=true;
    const nearBottom=scroll.scrollHeight-scroll.scrollTop-scroll.clientHeight<90;
    const height=scroll.scrollHeight, position=scroll.scrollTop;
    $('#chatOlder').disabled=true;
    try {
      const before=older && rows.size ? Math.min(...[...rows.values()].map(row=>row.seq)) : 0;
      const refresh=force || Date.now()-lastRefresh>60000;
      const data=await api('/chat/messages?'+new URLSearchParams({revision:refresh?-1:revision,before}));
      if(!data.unchanged) {
        // Refresh the visible window after changes so deleted historical text
        // cannot remain in a stale, previously loaded page.
        if(!older) {rows.clear();revision=data.revision;lastRefresh=Date.now();}
        for(const row of data.items)rows.set(row.id,row);
        if(older || rows.size<=50)$('#chatOlder').hidden=!data.has_more;
        render();
        if(older)scroll.scrollTop=position+scroll.scrollHeight-height;
        else if(nearBottom || force)bottom();
        else {scroll.scrollTop=position;$('#chatNew').hidden=false;}
      }
      $('#chatRetry').hidden=true;status('');
    } catch(error) {failure(error);}
    finally {loading=false;$('#chatOlder').disabled=false;}
  }
  $('#chatForm').addEventListener('submit',async event=>{
    event.preventDefault();if(sending || stopped)return;
    const text=$('#chatText').value.trim();if(!text)return;
    if(text!==requestText || !requestId){requestText=text;requestId=crypto.randomUUID();}
    sending=true;$('#chatSend').disabled=true;$('#chatText').readOnly=true;status('Отправляем…');
    try {
      await api('/chat/messages',{method:'POST',body:JSON.stringify({client_id:requestId,text})});
      requestId=null;requestText='';$('#chatText').value='';$('#chatCount').textContent='0 / 2000';
      revision=-1;status('Сообщение отправлено');await load(false,true);
    } catch(error){failure(error);}
    finally{sending=false;$('#chatSend').disabled=false;$('#chatText').readOnly=false;}
  });
  $('#chatText').addEventListener('input',event=>{$('#chatCount').textContent=event.target.value.length+' / 2000';});
  $('#chatText').addEventListener('keydown',event=>{if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)){event.preventDefault();$('#chatForm').requestSubmit();}});
  $('#chatMessages').addEventListener('click',async event=>{
    const button=event.target.closest('[data-delete]');if(!button || !confirm('Удалить это сообщение из общего чата?'))return;
    button.disabled=true;
    try {
      await api('/chat/messages/'+encodeURIComponent(button.dataset.delete),{method:'DELETE'});
      const row=rows.get(button.dataset.delete);if(row){row.deleted=true;row.text='';row.can_delete=false;render();}
      revision=-1;await load();
    } catch(error){button.disabled=false;failure(error);}
  });
  $('#chatOlder').onclick=()=>load(true);
  $('#chatNew').onclick=bottom;
  $('#chatRetry').onclick=async()=>{if(!user)await start();else await load(false,true);};
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)load(false,true);});
  async function start(){try{user=await getMe({throwOnError:true});$('#chatRoom').hidden=false;await load(false,true);}catch(error){failure(error);}}
  start();setInterval(()=>load(),12000);
})();

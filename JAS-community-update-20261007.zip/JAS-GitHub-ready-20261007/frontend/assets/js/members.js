(() => {
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const params = new URLSearchParams(location.search), id = params.get('id');
  let version = 0, controller, timer, offset = 0, viewer;
  const status = message => { $('#memberStatus').textContent = message; };
  const initials = name => String(name || '?').trim().split(/\s+/).slice(0,2).map(word => Array.from(word)[0]).join('').toUpperCase();
  function failure(error) {
    if (error.status === 401) { status('Войдите в аккаунт, чтобы просматривать участников.'); $('#memberLogin').hidden = false; }
    else { status(error.message || 'Не удалось загрузить данные.'); $('#memberRetry').hidden = false; }
  }
  function card(member) {
    return `<a class="member-card" href="members.html?id=${encodeURIComponent(member.id)}"><div class="avatar" aria-hidden="true">${escape(initials(member.full_name))}</div><h2>${verifiedName(member.full_name, member.verified, false)}</h2><div class="handle">@${escape(member.username)}</div><div class="member-status" data-member-status="${escape(member.id)}">${presenceLabel(member.is_online)}${activeVolunteerBadge(member.active_volunteer)}</div><p class="member-role">${escape(member.role_label)}</p></a>`;
  }
  async function search(more = false) {
    clearTimeout(timer);
    const current = ++version;
    controller?.abort(); controller = new AbortController();
    const q = $('#memberQuery').value.trim();
    if (!more) { offset = 0; $('#memberResults').replaceChildren(); }
    $('#memberMore').hidden = true; $('#memberRetry').hidden = true; $('#memberLogin').hidden = true;
    const url = new URL(location.href); q ? url.searchParams.set('q',q) : url.searchParams.delete('q'); history.replaceState(null,'',url);
    if (q.replace(/^@/,'').length < 2) { $('#memberResults').removeAttribute('aria-busy'); status('Введите минимум 2 символа имени или никнейма.'); return; }
    status('Ищем участников…'); $('#memberResults').setAttribute('aria-busy','true');
    try {
      const data = await api('/members?' + new URLSearchParams({q,offset,limit:24}), {signal:controller.signal});
      if (current !== version) return;
      $('#memberResults').insertAdjacentHTML('beforeend',data.items.map(card).join(''));
      offset += data.items.length;
      status(data.total ? `Найдено: ${data.total}. Показано: ${offset}.` : 'Никого не нашли. Попробуйте другое имя или никнейм.');
      $('#memberMore').hidden = !data.has_more;
    } catch (error) { if (current === version) failure(error); }
    finally { if (current === version) $('#memberResults').removeAttribute('aria-busy'); }
  }
  const tags = values => (values || []).length ? `<div class="tags">${values.map(value => `<span class="tag">${escape(value)}</span>`).join('')}</div>` : '<p>Пока не указаны.</p>';
  async function profile() {
    $('#directory').hidden = true; $('#backToMembers').hidden = false; $('#memberRetry').hidden = true;
    status('Загружаем профиль…');
    try {
      const {member} = await api('/members/' + encodeURIComponent(id));
      const date = new Date(member.created_at), joined = member.created_at && !Number.isNaN(date.getTime()) ? date.toLocaleDateString('ru-RU') : 'Не указана';
      document.title = `${member.full_name} — JAS Volunteers`;
      $('#memberProfile').innerHTML = `<header class="profile-hero"><div class="avatar" aria-hidden="true">${escape(initials(member.full_name))}</div><p class="eyebrow handle">УЧАСТНИК JAS</p><h1>${verifiedName(member.full_name, member.verified, false)}</h1><p class="handle">@${escape(member.username)}</p><div id="memberLiveStatus" class="member-status">${presenceLabel(member.is_online)}${activeVolunteerBadge(member.active_volunteer)}</div><div class="profile-actions"><button id="copyProfile" type="button">Скопировать ссылку</button>${viewer?.id === member.id ? '<a href="dashboard.html#section=profile">Редактировать профиль</a>' : ''}</div></header><div class="profile-layout"><div><section class="profile-section"><h2>О себе</h2><p class="bio">${escape(member.about || 'Участник пока не рассказал о себе.')}</p></section><section class="profile-section"><h2>Навыки</h2>${tags(member.skills)}</section><section class="profile-section"><h2>Интересы</h2>${tags(member.interests)}</section></div><aside><section class="profile-section"><h2>Волонтёрский вклад</h2><div class="stat">${escape(Math.floor(member.total_minutes / 60))} ч ${escape(member.total_minutes % 60)} мин</div><p>Подтверждённые волонтёрские часы</p><strong>${escape(member.awarded_project_count)}</strong> проектов с начисленными часами</section><section class="profile-section"><h2>В команде</h2><dl>${[['Роль',member.role_label],['Отдел',member.department_name || 'Не назначен'],['Команда',member.team_name || 'Не назначена'],['На платформе с',joined]].map(([key,value])=>`<dt>${key}</dt><dd>${escape(value)}</dd>`).join('')}</dl></section></aside></div>`;
      $('#memberProfile').hidden = false; status('');
      $('#copyProfile').addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(location.href); status('Ссылка на профиль скопирована.'); }
        catch { status('Не удалось скопировать ссылку. Скопируйте адрес из строки браузера.'); }
      });
    } catch (error) { failure(error); }
  }
  $('#memberQuery').value = params.get('q') || '';
  $('#memberSearch').addEventListener('submit', event => { event.preventDefault(); search(); });
  $('#memberQuery').addEventListener('input', () => { ++version; controller?.abort(); clearTimeout(timer); $('#memberMore').hidden=true; timer=setTimeout(()=>search(),350); });
  $('#memberMore').addEventListener('click', () => search(true));
  $('#memberRetry').addEventListener('click', () => id ? profile() : search());
  setInterval(async()=>{if(!id||document.hidden||!document.getElementById('memberLiveStatus'))return;try{const {member}=await api('/members/'+encodeURIComponent(id));document.getElementById('memberLiveStatus').innerHTML=presenceLabel(member.is_online)+activeVolunteerBadge(member.active_volunteer);}catch{}},60000);
  setInterval(async()=>{if(id||document.hidden)return;const panels=[...document.querySelectorAll('[data-member-status]')];for(let n=0;n<panels.length;n+=48){const group=panels.slice(n,n+48);try{const values=await api('/community/status?'+new URLSearchParams({ids:group.map(el=>el.dataset.memberStatus).join(',')}));for(const el of group){const value=values[el.dataset.memberStatus];if(value)el.innerHTML=presenceLabel(value.is_online)+activeVolunteerBadge(value.active_volunteer);}}catch{}}},60000);
  getMe().then(user => { viewer=user; if (id) profile(); else search(); });
})();

let volunteerApplications = [], volunteerTab = 'all';
const profileTabs = {all:'Все',pending:'Ожидают',accepted:'Приняты',completed:'Завершены',rejected:'Отклонены',cancelled:'Отменены',no_show:'Неявки',excused:'Уважительная причина'};
function renderVolunteerApplications() {
  const tabs=$('#volunteerTabs');
  tabs.innerHTML=Object.entries(profileTabs).map(([key,label])=>{
    const count=key==='all'?volunteerApplications.length:volunteerApplications.filter(a=>a.status===key).length;
    return '<button type="button" aria-pressed="'+(volunteerTab===key)+'" data-profile-tab="'+key+'" class="rounded-xl border px-3 py-2 text-sm '+(volunteerTab===key?'bg-jas text-white':'')+'">'+label+' ('+count+')</button>';
  }).join('');
  const items=volunteerApplications.filter(a=>volunteerTab==='all'||a.status===volunteerTab);
  $('#apps').innerHTML=items.map(a=>applicationRow(a,false)).join('')||'<p class="p-5 text-slate-500">В этой категории пока нет проектов. <a href="projects.html">Посмотреть каталог</a></p>';
}
function renderVolunteerProfile(user, applications) {
  volunteerApplications=applications;
  renderProfileDetails(user);
  if(!$('#participantCard')) {
    $('#meta').insertAdjacentHTML('afterend','<dl id="participantCard" class="mt-4 grid gap-3 sm:grid-cols-2"></dl>');
    $('#profile').closest('section').insertAdjacentHTML('afterend','<section id="participationStats" class="mt-6 rounded-2xl bg-white p-5"><h2 class="text-xl font-bold">Моё участие</h2><div id="participationCounts" class="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4"></div><p class="mt-3 text-sm text-slate-500">Завершённые участия подтверждает координатор. Неявки не публикуются: их видите вы и руководство с соответствующим доступом.</p></section><section id="nearestProject" class="mt-6 rounded-2xl bg-white p-5"></section>');
    $('#apps').previousElementSibling.textContent='Мои проекты';
    $('#apps').insertAdjacentHTML('beforebegin','<div id="volunteerTabs" role="group" aria-label="Статус моих проектов" class="mt-4 flex flex-wrap gap-2"></div>');
    $('#volunteerTabs').addEventListener('click',event=>{
      const target=event.target.closest('[data-profile-tab]');
      if(target){volunteerTab=target.dataset.profileTab;renderVolunteerApplications();}
    });
  }
  const joined=new Date(user.created_at);
  const fields=[['Никнейм','@'+user.username],['JAS ID',user.public_id||'Не указан'],['Отдел',user.department_name||'Не назначен'],['Команда',user.team_name||'Не назначена'],['На платформе с',Number.isNaN(joined.getTime())?'Дата не указана':joined.toLocaleDateString('ru-RU')],['Статус участника',user.verified?'Подтверждён JAS':'Без подтверждения']];
  $('#participantCard').innerHTML=fields.map(([label,value])=>'<div><dt class="text-xs text-slate-500">'+label+'</dt><dd class="font-semibold">'+esc(value)+'</dd></div>').join('');
  const counts=[['Всего заявок',applications.length],['Приняты сейчас',applications.filter(a=>a.status==='accepted').length],['Участий завершено',applications.filter(a=>a.status==='completed').length],['Неявки',applications.filter(a=>a.status==='no_show').length]];
  $('#participationCounts').innerHTML=counts.map(([label,count])=>'<div><b class="block text-2xl text-jas">'+count+'</b><span class="text-sm">'+label+'</span></div>').join('');
  const nearest=applications.filter(a=>a.status==='accepted'&&a.project_status==='active'&&Date.parse(a.starts_at)>=Date.now()).sort((a,b)=>Date.parse(a.starts_at)-Date.parse(b.starts_at))[0];
  $('#nearestProject').innerHTML='<h2 class="text-xl font-bold">Ближайший проект</h2>'+(nearest?'<h3 class="mt-3 font-bold">'+esc(nearest.title)+'</h3><p>'+esc(new Date(nearest.starts_at).toLocaleString('ru-RU'))+'</p><p>'+esc(nearest.location)+'</p><p class="mt-2">Заявка принята</p><a class="mt-3 inline-block rounded-xl border p-3" href="project.html?id='+encodeURIComponent(nearest.project_id)+'">Подробнее о проекте</a>':'<p class="mt-3 text-slate-500">Нет предстоящих проектов с принятой заявкой.</p><a class="mt-3 inline-block" href="projects.html">Найти проект</a>');
  renderVolunteerApplications();
  if(!$('#profileSecurity')) {
    $('main').insertAdjacentHTML('beforeend','<section id="profileSecurity" class="mt-8 rounded-2xl bg-white p-5"><h2 class="text-xl font-bold">Безопасность аккаунта</h2><p class="mt-2 text-sm">После смены пароля потребуется снова войти на всех устройствах.</p><form id="changePasswordForm" class="mt-4 grid max-w-xl gap-3"><label>Текущий пароль<input name="current_password" type="password" autocomplete="current-password" required maxlength="128" class="mt-1 block w-full rounded-xl border p-3"></label><label>Новый пароль<input name="new_password" type="password" autocomplete="new-password" required minlength="8" maxlength="128" class="mt-1 block w-full rounded-xl border p-3"></label><label>Повтор нового пароля<input name="password_confirmation" type="password" autocomplete="new-password" required minlength="8" maxlength="128" class="mt-1 block w-full rounded-xl border p-3"></label><button class="rounded-xl bg-jas p-3 text-white">Изменить пароль</button><p id="securityResult" role="status"></p></form><hr class="my-5"><p class="text-sm">Завершить все сессии, включая текущую. Пароль останется прежним.</p><button type="button" id="logoutAllDevices" class="mt-3 rounded-xl border p-3">Выйти со всех устройств</button></section>');
    $('#changePasswordForm').addEventListener('submit',async event=>{
      event.preventDefault();const form=event.target,submit=form.querySelector('button');
      if(submit.disabled)return;
      const data=Object.fromEntries(new FormData(form));
      if(data.new_password!==data.password_confirmation){$('#securityResult').textContent='Новые пароли не совпадают';return;}
      submit.disabled=true;
      try{const result=await api('/profile/password',{method:'POST',body:JSON.stringify(data)});form.reset();$('#securityResult').textContent=result.message;location.replace('index.html');}
      catch(error){$('#securityResult').textContent=error.message;}
      finally{submit.disabled=false;}
    });
    $('#logoutAllDevices').addEventListener('click',async event=>{
      if(!confirm('Выйти со всех устройств, включая это?'))return;
      const target=event.currentTarget;target.disabled=true;
      try{await api('/profile/logout-all',{method:'POST'});location.replace('index.html');}
      catch(error){$('#securityResult').textContent=error.message;target.disabled=false;}
    });
  }
}

function renderProfileDetails(user) {
  const form = $('#profile');
  if (!$('#viewMemberProfile')) {
    const link = document.createElement('a');
    link.id = 'viewMemberProfile';
    link.textContent = 'Посмотреть мой профиль участника ↗';
    link.className = 'mt-3 inline-block text-jas';
    link.href = 'members.html?id=' + encodeURIComponent(user.id);
    form.before(link);
    const hint = document.createElement('p');
    hint.className = 'mt-2 text-sm text-slate-500';
    hint.textContent = 'Имя, никнейм, описание, навыки и интересы видны другим участникам платформы.';
    form.before(hint);
  }
  if (!$('#profileAbout')) {
    form.insertAdjacentHTML('beforeend', '<label class="sm:col-span-2">О себе<textarea id="profileAbout" name="about" maxlength="1000" rows="4" class="mt-1 block w-full rounded-xl border p-3" placeholder="Расскажите, чем хотите помогать"></textarea></label><label class="sm:col-span-2">Навыки<input id="profileSkills" name="skills" maxlength="1050" class="mt-1 block w-full rounded-xl border p-3" placeholder="Например: фотография, организация мероприятий"><span class="text-xs text-slate-500">Через запятую, до 20 навыков по 50 символов.</span></label><label class="sm:col-span-2">Интересы<input id="profileInterests" name="interests" maxlength="1050" class="mt-1 block w-full rounded-xl border p-3" placeholder="Например: экология, образование"><span class="text-xs text-slate-500">Через запятую, до 20 интересов по 50 символов.</span></label><p id="profileSaveResult" role="status" class="sm:col-span-2"></p>');
    form.append(form.querySelector('button'));
    $('#meta').insertAdjacentHTML('beforebegin', '<div id="profileAvatar" role="img" aria-label="Аватар участника" class="my-4 flex h-20 w-20 items-center justify-center rounded-full bg-jas text-2xl font-bold text-white"></div>');
    form.insertAdjacentHTML('afterend', '<p class="mt-4 text-sm text-slate-500">Аватар: пока используются инициалы. Загрузка изображения будет доступна после подключения безопасного хранилища.</p><section id="profileDetails" class="mt-5" aria-label="Информация обо мне"></section>');
    form.elements.full_name.setAttribute('aria-label', 'Имя и фамилия');
    form.elements.full_name.required = true;
    form.elements.full_name.minLength = 3;
    form.elements.full_name.maxLength = 120;
    form.elements.username.setAttribute('aria-label', 'Никнейм');
    form.elements.username.required = true;
    form.elements.username.pattern = '[A-Za-z0-9_]{3,32}';
  }
  $('#profileAvatar').textContent = (user.full_name || 'JAS').trim().split(/\s+/).slice(0,2).map(x=>Array.from(x)[0]).join('').toUpperCase();
  form.elements.about.value = user.about || '';
  form.elements.skills.value = (user.skills || []).join(', ');
  form.elements.interests.value = (user.interests || []).join(', ');
  $('#profileDetails').innerHTML = '<h2 class="text-lg font-bold">Обо мне</h2><p class="mt-2 whitespace-pre-wrap break-words">'+esc(user.about || 'Вы пока не добавили информацию о себе.')+'</p>'+[['Навыки',user.skills],['Интересы',user.interests]].map(([label,items])=>'<h3 class="mt-3 font-semibold">'+label+'</h3><div class="mt-2 flex flex-wrap gap-2">'+((items||[]).map(x=>'<span class="max-w-full break-words rounded-xl border px-3 py-1 text-sm">'+esc(x)+'</span>').join('')||'<span class="text-sm text-slate-500">Пока не указаны</span>')+'</div>').join('');
}

const API = localStorage.getItem('jasApi') || (['localhost','127.0.0.1'].includes(location.hostname)
  ? location.protocol+'//'+location.hostname+':8000/api/v1' : location.origin+'/api/v1');
const $ = (s) => document.querySelector(s);
function verificationBadge(verified, interactive = true) {
  if (!verified) return '';
  const label = 'Аккаунт подтверждён JAS Volunteers';
  const image = '<img src="/assets/jas-verification.png" width="20" height="20" alt="" aria-hidden="true">';
  return interactive
    ? `<button type="button" class="verified-badge" aria-label="${label}" title="${label}" onclick="event.preventDefault();event.stopPropagation();toast(this.title)">${image}</button>`
    : `<span class="verified-badge" role="img" aria-label="${label}" title="${label}">${image}</span>`;
}
function verifiedName(value, verified, interactive = true) {
  const escape = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const words = String(value || '').trim().split(/\s+/);
  const last = words.pop();
  if (!verified) return escape(value || '');
  return (words.length ? escape(words.join(' ')) + ' ' : '') + '<span class="verified-name-tail">' + escape(last) + verificationBadge(true, interactive) + '</span>';
}

async function api(path, options = {}) {
  // Only reads expire automatically: a timed out write may still have succeeded.
  const controller = new AbortController();
  const isRead = !options.method || ['GET', 'HEAD'].includes(options.method.toUpperCase());
  const timeout = isRead ? setTimeout(() => controller.abort(), 25000) : null;
  const abort = () => controller.abort(options.signal?.reason);
  if (options.signal?.aborted) abort();
  else options.signal?.addEventListener('abort', abort, {once: true});
  let response, data;
  try {
    response = await fetch(API + path, { ...options, signal: controller.signal, credentials: 'include', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
    if (response.status === 204) return null;
    data = await response.json().catch(error => { if (controller.signal.aborted) throw error; return {}; });
  } catch (error) {
    if (controller.signal.aborted && !options.signal?.aborted) throw new Error('Сервер отвечает слишком долго. Попробуйте загрузить этот раздел ещё раз.');
    throw error;
  } finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener('abort', abort);
  }
  if (response.status === 503 && data.code === 'maintenance' && !location.pathname.endsWith('/maintenance.html')) location.replace('/maintenance.html');
  if (!response.ok) {
    const detail = Array.isArray(data.detail)
      ? data.detail.map(item => item.loc?.includes('username')
        ? 'Никнейм: от 3 до 32 символов — латинские буквы, цифры и знак _. Без пробелов и @.'
        : item.msg || 'Некорректные данные').join('. ')
      : data.detail;
    const message = typeof detail === 'string' ? detail : detail?.message || detail?.msg;
    const error = new Error(message || 'Не удалось выполнить запрос');
    error.status = response.status;
    throw error;
  }
  return data;
}
function toast(message, error = false) {
  const node = document.createElement('div'); node.textContent = message;
  node.className = `fixed bottom-5 right-5 z-[100] rounded-xl px-5 py-3 text-sm font-semibold shadow-xl ${error ? 'bg-red-700' : 'bg-gray-900'} text-white`;
  document.body.append(node); setTimeout(() => node.remove(), 3500);
}
function toggleAuthModal(mode) {
  const m = $('#authModal'); if (!m) return;
  if (!mode && !m.classList.contains('hidden')) { m.classList.add('hidden'); return; }
  mode = mode || 'login';
  m.classList.remove('hidden');
  $('#authTitle').textContent = mode === 'login' ? 'Вход в систему' : 'Создать аккаунт';
  $('#loginForm').classList.toggle('hidden', mode !== 'login');
  $('#registerForm').classList.toggle('hidden', mode !== 'register');
}
let currentUserRequest = null;
async function getMe({throwOnError = false} = {}) {
  // Several page modules need the same current session at startup. Share only
  // the pending request; a later call always checks the server again.
  if (!currentUserRequest) currentUserRequest = api('/auth/me').then(data => data.user).finally(() => { currentUserRequest = null; });
  try { return await currentUserRequest; }
  catch (error) { if (throwOnError) throw error; return null; }
}
setInterval(() => { if (!document.hidden && !location.pathname.endsWith('/maintenance.html')) getMe().then(user=>document.dispatchEvent(new CustomEvent('jas:community-user',{detail:user}))); }, 60000);
function setNav(user) { document.querySelectorAll('[data-auth]').forEach(x => x.classList.toggle('hidden', !user)); document.querySelectorAll('[data-guest]').forEach(x => x.classList.toggle('hidden', !!user)); if (user) document.querySelectorAll('[data-user-name]').forEach(x => x.textContent = user.full_name); }
document.addEventListener('DOMContentLoaded', async () => {
  const username = $('#registerForm [name="username"]');
  if (username) {
    const validateUsername = () => username.setCustomValidity(
      username.value && !/^[A-Za-z0-9_]{3,32}$/.test(username.value)
        ? 'Введите от 3 до 32 символов: латинские буквы, цифры или _. Без пробелов и @.' : '');
    username.addEventListener('input', validateUsername);
    username.addEventListener('blur', () => { username.value = username.value.trim(); validateUsername(); });
    username.addEventListener('invalid', validateUsername);
  }
  $('#loginForm')?.addEventListener('submit', async e => { e.preventDefault(); const submit=e.target.querySelector('button'); if(submit.disabled)return; submit.disabled=true; const f = new FormData(e.target); try { await api('/auth/login',{method:'POST',body:JSON.stringify({login:f.get('login'),password:f.get('password')})}); location.href='dashboard.html'; } catch (x) { toast(x.message,true); } finally { submit.disabled=false; } });
  $('#registerForm')?.addEventListener('submit', async e => { e.preventDefault(); const submit=e.target.querySelector('button'); if(submit.disabled)return; submit.disabled=true; const f = new FormData(e.target); try { await api('/auth/register',{method:'POST',body:JSON.stringify(Object.fromEntries(f))}); location.href='dashboard.html'; } catch (x) { toast(x.message,true); } finally { submit.disabled=false; } });
  $('#logout')?.addEventListener('click', async () => { try { await api('/auth/logout',{method:'POST'}); location.href='index.html'; } catch(e) { toast(e.message,true); } });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#authModal')?.classList.contains('hidden')&&$('#authModal'))toggleAuthModal();});
  const user = await getMe(); setNav(user);
});
function statusLabel(status) { return ({pending:'На рассмотрении',accepted:'Принят',rejected:'Отклонён',completed:'Завершён',cancelled:'Отменён',excused:'Уважительная причина',no_show:'Не пришёл'})[status] || status; }
function statusClass(status) { return ({pending:'bg-amber-50 text-amber-700',accepted:'bg-emerald-50 text-emerald-700',rejected:'bg-red-50 text-red-700',completed:'bg-gray-100 text-gray-700',cancelled:'bg-gray-100 text-gray-600'})[status] || ''; }
function can(user, permission) { return !!user && (user.permissions || []).some(p => p === '*' || p === permission); }
function canCoordinate(user) { return ['projects.manage','applications.review','attendance.manage','departments.manage','audit.export'].some(permission => can(user,permission)) || ['chairman','vice_chairman'].includes(user?.role); }

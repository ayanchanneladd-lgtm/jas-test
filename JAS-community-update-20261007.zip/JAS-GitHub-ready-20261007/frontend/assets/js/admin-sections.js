const adminSections = {
  overview: {target: '#stats', run: async () => {
    const stats=await api('/admin/stats');$('#stats').innerHTML=[['Пользователи',stats.users],['Проекты',stats.projects],['Заявки',stats.applications]].map(x=>`<div class="rounded-2xl bg-white p-5 shadow-sm"><p class="text-sm text-slate-500">${x[0]}</p><b class="mt-2 block text-3xl text-jas">${x[1]}</b></div>`).join('');
  }},
  server: {target: '#health', run: async () => {
    const overview=await api('/admin/developer-overview');$('#health').innerHTML=`<p>Firestore: <b class="text-emerald-700">подключён</b></p><p class="mt-2">Firebase project: ${esc(overview.project_id||'не указан')}</p><p class="mt-2">Ошибок API: ${overview.collections.system_errors}</p><p class="mt-2">Audit logs: ${overview.collections.audit_logs}</p>`;
  }},
  settings: {target: '#settingsForm', run: async () => {
    const settings=await api('/admin/settings');$('#platformName').value=settings.platform_name||'';$('#betaMode').checked=!!settings.beta_mode;
  }},
  users: {target: '#users', run: async () => {
    const [users,roles,org]=await Promise.all([api('/admin/users'),api('/admin/roles'),api('/admin/organization')]);renderUsers(users,roles,org);
  }},
  roles: {target: '#roles', run: async () => {
    const roles=await api('/admin/roles');renderRoles(roles);
  }},
  deleted: {target: '#deletedProjects', run: async () => {
    const deleted=await api('/admin/projects/deleted');$('#deletedProjects').innerHTML=deleted.length?deleted.map(p=>`<div class="border-b p-4"><b>${esc(p.title)}</b><p class="mt-1 text-sm text-slate-500">Причина: ${esc(p.deletion_reason)} · ${esc(p.coordinator_name)}${verificationBadge(p.coordinator_verified)}</p><button onclick="restoreProject('${p.id}')" class="mt-3 rounded-lg border px-3 py-2 text-xs font-bold text-jas">Восстановить</button></div>`).join(''):'<p class="p-5 text-slate-500">Удалённых проектов нет.</p>';
  }},
  organization: {target: '#organization', run: async () => {
    const org=await api('/admin/organization');$('#teamDepartment').innerHTML=org.departments.map(d=>`<option value="${d.id}">${esc(d.name)}</option>`).join('');$('#organization').innerHTML=`<b>Отделы</b><p class="mt-2 text-slate-500">${org.departments.map(d=>esc(d.name)).join(' · ')||'Нет'}</p><b class="mt-4 block">Команды</b><p class="mt-2 text-slate-500">${org.teams.map(t=>esc(t.name)).join(' · ')||'Нет'}</p>`;
  }},
  announcements: {target: '#notifications', run: async () => {
    const [notifications,roles]=await Promise.all([api('/admin/notifications'),api('/admin/roles')]);$('#notifications').innerHTML=notifications.length?notifications.slice(0,5).map(n=>`<div class="border-b p-4"><b>${esc(n.title)}</b><p class="mt-1 text-sm text-slate-500">${esc(n.audience==='all'?'Все пользователи':n.role)} · ${new Date(n.created_at).toLocaleString('ru-RU')}</p></div>`).join(''):'<p class="p-5 text-slate-500">Объявлений нет.</p>';$('#notificationRole').innerHTML=roles.roles.map(role=>`<option value="${role.key}">${esc(role.label)}</option>`).join('');
  }},
  errors: {target: '#errors', run: async () => {
    const errors=await api('/admin/system-errors');$('#errors').innerHTML=errors.length?errors.map(e=>`<div class="border-b p-4 text-sm"><b>${esc(e.path)}</b><p class="mt-1 text-red-700">HTTP ${e.status}${e.message?' · '+esc(e.message):''}</p><p class="mt-1 text-slate-500">${new Date(e.created_at).toLocaleString('ru-RU')}</p></div>`).join(''):'<p class="p-5 text-slate-500">Ошибок API не зафиксировано.</p>';
  }},
  audit: {target: '#logs', run: async () => {
    await loadAudit();
  }}
};

const adminLoaded = new Set(), adminPending = new Map();
async function load(force = true) {
  const key = location.hash.startsWith('#section=') ? location.hash.slice(9) :
    Object.keys(adminSections).find(key => adminSections[key].target === location.hash) || 'overview';
  const section = adminSections[key];
  if (force) adminLoaded.clear();
  if (!section) {
    // Optional sections own their loaders, but every admin entry point still
    // checks the current identity before leaving the page accessible.
    try {
      const me = await getMe({throwOnError:true});
      if (!me || me.role !== 'super_admin') location.replace('dashboard.html');
      else document.getElementById('identity').textContent = me.full_name;
    } catch (error) {
      if (error.status === 401 || error.status === 403) location.replace('dashboard.html');
      else toast(error.message, true);
    }
    return;
  }
  if (adminLoaded.has(key)) return;
  if (adminPending.has(key)) return adminPending.get(key);
  const task = (async () => {
    const host = document.querySelector(section.target);
    document.querySelectorAll('[data-admin-loading="'+key+'"]').forEach(node => node.remove());
    const status = document.createElement('div'); status.className = 'section-load-status'; status.setAttribute('role','status');
    status.dataset.adminLoading = key;
    status.textContent = 'Загрузка раздела…'; host.before(status);
    const controls = [...host.querySelectorAll('button,input,select,textarea')].filter(control => !control.disabled || control.dataset.loadingDisabled);
    controls.forEach(control => control.dataset.loadingDisabled = 'true');
    controls.forEach(control => control.disabled = true);
    host.setAttribute('aria-busy','true');
    try {
      const me = await getMe({throwOnError:true});
      if (!me || me.role !== 'super_admin') { location.replace('dashboard.html'); return; }
      document.getElementById('identity').textContent = me.full_name;
      await section.run(); adminLoaded.add(key); status.remove();
    } catch (error) {
      if (error.status === 401 || error.status === 403) { location.replace('dashboard.html'); return; }
      status.textContent = 'Не удалось загрузить раздел: ' + error.message + ' ';
      const retry = document.createElement('button'); retry.type = 'button'; retry.textContent = 'Повторить';
      retry.onclick = () => { status.remove(); load(); }; status.append(retry);
    } finally {
      if (adminLoaded.has(key)) controls.forEach(control => { control.disabled = false; delete control.dataset.loadingDisabled; });
      host.removeAttribute('aria-busy');
    }
  })();
  adminPending.set(key, task);
  try { await task; } finally { adminPending.delete(key); }
}
addEventListener('hashchange', () => load(false));

function hoursLabel(minutes) {
  return Math.floor(minutes / 60) + ' ч ' + (minutes % 60) + ' мин';
}

async function openCompletionDialog(projectId) {
  const dialog = document.createElement('dialog');
  dialog.className = 'rounded-2xl p-6';
  dialog.style.cssText = 'width:min(560px,calc(100vw - 32px));max-height:90dvh;overflow:auto;overflow-wrap:anywhere';
  dialog.setAttribute('aria-label', 'Завершить проект и начислить часы');
  dialog.innerHTML = '<h2 class="text-xl font-bold">Завершить проект</h2><div data-preview class="mt-4">Загружаем участников…</div><p data-result role="status" class="mt-3"></p><div class="mt-4 flex flex-wrap gap-2"><button type="button" data-close class="rounded-xl border p-3">Отмена</button><button type="button" data-without class="rounded-xl border p-3">Завершить без начисления</button></div>';
  document.body.append(dialog);
  dialog.showModal();
  let busy = false;
  const result = dialog.querySelector('[data-result]');
  const close = dialog.querySelector('[data-close]');
  const without = dialog.querySelector('[data-without]');
  close.addEventListener('click', () => dialog.close());
  dialog.addEventListener('cancel', event => { if (busy) event.preventDefault(); });
  dialog.addEventListener('close', () => dialog.remove());
  async function save(path, options) {
    if (busy) return;
    busy = true;
    dialog.querySelectorAll('button,input').forEach(x => x.disabled = true);
    result.textContent = 'Сохраняем проект, участие и часы…';
    try {
      const data = await api(path, options);
      dialog.close();
      toast(data.awarded_count ? 'Проект завершён. Часы начислены: ' + data.awarded_count + ' участникам.' : 'Проект завершён без начисления часов.');
      await load();
    } catch (error) { result.textContent = error.message; }
    finally {
      busy = false;
      dialog.querySelectorAll('button,input:not([data-ineligible])').forEach(x => x.disabled = false);
    }
  }
  without.addEventListener('click', () => {
    if (confirm('Завершить проект без начисления часов? Участие и часы можно будет отметить отдельно.'))
      save('/projects/' + encodeURIComponent(projectId) + '/complete', {method: 'PATCH'});
  });
  try {
    const data = await api('/projects/' + encodeURIComponent(projectId) + '/completion-preview');
    if (!dialog.isConnected) return;
    const form = document.createElement('form');
    form.innerHTML = '<p class="font-bold">' + esc(data.title) + '</p><p class="mt-2">Принятых волонтёров: <b>' + data.accepted_count + '</b></p><p class="mt-2 text-sm">Оставьте отмеченными только тех, кто действительно участвовал. Им будет подтверждено участие и начислены ВЧ. У остальных заявки останутся без изменений.</p><div data-roster class="my-4 grid gap-3" style="max-height:240px;overflow:auto">' + data.items.map(item => '<label class="flex items-start gap-2"><input type="checkbox" data-participant value="' + esc(item.application_id) + '" ' + (item.eligible ? 'checked' : 'disabled data-ineligible') + '><span>' + esc(item.name) + (item.reason ? '<small class="block">' + esc(item.reason) + '</small>' : '') + '</span></label>').join('') + '</div><label class="block font-bold">ВЧ каждому участнику<input class="mt-2 block w-full p-3" name="hours" type="number" min="0.0166666667" max="24" step="any" required placeholder="Например, 10"></label><p data-summary class="my-3 text-sm" aria-live="polite"></p><label class="flex items-start gap-2 my-3"><input type="checkbox" required><span>Подтверждаю участие выбранных волонтёров и количество часов. Все начисления и исправления сохраняются в истории.</span></label><button class="rounded-xl bg-jas p-3" type="submit">Завершить и начислить ВЧ</button>';
    const preview = dialog.querySelector('[data-preview]');
    preview.replaceChildren(form);
    function updateSummary() {
      const count = form.querySelectorAll('[data-participant]:checked').length;
      const hours = Number(form.elements.hours.value);
      form.querySelector('[data-summary]').textContent = 'Выбрано: ' + count + (hours > 0 ? ' · По ' + hours + ' ВЧ каждому · Всего: ' + (count * hours).toLocaleString('ru-RU') + ' ВЧ' : ' · Введите часы для каждого участника');
    }
    form.addEventListener('input', updateSummary); updateSummary();
    form.addEventListener('submit', event => {
      event.preventDefault();
      const ids = Array.from(form.querySelectorAll('[data-participant]:checked')).map(x => x.value);
      const rawMinutes = Number(form.elements.hours.value) * 60;
      const minutes = Math.round(rawMinutes);
      if (!ids.length || minutes < 1 || minutes > 1440 || Math.abs(rawMinutes - minutes) > .00001) {
        result.textContent = 'Выберите участников и укажите от 1 минуты до 24 часов с точностью до минуты.';
        return;
      }
      save('/projects/' + encodeURIComponent(projectId) + '/complete-with-hours', {method: 'POST', body: JSON.stringify({minutes, application_ids: ids})});
    });
  } catch (error) {
    if (dialog.isConnected) dialog.querySelector('[data-preview]').textContent = error.message;
  }
}

async function loadVolunteerHours() {
  let section = $('#volunteerHours');
  if (!section) {
    section = document.createElement('section');
    section.id = 'volunteerHours';
    section.className = 'mt-8 rounded-2xl bg-white p-5';
    section.style.overflowWrap = 'anywhere';
    section.style.scrollMarginTop = '160px';
    $('main > section').after(section);
  }
  section.innerHTML = '<div class="flex flex-wrap items-center justify-between gap-2"><h2 class="text-xl font-bold">Волонтёрские часы</h2><button type="button" data-hours-refresh class="rounded-xl border p-3 text-sm">Обновить</button></div><p data-hours-summary class="mt-2">Загрузка…</p><div data-hours-history></div><p data-hours-status role="status"></p><button type="button" data-hours-more class="mt-4 rounded-xl border p-3" hidden>Показать ещё</button>';
  section.querySelector('[data-hours-refresh]').addEventListener('click', loadVolunteerHours);
  let cursor = null;
  const more = section.querySelector('[data-hours-more]');
  const status = section.querySelector('[data-hours-status]');
  async function fetchPage() {
    if (more.disabled) return;
    more.disabled = true;
    status.textContent = '';
    try {
      const data = await api('/my/hours' + (cursor ? '?cursor=' + encodeURIComponent(cursor) : ''));
      if (!Array.isArray(data.items)) throw new Error('Не удалось получить историю часов');
      section.querySelector('[data-hours-summary]').textContent = hoursLabel(data.total_minutes) + ' подтверждено · Проектов: ' + data.project_count;
      const list = section.querySelector('[data-hours-history]');
      if (!cursor && !data.items.length) list.innerHTML = '<p class="mt-4 text-slate-500">Пока нет начислений. После подтверждения участия руководитель сможет начислить часы.</p>';
      for (const item of data.items) {
        const card = document.createElement('article');
        card.className = 'border-b py-4';
        card.innerHTML = '<div class="flex flex-wrap justify-between gap-2"><a class="font-bold" href="project.html?id=' + encodeURIComponent(item.project_id) + '">' + esc(item.project_title) + '</a><b>' + esc(hoursLabel(item.minutes)) + '</b></div><p class="text-sm mt-2">' + esc(item.reason) + '</p><p class="text-sm text-slate-500">' + esc(new Date(item.created_at).toLocaleString('ru-RU')) + ' · Начислил: ' + esc(item.granted_by_name) + '</p>';
        if (item.status === 'corrected') {
          card.querySelector('b').textContent = hoursLabel(item.previous_minutes) + ' → ' + hoursLabel(item.minutes);
          card.querySelector('p:last-child').textContent = new Date(item.created_at).toLocaleString('ru-RU') + ' · Исправил: ' + item.granted_by_name;
          const label = document.createElement('p'); label.className = 'text-sm font-bold mt-2'; label.textContent = 'Исправление часов (не дополнительное начисление)'; card.prepend(label);
        }
        list.append(card);
      }
      cursor = data.next_cursor;
      more.hidden = !cursor;
      more.textContent = 'Показать ещё';
    } catch (error) {
      status.textContent = error.message;
      if (!cursor) section.querySelector('[data-hours-summary]').textContent = 'История временно недоступна';
      more.hidden = false;
      more.textContent = 'Повторить загрузку';
    } finally { more.disabled = false; }
  }
  more.addEventListener('click', fetchPage);
  await fetchPage();
}

async function openHoursDialog(applicationId) {
  const data = await api('/applications/' + encodeURIComponent(applicationId) + '/hours');
  const dialog = document.createElement('dialog');
  dialog.className = 'rounded-2xl p-6';
  dialog.style.cssText = 'width: min(520px, calc(100vw - 32px)); max-height: 90dvh; overflow: auto; overflow-wrap: anywhere';
  dialog.setAttribute('aria-label', 'Волонтёрские часы участника');
  dialog.innerHTML = '<h2 class="text-xl font-bold">Волонтёрские часы</h2>';
  if (data.participant_name) dialog.insertAdjacentHTML('beforeend', '<p class="mt-3 font-bold">' + esc(data.participant_name) + '</p><p>' + esc(data.project_title) + '</p>');
  if (data.record) {
    dialog.insertAdjacentHTML('beforeend', '<p class="mt-4">Уже начислено: <b>' + esc(hoursLabel(data.record.minutes)) + '</b></p><p>' + esc(data.record.project_title) + '</p><p>' + esc(data.record.reason) + '</p><p class="text-sm">Начислил: ' + esc(data.record.granted_by_name) + '</p>');
    if ((data.can_correct ?? data.can_award) !== false) {
      const edit = document.createElement('button');
      edit.type = 'button'; edit.className = 'mt-4 rounded-xl border p-3'; edit.textContent = 'Исправить часы';
      edit.addEventListener('click', () => { edit.remove(); showHoursCorrection(dialog, applicationId, data.record); });
      dialog.append(edit);
    }
  } else if (data.can_award === false) {
    dialog.insertAdjacentHTML('beforeend', '<p class="mt-4">Начисление недоступно. Нужны завершённый проект, подтверждённое участие и активный аккаунт участника. Начислять часы себе нельзя.</p>');
  } else {
    const form = document.createElement('form');
    form.className = 'mt-4 grid gap-3';
    form.innerHTML = '<p class="text-sm">Укажите фактическое время участия. Повторное начисление запрещено. Исправления сохраняются в истории. Максимум — 24 часа за проект.</p><div class="grid grid-cols-2 gap-3"><label>Часы<input class="block w-full p-3" name="hours" type="number" min="0" max="24" step="1" value="0" required></label><label>Минуты<input class="block w-full p-3" name="minutes" type="number" min="0" max="59" step="1" value="0" required></label></div><label>Основание<textarea class="block w-full p-3" name="reason" minlength="3" maxlength="500" required placeholder="Например: помощь на регистрации участников"></textarea></label><label class="flex gap-2 items-start"><input type="checkbox" required><span>Проверил время и подтверждаю начисление</span></label><button class="rounded-xl bg-jas p-3">Начислить часы</button><p role="status"></p>';
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const submit = form.querySelector('button'), result = form.querySelector('[role=status]');
      if (submit.disabled) return;
      const minutes = Number(form.elements.hours.value) * 60 + Number(form.elements.minutes.value);
      if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) { result.textContent = 'Укажите от 1 минуты до 24 часов.'; return; }
      submit.disabled = true;
      result.textContent = 'Сохраняем…';
      try {
        await api('/applications/' + encodeURIComponent(applicationId) + '/hours', {method: 'POST', body: JSON.stringify({minutes, reason: form.elements.reason.value.trim()})});
        dialog.close();
        toast('Часы начислены. Участнику отправлено уведомление.');
        await load();
      } catch (error) { result.textContent = error.message; }
      finally { submit.disabled = false; }
    });
    dialog.append(form);
  }
  const close = document.createElement('button');
  close.type = 'button'; close.className = 'mt-4 rounded-xl border p-3'; close.textContent = 'Закрыть';
  close.addEventListener('click', () => dialog.close());
  dialog.append(close);
  dialog.addEventListener('close', () => dialog.remove());
  document.body.append(dialog);
  dialog.showModal();
}

function showHoursCorrection(dialog, applicationId, record) {
  const form = document.createElement('form'); form.className = 'mt-5 grid gap-3';
  form.innerHTML = '<h3 class="font-bold">Исправить количество ВЧ</h3><p class="text-sm">Укажите новое итоговое время за проект, а не прибавку. Ноль отменяет часы. Прежнее значение и причина сохранятся в истории.</p><div class="grid grid-cols-2 gap-3"><label>Часы<input name="hours" type="number" min="0" max="24" step="1" required class="block w-full p-3"></label><label>Минуты<input name="minutes" type="number" min="0" max="59" step="1" required class="block w-full p-3"></label></div><label>Причина исправления<textarea name="reason" minlength="3" maxlength="500" required class="block w-full p-3"></textarea></label><p data-change-summary aria-live="polite"></p><label class="flex gap-2 items-start"><input type="checkbox" required><span>Подтверждаю новое количество часов и причину</span></label><button type="submit" class="rounded-xl bg-jas p-3">Сохранить исправление</button><p role="status"></p>';
  form.elements.hours.value = Math.floor(record.minutes / 60);
  form.elements.minutes.value = record.minutes % 60;
  const total = () => Number(form.elements.hours.value) * 60 + Number(form.elements.minutes.value);
  const summary = () => { form.querySelector('[data-change-summary]').textContent = 'Было: ' + hoursLabel(record.minutes) + ' → Станет: ' + hoursLabel(total()); };
  form.addEventListener('input', summary); summary();
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const button = form.querySelector('button'), status = form.querySelector('[role=status]');
    if (button.disabled) return;
    const minutes = total();
    if (!Number.isInteger(minutes) || minutes < 0 || minutes > 1440 || minutes === record.minutes) {
      status.textContent = 'Укажите новое время от 0 до 24 часов, отличающееся от текущего.'; return;
    }
    button.disabled = true; status.textContent = 'Сохраняем исправление…';
    try {
      await api('/applications/' + encodeURIComponent(applicationId) + '/hours', {method:'PATCH', body:JSON.stringify({minutes, reason:form.elements.reason.value.trim(), expected_version:record.version || 1})});
      dialog.close(); toast('Часы исправлены. История сохранена, волонтёр уведомлён.'); await load();
    } catch (error) { status.textContent = error.message; }
    finally { button.disabled = false; }
  });
  dialog.insertBefore(form, dialog.lastElementChild);
  form.elements.hours.focus();
}

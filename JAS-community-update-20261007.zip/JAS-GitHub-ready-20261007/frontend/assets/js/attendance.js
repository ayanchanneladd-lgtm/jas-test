// Uses the existing leadership list; API validates every selected resource again.
function renderAttendanceManagement(applications, user) {
  document.querySelector('#attendanceManagement')?.remove();
  if (!can(user, 'attendance.manage')) return;
  const grouped = new Map();
  for (const item of applications) {
    if (item.project_status !== 'completed' || item.status !== 'accepted') continue;
    if (!grouped.has(item.project_id)) grouped.set(item.project_id, []);
    grouped.get(item.project_id).push(item);
  }
  const section = document.createElement('section');
  section.id = 'attendanceManagement';
  section.className = 'mt-8 rounded-2xl bg-white p-5';
  section.innerHTML = '<h2 class="text-xl font-bold">Отметить участие</h2><p class="mt-2 text-sm">Выберите статус только для нужных участников. За одно сохранение — до 50 человек одного проекта. Уже подтверждённые отметки здесь не изменяются.</p>';
  if (!grouped.size) section.insertAdjacentHTML('beforeend', '<p class="mt-4 text-slate-500">Нет участников завершённых проектов, ожидающих отметки.</p>');
  for (const [projectId, rows] of grouped) {
    const form = document.createElement('form');
    form.className = 'mt-5 border-t pt-4';
    form.innerHTML = '<h3 class="font-bold">'+esc(rows[0].title)+'</h3>'+rows.map(item=>'<label class="my-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><span>'+esc(item.full_name || item.username || 'Участник')+'</span><select data-attendance-id="'+esc(item.id)+'" class="max-w-full rounded-xl border p-3" aria-label="Отметка: '+esc(item.full_name || 'участник')+'"><option value="">Не менять</option><option value="completed">Участвовал</option><option value="no_show">Не пришёл</option><option value="excused">Уважительная причина</option></select></label>').join('')+'<button class="rounded-xl bg-jas p-3 text-white">Сохранить выбранные отметки</button><p class="mt-3" role="status"></p>';
    form.addEventListener('submit', async event=>{
      event.preventDefault();
      const submit=form.querySelector('button'), result=form.querySelector('[role="status"]');
      if (submit.disabled) return;
      const items=Array.from(form.querySelectorAll('[data-attendance-id]')).filter(x=>x.value).map(x=>({application_id:x.dataset.attendanceId,status:x.value}));
      if (!items.length || items.length>50) {result.textContent='Выберите от 1 до 50 участников.';return;}
      if (!confirm('Сохранить отметки для '+items.length+' участников? Проверьте выбранные статусы.')) return;
      submit.disabled=true;result.textContent='Сохраняем…';
      try {
        const data=await api('/projects/'+encodeURIComponent(projectId)+'/attendance',{method:'PUT',body:JSON.stringify({items})});
        result.textContent='Сохранено: '+data.updated+'. Уже было сохранено: '+data.unchanged+'.';
        toast(result.textContent);await load();
      } catch(error) {result.textContent=error.message;}
      finally {submit.disabled=false;}
    });
    section.append(form);
  }
  $('#management').after(section);
}

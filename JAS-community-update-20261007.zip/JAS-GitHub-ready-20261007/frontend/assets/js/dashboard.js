const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let editingProject = null, notificationOffset = 0;
const coordinatorPage = document.body.dataset.page === 'coordinator';
let attendanceAllowed = false, hoursAllowed = false;
let notificationRequest = null, notificationTotal = 0, profileDirty = false;
const button = (label, action, id, status='') => '<button type="button" class="rounded-xl border px-3 py-2 text-sm" data-action="'+action+'" data-id="'+esc(id)+'" data-status="'+status+'">'+label+'</button>';
const empty = '<p class="p-5 text-slate-500">Пока нет записей.</p>';
function applicationRow(a, manager) {
  let actions = button('История','history',a.id);
  if (!manager && (a.status === 'pending' || a.status === 'accepted' && a.project_status !== 'completed')) actions += button('Отменить','cancel',a.id);
  if (manager && a.status === 'pending') actions += (a.project_status==='active'?button('Принять','review',a.id,'accepted'):'')+button('Отклонить','review',a.id,'rejected');
  if (manager && attendanceAllowed && a.status === 'accepted' && a.project_status==='completed') actions += button('Участвовал','review',a.id,'completed')+button('Не пришёл','review',a.id,'no_show')+button('Уважительная причина','review',a.id,'excused');
  if (manager && hoursAllowed && a.status === 'completed' && a.project_status === 'completed') actions += button('Часы','hours',a.id);
  return '<article class="border-b p-5"><a class="font-bold" href="project.html?id='+encodeURIComponent(a.project_id)+'">'+esc(a.title)+'</a><p>'+esc(a.full_name || '')+verificationBadge(a.verified)+'</p><p class="text-sm">'+esc(a.location)+' · '+esc(a.status==='no_show'?'Не пришёл':statusLabel(a.status))+'</p><div class="mt-3 flex flex-wrap gap-2">'+actions+'</div></article>';
}
function preserveProfileDraft(render) {
  const form = $('#profile');
  const draft = profileDirty ? Object.fromEntries(new FormData(form)) : null;
  render();
  if (draft) for (const [name, value] of Object.entries(draft)) if (form.elements[name]) form.elements[name].value = value;
}
async function loadSection(selector, loader, retryLoader = null) {
  const target = $(selector);
  target?.setAttribute('aria-busy', 'true');
  target?.querySelector('[data-load-error]')?.remove();
  try { await loader(); return true; }
  catch (error) {
    if (error.status === 401) { location.replace('index.html'); return false; }
    if (!target) { toast(error.message, true); return false; }
    const message = document.createElement('div');
    message.dataset.loadError = '';
    message.className = 'p-4 text-sm';
    const text = document.createElement('p'); text.setAttribute('role', 'status'); text.textContent = 'Не удалось загрузить раздел: ' + error.message;
    const retry = document.createElement('button'); retry.type = 'button'; retry.className = 'mt-3 rounded-xl border px-3 py-2'; retry.textContent = 'Повторить загрузку';
    retry.addEventListener('click', async () => { retry.disabled = true; await (retryLoader ? retryLoader() : loadSection(selector, loader)); });
    message.append(text, retry); target.replaceChildren(message);
    if (target.id === 'dashboardLoadStatus') target.hidden = false;
    return false;
  } finally { target?.setAttribute('aria-busy', 'false'); }
}
function ensureManagedProjects() {
  if(!$('#managedProjects')) $('#projectManagement').insertAdjacentHTML('afterend','<section id="managedProjects" class="mt-8"><h2 class="text-xl font-bold">Активные проекты</h2><div id="activeProjectList"><p class="p-5 text-slate-500">Загрузка…</p></div></section><section id="completedProjects" class="mt-8"><h2 class="text-xl font-bold">Завершённые проекты</h2><div id="completedProjectList"></div></section>');
}
async function loadProjectCategories() {
  const cats = await api('/categories'), selected = $('#projectCategory').value;
  $('#projectCategory').innerHTML = cats.map(c => '<option value="' + esc(c.id) + '">' + esc(c.name) + '</option>').join('');
  if (selected) $('#projectCategory').value = selected;
  $('#projectCategoriesStatus').replaceChildren();
}
function load() {
  return loadDashboard();
}
async function loadDashboard() {
  let user;
  if (!$('#dashboardLoadStatus')) $('main').insertAdjacentHTML('afterbegin', '<div id="dashboardLoadStatus" class="rounded-xl border bg-white" hidden></div>');
  const authenticated = await loadSection('#dashboardLoadStatus', async () => {
    user = await getMe({throwOnError: true});
    if (!user) { location.replace('index.html'); return; }
    if (coordinatorPage && !canCoordinate(user)) { location.replace('dashboard.html'); user = null; return; }
    if (!coordinatorPage && /#section=(create|applications|reports|organization|verification)$/.test(location.hash)) {
      if (canCoordinate(user)) { location.replace('coordinator.html'+location.hash); user=null; return; }
      location.hash='section=overview';
    }
    attendanceAllowed=can(user,'attendance.manage');
    hoursAllowed=can(user,'hours.manage');
    if (!attendanceAllowed || !can(user,'applications.review')) $('#attendanceManagement')?.remove();
    $('#name').textContent=user.full_name;
    document.dispatchEvent(new CustomEvent('jas:user',{detail:user}));
    if (coordinatorPage) {
      let shortcuts = $('#coordinatorActions');
      if (!shortcuts) { shortcuts = document.createElement('div'); shortcuts.id = 'coordinatorActions'; $('#coordinatorIntro').append(shortcuts); }
      shortcuts.replaceChildren();
      const actions = [
        ['projects.manage','projects','Проекты команды','Просмотр, редактирование и завершение'],
        ['projects.manage','create','Создать проект','Новая волонтёрская инициатива'],
        ['applications.review','applications','Заявки и участие','Приём участников, отметки и волонтёрские часы'],
        ['departments.manage','organization','Отделы и команды','Управление структурой организации'],
        ['audit.export','reports','Журнал действий','Отчёт за выбранный период']
      ];
      for (const [permission,key,title,description] of actions) if (can(user,permission) && (key !== 'reports' || ['super_admin','chairman','vice_chairman'].includes(user.role))) {
        const link = document.createElement('a'); link.href='#section='+key; link.textContent=title;
        const detail = document.createElement('small'); detail.textContent=description; link.append(detail); shortcuts.append(link);
      }
    }
    if (!coordinatorPage) {
      $('#meta').textContent=user.role_label;
      $('#coordinatorLink').classList.toggle('hidden',!canCoordinate(user));
      preserveProfileDraft(() => {
      $('#profile').elements.full_name.value=user.full_name;
      $('#profile').elements.username.value=user.username;
      renderProfileDetails(user);
      });
    }
    $('#adminLink').classList.toggle('hidden',user.role!=='super_admin');
    $('#projectManagement')?.classList.toggle('hidden',!can(user,'projects.manage'));
    $('#management')?.classList.toggle('hidden',!can(user,'applications.review'));
    $('#auditExport')?.classList.toggle('hidden',!can(user,'audit.export')||!['super_admin','chairman','vice_chairman'].includes(user.role));
    $('#dashboardLoadStatus').hidden = true;
  }, () => location.reload());
  if (!authenticated || !user) return;
  // Render every ready section immediately. One slow or failed read must not
  // hold up the coordinator's projects, applications, hours or notifications.
  const tasks = coordinatorPage ? [] : [
    loadSection('#apps', async () => {
      const mine = await api('/my/applications');
      preserveProfileDraft(() => renderVolunteerProfile(user, mine));
    }),
    loadVolunteerHours(),
    loadNotifications()
  ];
  if(coordinatorPage && can(user,'applications.review')) {
    tasks.push(loadSection('#review', async () => {
      const all=await api('/applications');
      $('#review').innerHTML='<p class="p-4 text-sm">Участие отмечается после завершения проекта.</p>'+all.map(a=>applicationRow(a,true)).join('');
      renderAttendanceManagement(all,user);
    }));
  }
  if(coordinatorPage && can(user,'projects.manage')) {
    ensureManagedProjects();
    if (!$('#projectCategoriesStatus')) $('#projectCategory').insertAdjacentHTML('afterend', '<div id="projectCategoriesStatus" class="md:col-span-2" role="status"></div>');
    tasks.push(loadSection('#projectCategoriesStatus', loadProjectCategories), loadSection('#activeProjectList', loadManagedProjects));
  } else {
    $('#managedProjects')?.remove(); $('#completedProjects')?.remove();
  }
  await Promise.allSettled(tasks);
}
async function loadManagedProjects() {
  ensureManagedProjects();
  const projects=await api('/managed/projects');
  for(const [status,target] of [['active','#activeProjectList'],['completed','#completedProjectList']]) {
    $(target).innerHTML=projects.filter(p=>p.status===status).map(p=>'<article class="mt-3 rounded-2xl bg-white p-5"><a class="font-bold" href="project.html?id='+encodeURIComponent(p.id)+'">'+esc(p.title)+'</a><p>'+esc(p.location)+' · '+esc(new Date(p.starts_at).toLocaleString('ru-RU'))+'</p><p>Координатор: '+esc(p.coordinator_name)+verificationBadge(p.coordinator_verified)+' · Свободно: '+p.available_places+'</p><div class="mt-3 flex flex-wrap gap-2">'+(status==='active'?button('Редактировать','edit',p.id)+button('Завершить','complete',p.id):'')+button('Удалить','delete',p.id)+'</div></article>').join('')||empty;
  }
}
function loadNotifications(offset = notificationOffset) {
  if (notificationRequest) return notificationRequest;
  if(!$('#inbox')) $('main').insertAdjacentHTML('beforeend','<section id="inbox" class="mt-8 rounded-2xl bg-white p-5"><h2 class="text-xl font-bold">Уведомления <span id="unread"></span></h2><div id="inboxItems" aria-live="polite"></div><div class="flex gap-2"><button id="noticePrev" data-action="noticePrev" class="rounded-xl border p-3">Назад</button><button id="noticeNext" data-action="noticeNext" class="rounded-xl border p-3">Далее</button></div></section>');
  $('#noticePrev').disabled = $('#noticeNext').disabled = true;
  notificationRequest = loadSection('#inboxItems', async () => {
  const data=await api('/my/notifications?offset='+offset);
  notificationOffset = offset; notificationTotal = data.total;
  $('#unread').textContent='('+data.unread+' новых)';
  $('#inboxItems').innerHTML=data.items.map(n=>'<article class="border-b py-4"><b>'+esc(n.title)+'</b><p style="white-space:pre-wrap">'+esc(n.message)+'</p>'+(['HOURS_CONFIRMED','HOURS_CORRECTED'].includes(n.type)?'<a href="#volunteerHours" class="text-jas underline">История часов</a><br>':'')+'<small>'+esc(new Date(n.created_at).toLocaleString('ru-RU'))+'</small> '+(n.read?'Прочитано':button('Прочитано','read',n.id))+'</article>').join('')||empty;
  }, () => loadNotifications(offset)).finally(() => {
    $('#noticePrev').disabled=notificationOffset===0;
    $('#noticeNext').disabled=notificationOffset+20>=notificationTotal;
    notificationRequest = null;
  });
  return notificationRequest;
}
async function downloadAuditLogs() {
  try {
    const response=await fetch(API+'/audit-logs/export?period='+$('#auditPeriod').value,{credentials:'include'});
    if(!response.ok)throw new Error('Не удалось скачать журнал');
    const link=document.createElement('a');link.href=URL.createObjectURL(await response.blob());link.download='jas-audit.csv';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
  }catch(e){toast(e.message,true)}
}
document.addEventListener('DOMContentLoaded',()=>{
  $('#profile')?.addEventListener('input', () => { profileDirty = true; });
  $('#openProjectForm')?.addEventListener('click',()=>{
    editingProject=null;$('#projectForm').reset();$('#projectForm').classList.remove('hidden');
    $('#projectManagement h2').textContent='Создать проект';
    $('#projectForm button').textContent='Создать проект';
  });
  $('#projectForm')?.addEventListener('submit',async e=>{
    e.preventDefault();const submit=e.target.querySelector('button');submit.disabled=true;
    try{
      const data=Object.fromEntries(new FormData(e.target));data.capacity=Number(data.capacity);data.starts_at=new Date(data.starts_at).toISOString();
      await api(editingProject?'/projects/'+encodeURIComponent(editingProject):'/projects',{method:editingProject?'PUT':'POST',body:JSON.stringify(data)});
      toast(editingProject?'Проект обновлён':'Проект создан');editingProject=null;e.target.reset();e.target.classList.add('hidden');location.hash='section=projects';await loadSection('#activeProjectList', loadManagedProjects);
    }catch(x){toast(x.message,true)}finally{submit.disabled=false}
  });
  $('#profile')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const submit=e.target.querySelector('button');if(submit.disabled)return;submit.disabled=true;
    try{
      const data=Object.fromEntries(new FormData(e.target));
      for(const field of ['skills','interests']) {
        data[field]=(data[field]||'').split(',').map(value=>value.trim()).filter(Boolean);
        if(data[field].length>20||data[field].some(value=>value.length>50))throw new Error('Укажите до 20 значений, каждое не длиннее 50 символов');
      }
      const saved=await api('/profile',{method:'PATCH',body:JSON.stringify(data)});
      profileDirty=false;
      $('#name').textContent=saved.user.full_name;
      document.dispatchEvent(new CustomEvent('jas:user',{detail:saved.user}));
      renderProfileDetails(saved.user);
      $('#profileSaveResult').textContent='Профиль сохранён';toast('Профиль сохранён');
    }catch(x){if($('#profileSaveResult'))$('#profileSaveResult').textContent=x.message;toast(x.message,true)}
    finally{submit.disabled=false;}
  });
  $('main').addEventListener('click',async e=>{
    const b=e.target.closest('[data-action]');if(!b || b.disabled)return;
    const {action,id,status}=b.dataset;b.disabled=true;
    try{
      if(action==='hours'){await openHoursDialog(id);return;}
      if(action==='history'){
        const rows=await api('/applications/'+encodeURIComponent(id)+'/history');
        const dialog=document.createElement('dialog');dialog.className='rounded-2xl p-6';dialog.style.maxWidth='90vw';
        dialog.innerHTML='<h2 class="font-bold">История заявки</h2>'+rows.map(r=>'<p>'+esc(new Date(r.created_at).toLocaleString('ru-RU'))+' · '+esc(r.status==='no_show'?'Не пришёл':statusLabel(r.status))+'</p>').join('')+'<form method="dialog"><button class="mt-4 rounded-xl border p-3">Закрыть</button></form>';
        document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();return;
      }
      if(action==='edit'){
        const p=await api('/projects/'+encodeURIComponent(id));editingProject=id;
        for(const key of ['title','description','location','capacity','category_id','image_url','requirements'])$('#projectForm').elements[key].value=p[key]||'';
        const d=new Date(p.starts_at);$('#projectForm').elements.starts_at.value=new Date(d-d.getTimezoneOffset()*60000).toISOString().slice(0,16);
        $('#projectManagement h2').textContent='Редактировать проект';$('#projectForm button').textContent='Сохранить изменения';$('#projectForm').classList.remove('hidden');location.hash='section=create';return;
      }
      if(action==='cancel'){if(!confirm('Отменить свою заявку? Повторная подача на этот проект недоступна.'))return;await api('/my/applications/'+encodeURIComponent(id)+'/cancel',{method:'POST'})}
      if(action==='review')await api('/applications/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({status})});
      if(action==='complete'){await openCompletionDialog(id);return;}
      if(action==='delete'){const reason=prompt('Причина удаления (от 5 символов):');if(reason===null)return;await api('/projects/'+encodeURIComponent(id),{method:'DELETE',body:JSON.stringify({reason:reason.trim()})})}
      if(action==='read'){await api('/my/notifications/'+encodeURIComponent(id)+'/read',{method:'POST'});await loadNotifications();return;}
      if(action==='noticePrev'){await loadNotifications(Math.max(0,notificationOffset-20));return}
      if(action==='noticeNext'){await loadNotifications(notificationOffset+20);return}
      toast('Изменения сохранены');await load();
    }catch(x){toast(x.message,true)}finally{b.disabled=false}
  });
  load();
  if (!coordinatorPage) setInterval(()=>{if(!document.hidden)loadNotifications().catch(()=>{});},30000);
});

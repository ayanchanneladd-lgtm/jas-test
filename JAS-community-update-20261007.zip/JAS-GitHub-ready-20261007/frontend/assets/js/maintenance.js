let maintenanceChecking = false;
async function refreshMaintenance() {
  if (maintenanceChecking) return;
  maintenanceChecking = true;
  const button = $('#check'); button.disabled = true; button.setAttribute('aria-busy', 'true');
  try {
    const data = await api('/maintenance', {signal: AbortSignal.timeout(10000)});
    if (!data.maintenance_mode) { location.replace('/'); return; }
    $('#reason').textContent = data.maintenance_reason || 'Технические работы';
    $('#estimate').textContent = data.maintenance_hours ? data.maintenance_hours + ' ч.' : 'Уточняется';
    const deadline = data.maintenance_until ? new Date(data.maintenance_until) : null;
    $('#until').textContent = deadline && !Number.isNaN(deadline.getTime())
      ? deadline.toLocaleString('ru-RU', {day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'}) : 'Уточняется';
    $('#status').textContent = 'Работы продолжаются. Когда сайт откроется, мы перенаправим тебя автоматически.';
    $('#status').dataset.error = 'false';
  } catch {
    $('#status').textContent = 'Связь со статусом временно недоступна. Проверим снова автоматически.';
    $('#status').dataset.error = 'true';
  } finally { maintenanceChecking = false; button.disabled = false; button.setAttribute('aria-busy', 'false'); }
}
$('#check').addEventListener('click', refreshMaintenance);
$('#developerLogin').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.target.querySelector('button');
  if (button.disabled) return;
  button.disabled = true; $('#loginStatus').textContent = 'Проверяем доступ…';
  try {
    const result = await api('/auth/login', {method:'POST', body:JSON.stringify(Object.fromEntries(new FormData(event.target))), signal:AbortSignal.timeout(15000)});
    if (result.user.role === 'super_admin') location.replace('/admin.html');
    else $('#loginStatus').textContent = 'На время работ доступ открыт только разработчику.';
  } catch (error) { $('#loginStatus').textContent = error.message; }
  finally { button.disabled = false; }
});
const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
const motionButton = $('#motionToggle');
let pausedMotion = false;
function updateMotionButton() {
  const reduced = motionPreference.matches || pausedMotion;
  document.body.classList.toggle('motion-paused', pausedMotion);
  motionButton.setAttribute('aria-pressed', String(reduced));
  motionButton.setAttribute('aria-label', motionPreference.matches ? 'Анимации отключены настройками устройства' : reduced ? 'Включить анимации' : 'Приостановить анимации');
  motionButton.replaceChildren(document.createTextNode(reduced ? 'Анимации на паузе ' : 'Пауза анимаций '));
  const icon = document.createElement('span'); icon.textContent = reduced ? '▷' : 'Ⅱ'; icon.setAttribute('aria-hidden','true'); motionButton.append(icon);
}
motionButton.addEventListener('click', () => { pausedMotion = !pausedMotion; updateMotionButton(); });
motionPreference.addEventListener('change', updateMotionButton);
updateMotionButton();
refreshMaintenance();
setInterval(() => { if (!document.hidden) refreshMaintenance(); }, 15000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshMaintenance(); });

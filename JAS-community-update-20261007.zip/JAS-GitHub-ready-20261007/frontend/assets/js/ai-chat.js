/* Shared AI center and admin dialog. Model output is always plain text. */
(() => {
  async function mount(host) {
    host.innerHTML = `<div class="jas-ai-toolbar"><strong>✦ JAS AI · BETA</strong><a href="/ai.html">AI Center ↗</a></div>
      <p>Только технические вопросы и вымышленные примеры. Не отправляйте имена, документы, логи пользователей, секреты или конфиденциальные данные. Gemini Free Tier может использовать сообщения для улучшения сервисов.</p>
      <p class="jas-ai-status" role="status" aria-live="polite">Загрузка…</p>
      <div class="jas-ai-messages" aria-label="История диалога"></div>
      <section data-chat-proposal aria-label="Подтверждение команды"></section>
      <form><label>Вопрос<textarea maxlength="4000" rows="3" required placeholder="Например: предложи тесты для формы регистрации"></textarea></label>
      <label class="jas-ai-consent"><input type="checkbox" required> Мне 18 лет или больше. В сообщении нет персональных, секретных и конфиденциальных данных.</label>
      <div class="jas-ai-toolbar"><button type="submit" disabled>Отправить</button><button type="button" data-clear>Новый диалог / удалить историю</button><button type="button" data-refresh>Обновить</button></div></form>`;
    const status = host.querySelector('.jas-ai-status');
    const messages = host.querySelector('.jas-ai-messages');
    const form = host.querySelector('form');
    const input = host.querySelector('textarea');
    const send = host.querySelector('[type=submit]');
    const consent = host.querySelector('[type=checkbox]');
    let conversation = null, ready = false, busy = false, retry = null, management = false;
    const proposalHost = host.querySelector('[data-chat-proposal]');
    async function refreshProposal() {
      proposalHost.replaceChildren();
      if (!management) return;
      const data = await api('/ai/admin/proposal');
      const proposal = data.proposal;
      if (!proposal || !['maintenance.start','maintenance.stop'].includes(proposal.action)) return;
      const title = document.createElement('h3');
      title.textContent = proposal.action === 'maintenance.start' ? 'Закрыть сайт на технические работы' : 'Открыть сайт';
      const detail = document.createElement('p');
      detail.textContent = (proposal.action === 'maintenance.start' ? `Ориентировочный срок: ${proposal.parameters.hours} ч. Причина: ${proposal.parameters.reason}. Для открытия сайта потребуется отдельная команда. ` : '') +
        `Статус: ${proposal.state}. Подтверждение до ${new Date(proposal.expires * 1000).toLocaleString('ru-RU')}.`;
      proposalHost.append(title, detail);
      if (proposal.state !== 'pending') return;
      const checkbox = document.createElement('input'); checkbox.type = 'checkbox';
      const label = document.createElement('label'); label.className = 'jas-ai-consent';
      label.append(checkbox, document.createTextNode('Подтверждаю именно это действие и указанный срок.'));
      const approve = document.createElement('button'); approve.type = 'button'; approve.textContent = 'Подтвердить и выполнить';
      approve.dataset.chatConfirm = '';
      const cancel = document.createElement('button'); cancel.type = 'button'; cancel.textContent = 'Отменить';
      proposalHost.append(label, approve, cancel);
      async function decide(confirmAction) {
        if (busy) return;
        if (confirmAction && !checkbox.checked) { status.textContent = 'Проверь действие и поставь отметку подтверждения.'; return; }
        busy = true; approve.disabled = cancel.disabled = send.disabled = true;
        try {
          const result = await api('/ai/admin/proposals/' + proposal.id + '/decision', {
            method:'POST', body:JSON.stringify({confirm:confirmAction})});
          await refreshProposal();
          status.textContent = result.state === 'completed'
            ? (proposal.action === 'maintenance.start' ? 'Техработы включены. Сайт закрыт для посетителей; доступ разработчика сохранён.' : 'Техработы выключены. Сайт открыт.')
            : result.detail || 'Действие отменено.';
        } catch (e) { status.textContent = e.message + ' Обнови карточку перед повтором.'; }
        finally { busy = false; send.disabled = !ready; approve.disabled = cancel.disabled = false; }
      }
      approve.onclick = () => decide(true); cancel.onclick = () => decide(false);
    }
    function render(rows) {
      messages.replaceChildren();
      if (!rows.length) messages.textContent = 'Разработчик может написать: «Включи технические работы на 5 часов» или «Открой сайт». Выполнение — после подтверждения в карточке. Остальные операции доступны в режиме управления.';
      rows.forEach(row => {
        const article = document.createElement('article');
        const title = document.createElement('strong');
        title.textContent = row.role === 'user' ? 'Вы' : 'JAS AI';
        const text = document.createElement('p'); text.textContent = row.text;
        article.append(title, text); messages.append(article);
      });
      messages.scrollTop = messages.scrollHeight;
    }
    async function refresh() {
      if (busy) return;
      send.disabled = true;
      try {
        const [config, history] = await Promise.all([api('/ai/status'), api('/ai/history')]);
        conversation = history.conversation_id;
        const me = await getMe();
        management = !!config.management_available && !!me && can(me, 'ai.chat');
        ready = (config.ready || management) && !!me && can(me, 'ai.chat');
        render(history.messages);
        await refreshProposal();
        status.textContent = ready ? (config.ready ? 'Готов · 3 запроса/мин, 20/сутки. Команды техработ работают без обращения к Gemini.' : 'Gemini выключен. Доступны локальные команды техработ с подтверждением.') : 'AI выключен, не настроен или у вас нет права ai.chat.';
        send.disabled = !ready;
      } catch (e) { ready = false; status.textContent = e.message; }
    }
    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (busy || !ready || !input.value.trim() || !consent.checked) return;
      busy = true; send.disabled = true; input.disabled = true;
      status.textContent = 'JAS AI готовит ответ…';
      try {
        if (!conversation) conversation = (await api('/ai/history/new', {method:'POST'})).conversation_id;
        const message = input.value.trim();
        if (!retry || retry.message !== message || retry.conversation_id !== conversation)
          retry = {request_id:crypto.randomUUID(), conversation_id:conversation, message, privacy_confirmed:true};
        await api('/ai/chat', {method:'POST', body:JSON.stringify(retry), signal:AbortSignal.timeout(45000)});
        input.value = ''; retry = null;
        busy = false; await refresh();
      } catch (error) {
        status.textContent = error.message + ' Обновите историю перед повтором.';
        // Network ambiguity: retain request id; server replays completed requests.
        // Explicit failed request requires edited text or a new conversation.
      } finally { busy = false; input.disabled = false; send.disabled = !ready; input.focus(); }
    });
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); }
    });
    host.querySelector('[data-refresh]').onclick = refresh;
    host.querySelector('[data-clear]').onclick = async () => {
      if (busy || !confirm('Удалить вашу текущую историю без возможности восстановления?')) return;
      busy = true;
      try {
        const data = await api('/ai/history', {method:'DELETE'});
        conversation = data.conversation_id; retry = null; render([]);
        status.textContent = 'История удалена. Копии у провайдера этим действием не удаляются.';
      } catch (e) { status.textContent = e.message; }
      finally { busy = false; }
    };
    await refresh();
  }
  document.addEventListener('DOMContentLoaded', async () => {
    const center = document.querySelector('[data-ai-center]');
    const me = await getMe();
    if (!me || !can(me, 'ai.access')) {
      if (center) center.textContent = 'Для JAS AI необходим вход и разрешение ai.access. Доступ не предоставлен.';
      return;
    }
    if (center) { await mount(center); return; }
    const link = document.createElement('a'); link.href = '/ai.html'; link.textContent = '✦ JAS AI Center';
    const nav = document.querySelector('nav'); if (nav) nav.append(link);
    if (!location.pathname.endsWith('/admin.html')) return;
    const button = document.createElement('button'); button.className = 'jas-ai-launcher'; button.textContent = '✦ JAS AI';
    const dialog = document.createElement('dialog'); dialog.className = 'jas-ai-dialog'; dialog.setAttribute('aria-label', 'JAS AI Chat');
    const close = document.createElement('button'); close.textContent = 'Закрыть ×'; close.onclick = () => dialog.close();
    const host = document.createElement('div'); host.className = 'jas-ai-panel'; dialog.append(close, host);
    document.body.append(button, dialog);
    let loaded = false;
    button.onclick = async () => { dialog.showModal(); if (!loaded) { loaded = true; await mount(host); } };
  });
})();

function activeVolunteerBadge(active) {
  return active ? '<span class="active-volunteer-badge" title="Не менее 50 подтверждённых часов и 8 проектов за всё время"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 1 3.2 6.5 7.2 1-5.2 5.1 1.2 7.2L12 17.4l-6.4 3.4 1.2-7.2L1.6 8.5l7.2-1z"/></svg>Активный волонтёр</span>' : '';
}
function presenceLabel(online) {
  return '<span class="presence '+(online?'online':'')+'" title="Статус по активности на сайте за последние 2 минуты">'+(online?'В сети':'Не в сети')+'</span>';
}
document.addEventListener('DOMContentLoaded',()=>{
  let user=null, heartbeatPending=false, lastHeartbeat=0;
  const mainNav=document.querySelector('body > nav > div, body > header.member-nav');
  if(mainNav){
    const desktop=document.createElement('a');desktop.href='chat.html';desktop.textContent='Общий чат';desktop.className='community-desktop-link';
    (mainNav.querySelector('nav,div')||mainNav).append(desktop);
    const trigger=document.createElement('button');trigger.type='button';trigger.className='mobile-menu-toggle';trigger.textContent='☰';trigger.setAttribute('aria-label','Открыть меню сайта');trigger.setAttribute('aria-expanded','false');trigger.setAttribute('aria-controls','mobileSiteMenu');
    mainNav.append(trigger);mainNav.classList.add('mobile-header-ready');
    const dialog=document.createElement('dialog');dialog.id='mobileSiteMenu';dialog.className='mobile-site-menu';
    dialog.innerHTML='<header><strong>JAS Volunteers</strong><button type="button" aria-label="Закрыть меню сайта">✕</button></header><nav aria-label="Меню сайта"></nav>';
    document.body.append(dialog);
    const renderMenu=()=>{
      const links=[['index.html','Главная'],['projects.html','Проекты'],['members.html','Участники'],['chat.html','Общий чат'],['dashboard.html','Личный кабинет']];
      if(canCoordinate(user))links.push(['coordinator.html','Панель координатора']);
      if(user?.role==='super_admin')links.push(['admin.html','Панель разработчика']);
      dialog.querySelector('nav').innerHTML=links.map(([href,label])=>'<a href="'+href+'">'+label+'</a>').join('')+(user?'<button type="button" data-mobile-logout>Выйти из аккаунта</button>':'<a href="index.html">Войти / зарегистрироваться</a>');
      dialog.querySelector('[data-mobile-logout]')?.addEventListener('click',async event=>{event.target.disabled=true;try{await api('/auth/logout',{method:'POST'});location.href='index.html';}catch(error){event.target.disabled=false;toast(error.message,true);}});
    };
    renderMenu();trigger.onclick=()=>{renderMenu();dialog.showModal();trigger.setAttribute('aria-expanded','true');};
    dialog.querySelector('header button').onclick=()=>dialog.close();
    dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});
    dialog.addEventListener('close',()=>{trigger.setAttribute('aria-expanded','false');trigger.focus();});
  }
  const dock=document.createElement('nav');dock.className='mobile-dock';dock.setAttribute('aria-label','Навигация сайта');
  const current=location.pathname.split('/').pop()||'index.html';
  dock.innerHTML=[['index.html','⌂','Главная'],['projects.html','◇','Проекты'],['chat.html','▤','Чат'],['dashboard.html','○','Кабинет']].map(([href,icon,label])=>'<a href="'+href+'"'+(current===href?' aria-current="page"':'')+'><span aria-hidden="true">'+icon+'</span>'+label+'</a>').join('');
  document.body.append(dock);
  const markOwn=()=>{
    const name=document.getElementById('name');if(!name||!user)return;
    let panel=document.getElementById('ownCommunityStatus');
    if(!panel){panel=document.createElement('div');panel.id='ownCommunityStatus';panel.className='member-status';name.after(panel);}
    panel.innerHTML=presenceLabel(true)+activeVolunteerBadge(user.active_volunteer);
  };
  async function heartbeat(){
    if(!user||document.hidden||heartbeatPending||Date.now()-lastHeartbeat<55000)return;
    heartbeatPending=true;
    try{await api('/presence',{method:'POST'});lastHeartbeat=Date.now();}
    catch(error){if(error.status===401)user=null;}
    finally{heartbeatPending=false;}
  }
  getMe().then(value=>{user=value;markOwn();heartbeat();});
  document.addEventListener('jas:user',event=>{user=event.detail?{...user,...event.detail}:null;markOwn();});
  document.addEventListener('jas:community-user',event=>{user=event.detail;markOwn();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)heartbeat();});
  setInterval(heartbeat,60000);
});

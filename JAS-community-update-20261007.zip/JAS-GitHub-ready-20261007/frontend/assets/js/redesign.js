// Presentation only: existing forms, API calls and permission checks stay intact.
document.addEventListener('DOMContentLoaded', () => {
  const main = document.querySelector('main');
  if (!main) return;
  if (!main.id) main.id = 'main-content';
  main.tabIndex = -1;
  const skip = document.createElement('a');
  skip.className = 'skip-link'; skip.href = '#' + main.id; skip.textContent = 'К содержимому';
  document.body.prepend(skip);
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let paused = false;
  try { paused = localStorage.getItem('jasMotionPaused') === 'true'; } catch {}
  const ownMotionControl = document.getElementById('motionToggle');
  if (ownMotionControl) paused = false;
  const motion = document.createElement('button');
  motion.className = 'motion-toggle'; motion.type = 'button';
  function updateMotion() {
    const stopped = paused || reduced.matches;
    document.documentElement.classList.toggle('motion-paused', stopped);
    motion.textContent = stopped ? 'Анимации: выкл.' : 'Анимации: вкл.';
    motion.setAttribute('aria-pressed', String(stopped));
    motion.setAttribute('aria-label', reduced.matches ? 'Анимации отключены настройками устройства' : 'Приостановить анимации');
    motion.disabled = reduced.matches;
  }
  motion.addEventListener('click', () => { paused = !paused; try { localStorage.setItem('jasMotionPaused', String(paused)); } catch {} updateMotion(); });
  reduced.addEventListener('change', updateMotion);
  updateMotion(); if (!ownMotionControl) document.body.append(motion);
  const progress = document.createElement('div'); progress.className = 'page-progress'; progress.setAttribute('aria-hidden', 'true');
  document.body.append(progress);
  let scheduled = false;
  function updateProgress() {
    scheduled = false;
    const length = document.documentElement.scrollHeight - innerHeight;
    progress.style.transform = 'scaleX(' + (length > 0 ? Math.min(1, scrollY / length) : 0) + ')';
  }
  addEventListener('scroll', () => { if (!scheduled) { scheduled = true; requestAnimationFrame(updateProgress); } }, {passive:true});
  addEventListener('resize', updateProgress); updateProgress();
  const emblem = document.querySelector('.hero-side > img');
  if (emblem) {
    emblem.src = '/assets/oyu-round.png';
    const wrap = document.createElement('div'); wrap.className = 'hero-emblem'; wrap.setAttribute('aria-hidden', 'true');
    emblem.before(wrap); wrap.append(emblem);
    const label = document.createElement('span'); label.textContent = 'ЖАҚСЫЛЫҚ ЖАСА'; wrap.append(label);
  }

  const page = document.body.dataset.page;
  if (['dashboard','coordinator','admin'].includes(page)) initCompactWorkspace(main, page);
  if ('IntersectionObserver' in window && !reduced.matches && !paused) {
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) {
        entry.target.classList.add('jas-enter'); observer.unobserve(entry.target);
        entry.target.addEventListener('animationend', () => entry.target.classList.remove('jas-enter'), {once:true});
      }
    }, {threshold:.07});
    main.querySelectorAll('.poster,.steps-grid article,main > section,.workspace-welcome').forEach(x => observer.observe(x));
  }
});

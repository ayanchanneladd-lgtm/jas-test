document.addEventListener('DOMContentLoaded',async()=>{
  const user=await getMe();if(!can(user,'departments.manage'))return;
  const panel=document.createElement('section');panel.id='organizationPanel';panel.className='mt-8 rounded-2xl bg-white p-5';
  panel.innerHTML='<h2 class="text-xl font-bold">Управление отделами и командами</h2><form class="mt-4 flex flex-wrap gap-2"><select name="kind" class="rounded-xl border p-3"><option value="departments">Отдел</option><option value="teams">Команда</option></select><input name="name" required minlength="2" maxlength="120" placeholder="Название" aria-label="Название" class="rounded-xl border p-3"><select name="department_id" aria-label="Отдел команды" class="rounded-xl border p-3"></select><button class="rounded-xl border p-3">Создать</button></form><div class="directory-list"></div>';
  $('main').append(panel);
  async function refresh(){
    const org=await api('/admin/organization');
    panel.querySelector('[name="department_id"]').innerHTML=org.departments.map(d=>'<option value="'+esc(d.id)+'">'+esc(d.name)+'</option>').join('');
    panel.querySelector('.directory-list').innerHTML=[['departments',org.departments],['teams',org.teams]].map(([kind,rows])=>rows.map(r=>'<div class="flex flex-wrap gap-2 border-b py-3"><span>'+esc(r.name)+'</span><button type="button" data-kind="'+kind+'" data-id="'+esc(r.id)+'" data-name="'+esc(r.name)+'" data-directory="rename" class="rounded-xl border p-2">Переименовать</button><button type="button" data-kind="'+kind+'" data-id="'+esc(r.id)+'" data-directory="delete" class="rounded-xl border p-2">Удалить</button></div>').join('')).join('')||'<p>Справочники пусты.</p>';
  }
  panel.querySelector('form').addEventListener('submit',async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target)),kind=data.kind;delete data.kind;
    if(kind==='departments')delete data.department_id;
    try{await api('/admin/'+kind,{method:'POST',body:JSON.stringify(data)});e.target.reset();await refresh();toast('Создано')}catch(x){toast(x.message,true)}
  });
  panel.addEventListener('click',async e=>{
    const b=e.target.closest('[data-directory]');if(!b)return;b.disabled=true;
    try{
      const path='/admin/'+b.dataset.kind+'/'+encodeURIComponent(b.dataset.id);
      if(b.dataset.directory==='rename'){
        const name=prompt('Новое название:',b.dataset.name);if(name===null)return;
        await api(path,{method:'PATCH',body:JSON.stringify({name:name.trim()})});
      }else{
        if(!confirm('Удалить неиспользуемую запись? Действие необратимо.'))return;
        await api(path,{method:'DELETE'});
      }
      await refresh();toast('Сохранено');
    }catch(x){toast(x.message,true)}finally{b.disabled=false}
  });
  try{await refresh()}catch(e){panel.querySelector('.directory-list').textContent=e.message}
});
